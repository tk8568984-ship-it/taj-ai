/**
 * Utility to convert SVG strings or SVG data URIs to clean PNG Data URLs (image/png;base64,...)
 * using an off-screen HTML5 Canvas. This ensures multimodal AI models like Gemini receive
 * valid raster images (PNG) rather than raw SVG data URIs.
 */

export function convertSvgToPngDataUrl(
  svgInput: string,
  width = 600,
  height = 360
): Promise<string> {
  return new Promise((resolve) => {
    // If not running in a browser with canvas support, return input as-is
    if (typeof window === 'undefined' || typeof document === 'undefined') {
      resolve(svgInput);
      return;
    }

    try {
      const trimmed = svgInput.trim();
      let src = trimmed;

      if (trimmed.startsWith('<svg') || trimmed.includes('<svg xmlns=')) {
        src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(trimmed);
      } else if (trimmed.startsWith('data:image/svg+xml;utf8,')) {
        // Keep as data URI
        src = trimmed;
      }

      const img = new Image();
      img.crossOrigin = 'anonymous';

      const timeoutId = setTimeout(() => {
        // If image takes more than 1.5s to render, resolve with original
        resolve(src);
      }, 1500);

      img.onload = () => {
        clearTimeout(timeoutId);
        try {
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');

          if (ctx) {
            // Fill dark background typical for trading platforms
            ctx.fillStyle = '#090d16';
            ctx.fillRect(0, 0, width, height);

            // Draw SVG
            ctx.drawImage(img, 0, 0, width, height);

            // Convert to PNG Base64 Data URL
            const pngDataUrl = canvas.toDataURL('image/png');
            resolve(pngDataUrl);
            return;
          }
        } catch (canvasErr) {
          console.warn('Canvas conversion failed, using original SVG URI:', canvasErr);
        }
        resolve(src);
      };

      img.onerror = (err) => {
        clearTimeout(timeoutId);
        console.warn('Image element failed to load SVG, using original URI:', err);
        resolve(src);
      };

      img.src = src;
    } catch (topErr) {
      console.warn('Top-level convertSvgToPngDataUrl error:', topErr);
      resolve(svgInput);
    }
  });
}
