import JSZip from 'jszip';

export async function generateProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // 1. README with Bengali & English instructions
  const readmeContent = `# Apex AI - Personal Assistant & Trading Intelligence
## পার্সোনাল এআই অ্যাসিস্ট্যান্ট ও ট্রেডিং জগতের ৩০টি ধাপ (মোবাইল ও পিসি সেটআপ গাইড)

এই প্রজেক্টটি আপনার ফোনে এবং কম্পিউটারে সম্পূর্ণভাবে রান করার জন্য প্রস্তুত।

---

### অপশন ১: ফোনে সরাসরি ইনস্টল করার নিয়ম (PWA - সবচেয়ে সহজ পদ্ধতি)
কোনো অ্যান্ড্রয়েড স্টুডিও বা জটিল কোডিং ছাড়াই মাত্র ৫ সেকেন্ডে আপনার ফোনে অ্যাপ হিসেবে ইনস্টল করুন:
1. আপনার ফোন থেকে এই ব্রাউজার লিঙ্কে প্রবেশ করুন।
2. গুগল ক্রোম (Google Chrome) ব্রাউজারের উপরে ডানদিকের থ্রি-ডট (⋮) মেন্যুতে ক্লিক করুন।
3. **"Install app"** অথবা **"Add to Home screen" (হোম স্ক্রিনে যোগ করুন)** অপশনে ট্যাপ করুন।
4. সাথে সাথে আপনার মোবাইলের হোম স্ক্রিনে "Apex AI" এর অফিসিয়াল অ্যাপ আইকন যুক্ত হয়ে যাবে এবং এটি একটি পূর্ণাঙ্গ মোবাইল অ্যাপের মতো ফুলস্ক্রিনে চলবে!

---

### অপশন ২: কম্পিউটারে চালিয়ে ফোন দিয়ে লোকাল নেটওয়ার্কে রান করা
1. জিপ ফাইলটি আনজিপ (Extract) করুন।
2. ফোল্ডারে টার্মিনাল বা কমান্ড প্রম্পট (CMD) ওপেন করুন।
3. ডিপেন্ডেন্সি ইনস্টল করুন:
   \`\`\`bash
   npm install
   \`\`\`
4. এআই ফিচারগুলোর জন্য আপনার \`.env\` ফাইলে \`GEMINI_API_KEY\` যুক্ত করুন:
   \`\`\`env
   GEMINI_API_KEY=your_gemini_api_key_here
   \`\`\`
5. সার্ভার স্টার্ট করুন:
   \`\`\`bash
   npm run dev
   \`\`\`
6. এখন টার্মিনালে প্রদর্শিত Network URL (যেমন: \`http://192.168.x.x:3000\`) আপনার ফোনের ব্রাউজারে টাইপ করলে আপনার ফোনেই অ্যাপটি চলবে!

---

### অপশন ৩: Capacitor দিয়ে অ্যান্ড্রয়েড APK অ্যাপ (.apk) তৈরি করার নিয়ম
আপনি যদি এটিকে গুগল প্লে-স্টোর বা সরাসরি ফোনে ইনস্টলযোগ্য .apk বানাতে চান:
1. প্রজেক্ট ফোল্ডারে টার্মিনাল ওপেন করে প্রজেক্ট বিল্ড করুন:
   \`\`\`bash
   npm run build
   \`\`\`
2. Capacitor ইনস্টল করুন:
   \`\`\`bash
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "ApexAI" "com.apex.ai.assistant" --web-dir dist
   \`\`\`
3. অ্যান্ড্রয়েড প্ল্যাটফর্ম যুক্ত করুন:
   \`\`\`bash
   npx cap add android
   npx cap copy
   npx cap open android
   \`\`\`
4. Android Studio ওপেন হবে। সেখান থেকে \`Build > Build Bundle(s) / APK(s) > Build APK\` ক্লিক করলেই আপনার কাঙ্ক্ষিত .apk ফাইল তৈরি হয়ে যাবে!

---

### অ্যাপের প্রধান ফিচারসমূহ:
1. **পার্সোনাল এআই অ্যাসিস্ট্যান্ট**: যেকোনো প্রশ্নের উত্তর, ভয়েস কমান্ড এবং ফোন অ্যাপ লঞ্চার (ইউটিউব, হোয়াটসঅ্যাপ, ক্যালকুলেটর ইত্যাদি)।
2. **পরবর্তী ক্যান্ডেল প্রেডিকশন**: চার্টের যে কোনো স্ক্রিনশট আপলোড করে এআই দিয়ে পরবর্তী ক্যান্ডেল (CALL/PUT) এবং উইন কনফিডেন্স জানা।
3. **ট্রেডিং জগতের ৩০টি ধাপ**: বাইনারি ও ফরেক্স ট্রেডিংয়ের প্রাইজ অ্যাকশন, এসএমসি (SMC), এফভিজি (FVG), অর্ডার ব্লক এবং সাইকোলজির পূর্ণাঙ্গ গাইড।
4. **লাইভ ক্যান্ডেলস্টিক চার্ট ও রাডার**: রিয়েলটাইম ক্যান্ডেল মুভমেন্ট এবং ডায়নামিক টেকনিক্যাল সিগন্যাল।
`;

  zip.file('README-MOBILE-SETUP.md', readmeContent);

  // 2. package.json
  const packageJson = {
    name: 'apex-ai-trading-assistant',
    private: true,
    version: '1.0.0',
    type: 'module',
    scripts: {
      dev: 'vite --port=3000 --host=0.0.0.0',
      build: 'vite build',
      start: 'node server.ts',
      preview: 'vite preview',
    },
    dependencies: {
      '@google/genai': '^2.4.0',
      '@tailwindcss/vite': '^4.1.14',
      '@vitejs/plugin-react': '^5.0.4',
      dotenv: '^17.2.3',
      express: '^4.21.2',
      jszip: '^3.10.1',
      'lucide-react': '^0.546.0',
      motion: '^12.23.24',
      react: '^19.0.1',
      'react-dom': '^19.0.1',
      tailwindcss: '^4.1.14',
      vite: '^6.2.3',
      'vite-plugin-pwa': '^1.2.0',
    },
    devDependencies: {
      '@types/express': '^4.17.21',
      '@types/node': '^22.14.0',
      typescript: '~5.8.2',
    },
  };
  zip.file('package.json', JSON.stringify(packageJson, null, 2));

  // 3. .env.example
  zip.file(
    '.env.example',
    `# Google Gemini API Key
GEMINI_API_KEY=your_gemini_api_key_here
PORT=3000
`
  );

  // 4. manifest.json
  const manifest = {
    id: '/',
    name: 'Apex AI - Personal Assistant & Trading Intelligence',
    short_name: 'ApexAI',
    description: 'Smart AI Personal Assistant with 30-step trading mastery and next candle predictions',
    start_url: '/',
    display: 'standalone',
    theme_color: '#090d16',
    background_color: '#090d16',
  };
  zip.file('public/manifest.json', JSON.stringify(manifest, null, 2));

  // 5. Build full zip archive
  return await zip.generateAsync({ type: 'blob' });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
