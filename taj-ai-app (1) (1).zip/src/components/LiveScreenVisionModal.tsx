import React, { useState, useRef, useEffect } from 'react';
import {
  Monitor,
  Camera,
  X,
  Sparkles,
  Send,
  Mic,
  MicOff,
  CheckCircle,
  AlertCircle,
  Eye,
  RefreshCw,
  Image as ImageIcon,
  Volume2,
} from 'lucide-react';
import { AppLanguage } from '../types/trading';
import { soundFx } from '../utils/soundEffects';

interface LiveScreenVisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
  onSendVisionQuery: (query: string, imageBase64: string) => Promise<string | void>;
  isVoiceSpeaking?: boolean;
}

export const LiveScreenVisionModal: React.FC<LiveScreenVisionModalProps> = ({
  isOpen,
  onClose,
  language,
  onSendVisionQuery,
  isVoiceSpeaking = false,
}) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedSnapshot, setCapturedSnapshot] = useState<string | null>(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [promptInput, setPromptInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [latestAnalysis, setLatestAnalysis] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isListeningVoice, setIsListeningVoice] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const recognitionRef = useRef<any>(null);

  // Set up Speech Recognition for voice queries in Vision modal
  useEffect(() => {
    if (typeof window !== 'undefined' && isOpen) {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = language === 'bn' ? 'bn-BD' : 'en-US';

        recognition.onstart = () => {
          setIsListeningVoice(true);
          soundFx.playBeep();
        };

        recognition.onresult = (event: any) => {
          const text = event.results[0][0].transcript;
          if (text) {
            setPromptInput(text);
            handleAnalyzeCurrentFrame(text);
          }
        };

        recognition.onerror = () => setIsListeningVoice(false);
        recognition.onend = () => setIsListeningVoice(false);
        recognitionRef.current = recognition;
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, [language, isOpen]);

  // Clean up streams when modal closes
  useEffect(() => {
    if (!isOpen && stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
      setIsScreenSharing(false);
    }
  }, [isOpen, stream]);

  // Start live screen capture
  const handleStartScreenShare = async () => {
    setErrorMsg(null);
    try {
      soundFx.playBeep();
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        throw new Error(
          language === 'bn'
            ? 'আপনার ব্রাউজারে লাইভ ডিসপ্লে শেয়ারিং সমর্থিত নয়। দয়া করে নিচের "স্ক্রিনশট আপলোড" বাটন ব্যবহার করুন।'
            : 'DisplayMedia is not supported on this browser. Please use the "Upload Screenshot" option below.'
        );
      }

      const mediaStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
        },
        audio: false,
      });

      setStream(mediaStream);
      setIsScreenSharing(true);

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
      }

      mediaStream.getVideoTracks()[0].onended = () => {
        setIsScreenSharing(false);
        setStream(null);
      };
    } catch (err: any) {
      console.warn('Screen share error:', err);
      setErrorMsg(
        err.message ||
          (language === 'bn'
            ? 'স্ক্রিন শেয়ারিং চালু করা যায়নি। আপনি স্ক্রিনশট ফাইল আপলোড করেও এআই-কে দেখাতে পারেন।'
            : 'Could not start screen sharing. You can also upload a screenshot instead.')
      );
    }
  };

  // Stop sharing
  const handleStopScreenShare = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
      setIsScreenSharing(false);
    }
  };

  // Capture current frame from video
  const captureFrameFromVideo = (): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return null;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedSnapshot(dataUrl);
    return dataUrl;
  };

  // Handle file screenshot upload fallback
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const b64 = ev.target?.result as string;
      if (b64) {
        setCapturedSnapshot(b64);
        soundFx.playBeep();
      }
    };
    reader.readAsDataURL(file);
  };

  // Trigger analysis of current frame
  const handleAnalyzeCurrentFrame = async (overridePrompt?: string) => {
    const query = overridePrompt || promptInput.trim() || (language === 'bn' ? 'আমার স্ক্রিনে কি দেখা যাচ্ছে বিস্তারিত বলো এবং কমেন্ট/পোস্ট পড়ে শোনাও।' : 'Look at my screen and tell me what is happening, read any comments or charts.');

    let imagePayload = capturedSnapshot;
    if (isScreenSharing && videoRef.current) {
      const freshFrame = captureFrameFromVideo();
      if (freshFrame) imagePayload = freshFrame;
    }

    if (!imagePayload) {
      setErrorMsg(
        language === 'bn'
          ? 'অনুগ্রহ করে প্রথমে স্ক্রিন শেয়ার চালু করুন অথবা একটি স্ক্রিনশট আপলোড করুন।'
          : 'Please start screen sharing or upload a screenshot first.'
      );
      return;
    }

    try {
      setIsAnalyzing(true);
      setErrorMsg(null);
      soundFx.playBeep();

      const reply = await onSendVisionQuery(query, imagePayload);
      if (reply) {
        setLatestAnalysis(reply);
      }
    } catch (err: any) {
      console.error('Vision analysis error:', err);
      setErrorMsg(language === 'bn' ? 'স্ক্রিন ভিশন এনালাইসিসে ত্রুটি হয়েছে।' : 'Error analyzing screen.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Trigger voice recognition
  const toggleVoiceListen = () => {
    if (isListeningVoice) {
      recognitionRef.current?.stop();
      setIsListeningVoice(false);
    } else {
      try {
        recognitionRef.current?.start();
      } catch (e) {
        setIsListeningVoice(false);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-[#0b0f19] border border-slate-800 w-full max-w-3xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                {language === 'bn' ? 'এআই লাইভ স্ক্রিন ভিশন (Screen Vision)' : 'AI Live Screen Vision'}
                <span className="px-2 py-0.2 rounded-full text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Multimodal 3.8
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'bn'
                  ? 'ভিডিওর মতো এআই আপনার সম্পূর্ণ স্ক্রিন, টিকটক/ফেসবুক কমেন্ট বা ট্রেডিং চার্ট রিয়েল-টাইমে দেখতে পারবে।'
                  : 'Just like in the video, AI can watch your screen, read social comments, or analyze trading charts.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Screen / Video Display Area */}
          <div className="relative rounded-xl border border-slate-800 bg-slate-950 min-h-[220px] max-h-[340px] flex items-center justify-center overflow-hidden">
            {isScreenSharing ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-contain max-h-[340px]"
              />
            ) : capturedSnapshot ? (
              <img
                src={capturedSnapshot}
                alt="Captured Screen"
                className="w-full h-full object-contain max-h-[340px]"
              />
            ) : (
              <div className="text-center p-6 space-y-3">
                <div className="w-14 h-14 mx-auto rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400">
                  <Monitor className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-200">
                    {language === 'bn' ? 'স্ক্রিন ভিশন সক্রিয় নেই' : 'Screen Vision is Idle'}
                  </h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                    {language === 'bn'
                      ? 'নিচের বাটনে চাপ দিয়ে স্ক্রিন শেয়ার চালু করুন অথবা টিকটক/ফেসবুকের স্ক্রিনশট আপলোড করুন।'
                      : 'Click below to share your screen or upload a screenshot to inspect.'}
                  </p>
                </div>
              </div>
            )}

            {/* Sharing Status Badge */}
            {isScreenSharing && (
              <div className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/80 text-emerald-300 text-[10px] font-mono flex items-center gap-1.5 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                <span>{language === 'bn' ? 'স্ক্রিন ভিশন লাইভ' : 'Screen Vision LIVE'}</span>
              </div>
            )}
          </div>

          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {!isScreenSharing ? (
                <button
                  onClick={handleStartScreenShare}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-900/30 transition-all"
                >
                  <Monitor className="w-4 h-4" />
                  {language === 'bn' ? 'লাইভ স্ক্রিন শেয়ার শুরু করুন' : 'Start Live Screen Share'}
                </button>
              ) : (
                <button
                  onClick={handleStopScreenShare}
                  className="px-3.5 py-2 rounded-xl bg-rose-600/80 hover:bg-rose-500 text-white font-medium text-xs flex items-center gap-1.5 transition-all"
                >
                  <X className="w-4 h-4" />
                  {language === 'bn' ? 'শেয়ারিং বন্ধ করুন' : 'Stop Screen Share'}
                </button>
              )}

              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />

              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs flex items-center gap-1.5 transition-colors"
              >
                <ImageIcon className="w-4 h-4 text-cyan-400" />
                {language === 'bn' ? 'স্ক্রিনশট আপলোড' : 'Upload Screenshot'}
              </button>
            </div>

            {isScreenSharing && (
              <button
                onClick={() => captureFrameFromVideo()}
                className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs flex items-center gap-1 hover:text-cyan-400"
              >
                <Camera className="w-3.5 h-3.5" />
                {language === 'bn' ? 'ফ্রেম ফ্রিজ' : 'Snapshot'}
              </button>
            )}
          </div>

          {/* Quick preset questions */}
          <div className="space-y-1.5">
            <span className="text-[11px] text-slate-400">
              {language === 'bn' ? 'দ্রুত প্রশ্ন করুন (ভিডিওর মতো):' : 'Quick Prompt Presets:'}
            </span>
            <div className="flex flex-wrap gap-1.5">
              {[
                {
                  labelBn: '💬 স্ক্রিনের কমেন্টগুলো পড়ে বলো',
                  labelEn: '💬 Read comments on screen',
                  prompt: language === 'bn' ? 'আমার স্ক্রিনের কমেন্ট এবং রিপ্লাইগুলো পড়ে শোনান এবং মন্তব্য করুন।' : 'Read and summarize the comments and replies visible on screen.',
                },
                {
                  labelBn: '👤 এই প্রোফাইল বা ভিডিও সম্পর্কে কি বুঝছ?',
                  labelEn: '👤 Analyze this profile/video',
                  prompt: language === 'bn' ? 'স্ক্রিনের প্রোফাইল, ফলোয়ার ও ভিডিও কনটেন্ট দেখে বিস্তারিত রিভিউ দিন।' : 'Review the profile details and video shown on the screen.',
                },
                {
                  labelBn: '📊 চার্টের পরবর্তী ক্যান্ডেল প্রেডিক্ট কর',
                  labelEn: '📊 Predict next candle from chart',
                  prompt: language === 'bn' ? 'স্ক্রিনের ক্যান্ডেলস্টিক চার্টটি দেখে ৩০টি রুল অনুযায়ী পরের ক্যান্ডেল CALL নাকি PUT হবে কনফিডেন্স সহ প্রেডিক্ট করুন।' : 'Analyze the candlestick chart on screen and predict CALL or PUT with confidence.',
                },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPromptInput(item.prompt);
                    handleAnalyzeCurrentFrame(item.prompt);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 hover:text-white transition-colors"
                >
                  {language === 'bn' ? item.labelBn : item.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Query input box */}
          <div className="flex items-center gap-2">
            <div className="flex-1 relative">
              <input
                type="text"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAnalyzeCurrentFrame()}
                placeholder={
                  language === 'bn'
                    ? 'এআই-কে বলুন স্ক্রিনের কী দেখতে চান (যেমন: কমেন্টটা পড়)...'
                    : 'Ask AI what to check on your screen (e.g. read comment)...'
                }
                className="w-full pl-3 pr-10 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500"
              />
              <button
                onClick={toggleVoiceListen}
                className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-colors ${
                  isListeningVoice
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
                title={language === 'bn' ? 'ভয়েস দিয়ে প্রশ্ন করুন' : 'Ask with voice'}
              >
                {isListeningVoice ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </button>
            </div>

            <button
              onClick={() => handleAnalyzeCurrentFrame()}
              disabled={isAnalyzing}
              className="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-medium text-sm flex items-center gap-1.5 shadow-lg shadow-cyan-900/40 transition-all"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{language === 'bn' ? 'দেখছে...' : 'Analyzing...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>{language === 'bn' ? 'বিশ্লেষণ কর' : 'Inspect'}</span>
                </>
              )}
            </button>
          </div>

          {/* Latest Analysis Result Card */}
          {latestAnalysis && (
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-cyan-500/30 space-y-1.5 shadow-lg">
              <div className="flex items-center justify-between text-xs font-semibold text-cyan-400">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  {language === 'bn' ? 'তাজ (TAJ) / এআই রেসপন্স:' : 'TAJ / AI Vision Response:'}
                </span>
                {isVoiceSpeaking && (
                  <span className="flex items-center gap-1 text-[11px] text-emerald-400 animate-pulse">
                    <Volume2 className="w-3 h-3" />
                    {language === 'bn' ? 'ভয়েসে বলছে...' : 'Speaking aloud...'}
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {latestAnalysis}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
