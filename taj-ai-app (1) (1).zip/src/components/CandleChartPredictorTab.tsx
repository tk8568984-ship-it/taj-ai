import React, { useState, useEffect, useRef } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Clock,
  Sparkles,
  Sliders,
  RefreshCw,
  Zap,
  Play,
  Pause,
  Layers,
  ShieldCheck,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { AppLanguage, CandleData } from '../types/trading';
import { soundFx } from '../utils/soundEffects';

interface CandleChartPredictorTabProps {
  language: AppLanguage;
  onNavigateToScan: () => void;
}

const ASSETS = [
  { id: 'EUR/USD (OTC)', name: 'EUR/USD (OTC)', base: 1.0845, payout: 92 },
  { id: 'GBP/USD', name: 'GBP/USD', base: 1.278, payout: 88 },
  { id: 'USD/JPY', name: 'USD/JPY', base: 154.2, payout: 87 },
  { id: 'Gold XAU/USD', name: 'Gold (XAU/USD)', base: 2645.0, payout: 90 },
  { id: 'BTC/USDT', name: 'BTC/USDT', base: 88450.0, payout: 85 },
  { id: 'AUD/CAD (OTC)', name: 'AUD/CAD (OTC)', base: 0.892, payout: 93 },
];

export const CandleChartPredictorTab: React.FC<CandleChartPredictorTabProps> = ({
  language,
  onNavigateToScan,
}) => {
  const [selectedAsset, setSelectedAsset] = useState(ASSETS[0]);
  const [timeframeSeconds, setTimeframeSeconds] = useState(60); // 1-minute default
  const [countdown, setCountdown] = useState(60);
  const [isPaused, setIsPaused] = useState(false);
  const [showEma, setShowEma] = useState(true);
  const [showBollinger, setShowBollinger] = useState(true);

  // Live candles state
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [currentPrice, setCurrentPrice] = useState(ASSETS[0].base);
  const [priceChange, setPriceChange] = useState(0.04);

  // Live next candle radar prediction state
  const [liveSignal, setLiveSignal] = useState<'CALL' | 'PUT' | 'WAIT'>('CALL');
  const [confidence, setConfidence] = useState(86);
  const [activePattern, setActivePattern] = useState('Bullish Hammer Rejection at EMA 20');
  const [entryAdvice, setEntryAdvice] = useState('Wait for 5-second downward pullback for margin of safety entry');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Initialize initial candle history
  useEffect(() => {
    let p = selectedAsset.base;
    const initialCandles: CandleData[] = [];
    const now = Date.now();

    for (let i = 24; i >= 0; i--) {
      const open = p;
      const variation = (Math.random() - 0.48) * (selectedAsset.base * 0.0008);
      const close = open + variation;
      const high = Math.max(open, close) + Math.random() * (selectedAsset.base * 0.0004);
      const low = Math.min(open, close) - Math.random() * (selectedAsset.base * 0.0004);
      p = close;

      initialCandles.push({
        time: new Date(now - i * timeframeSeconds * 1000).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
        timestamp: now - i * timeframeSeconds * 1000,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 800) + 200,
        isBullish: close >= open,
      });
    }

    setCandles(initialCandles);
    setCurrentPrice(p);
    setCountdown(timeframeSeconds);
  }, [selectedAsset, timeframeSeconds]);

  // Real-time ticking engine
  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setCountdown((prevCount) => {
        if (prevCount <= 1) {
          // Finish current candle and push new candle
          setCandles((prevCandles) => {
            const last = prevCandles[prevCandles.length - 1];
            if (!last) return prevCandles;

            const newOpen = last.close;
            const newCandle: CandleData = {
              time: new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              }),
              timestamp: Date.now(),
              open: newOpen,
              high: newOpen,
              low: newOpen,
              close: newOpen,
              volume: 100,
              isBullish: true,
            };

            const updated = [...prevCandles.slice(1), newCandle];

            // Evaluate new AI live prediction for this new candle
            evaluateNextCandleForecast(updated);

            return updated;
          });

          return timeframeSeconds;
        }

        // Intra-candle price tick
        const tickMove = (Math.random() - 0.49) * (selectedAsset.base * 0.0002);
        setCurrentPrice((prevPrice) => {
          const nextPrice = Number((prevPrice + tickMove).toFixed(selectedAsset.base > 100 ? 2 : 5));

          setCandles((prevCandles) => {
            if (prevCandles.length === 0) return prevCandles;
            const lastIdx = prevCandles.length - 1;
            const last = prevCandles[lastIdx];

            const newHigh = Math.max(last.high, nextPrice);
            const newLow = Math.min(last.low, nextPrice);
            const isBull = nextPrice >= last.open;

            const updatedCandles = [...prevCandles];
            updatedCandles[lastIdx] = {
              ...last,
              high: newHigh,
              low: newLow,
              close: nextPrice,
              volume: last.volume + Math.floor(Math.random() * 5),
              isBullish: isBull,
            };

            return updatedCandles;
          });

          return nextPrice;
        });

        return prevCount - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPaused, selectedAsset, timeframeSeconds]);

  // Evaluate dynamic next candle radar
  const evaluateNextCandleForecast = (candleList: CandleData[]) => {
    if (candleList.length < 5) return;
    const last = candleList[candleList.length - 1];
    const prev = candleList[candleList.length - 2];

    const body = Math.abs(last.close - last.open);
    const lowerWick = Math.min(last.open, last.close) - last.low;
    const upperWick = last.high - Math.max(last.open, last.close);

    if (lowerWick > body * 1.5) {
      // Long lower wick rejection -> Bullish CALL
      setLiveSignal('CALL');
      setConfidence(Math.floor(Math.random() * 9) + 84);
      setActivePattern('Bullish Pinbar / Hammer Rejection (লোয়ার উইক বাউন্স)');
      setEntryAdvice(
        language === 'bn'
          ? 'ক্যান্ডেলের শুরুতে সামান্য নিচে নামলে CALL এন্ট্রি নিন (Margin of Safety)।'
          : 'Wait for a 2-pip downward dip before executing CALL.'
      );
      soundFx.playCallSignal();
    } else if (upperWick > body * 1.5) {
      // Long upper wick rejection -> Bearish PUT
      setLiveSignal('PUT');
      setConfidence(Math.floor(Math.random() * 8) + 83);
      setActivePattern('Shooting Star / Upper Wick Rejection (আপার উইক রিজেকশন)');
      setEntryAdvice(
        language === 'bn'
          ? 'ক্যান্ডেলের শুরুতে সামান্য উপরে উঠলে PUT এন্ট্রি নিন।'
          : 'Wait for a minor upward jump before executing PUT.'
      );
      soundFx.playPutSignal();
    } else if (last.isBullish && prev.isBullish) {
      setLiveSignal('CALL');
      setConfidence(80);
      setActivePattern('Momentum Continuation (বুলিশ ট্রেন্ড কন্টিনিউ)');
      setEntryAdvice(
        language === 'bn'
          ? 'ট্রেন্ডের সাথে ১-মিনিট CALL ট্রেড বজায় রাখুন।'
          : 'Trade with strong upward momentum.'
      );
    } else {
      setLiveSignal('PUT');
      setConfidence(79);
      setActivePattern('Bearish Pressure (সেলারদের চাপ)');
      setEntryAdvice(
        language === 'bn'
          ? 'রেজিস্ট্যান্সের নিচে PUT এন্ট্রি নিরাপদ।'
          : 'Look for PUT entries below dynamic resistance.'
      );
    }
  };

  // Draw Candlestick Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || candles.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#080c15';
    ctx.fillRect(0, 0, width, height);

    // Calculate min/max price for scaling
    const prices = candles.flatMap((c) => [c.high, c.low]);
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    const priceRange = maxPrice - minPrice || 1;
    const paddingY = 40;
    const chartHeight = height - paddingY * 2;

    const getY = (price: number) => {
      return height - paddingY - ((price - minPrice) / priceRange) * chartHeight;
    };

    // Draw grid lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 0.75;
    ctx.setLineDash([3, 4]);

    for (let i = 1; i <= 5; i++) {
      const y = paddingY + (chartHeight / 6) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width - 65, y);
      ctx.stroke();

      const priceAtY = maxPrice - (i / 6) * priceRange;
      ctx.fillStyle = '#64748b';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.fillText(priceAtY.toFixed(selectedAsset.base > 100 ? 1 : 5), width - 60, y + 3);
    }
    ctx.setLineDash([]);

    // Calculate EMA 20
    const ema20Points: { x: number; y: number }[] = [];
    let k = 2 / (14 + 1);
    let ema = candles[0].close;

    // Draw Candlesticks
    const candleWidth = (width - 70) / candles.length;
    const candleSpacing = candleWidth * 0.35;
    const barWidth = candleWidth - candleSpacing;

    candles.forEach((candle, idx) => {
      const xCenter = idx * candleWidth + candleWidth / 2;
      const yOpen = getY(candle.open);
      const yClose = getY(candle.close);
      const yHigh = getY(candle.high);
      const yLow = getY(candle.low);

      ema = candle.close * k + ema * (1 - k);
      ema20Points.push({ x: xCenter, y: getY(ema) });

      const isGreen = candle.close >= candle.open;
      const candleColor = isGreen ? '#10b981' : '#f43f5e';

      // Draw Wick
      ctx.strokeStyle = candleColor;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(xCenter, yHigh);
      ctx.lineTo(xCenter, yLow);
      ctx.stroke();

      // Draw Body
      ctx.fillStyle = candleColor;
      const topY = Math.min(yOpen, yClose);
      const bodyH = Math.max(Math.abs(yClose - yOpen), 2);
      ctx.fillRect(xCenter - barWidth / 2, topY, barWidth, bodyH);

      // Volume sub-bar at bottom
      const volH = (candle.volume / 1000) * 35;
      ctx.fillStyle = isGreen ? 'rgba(16, 185, 129, 0.25)' : 'rgba(244, 63, 94, 0.25)';
      ctx.fillRect(xCenter - barWidth / 2, height - volH, barWidth, volH);
    });

    // Draw EMA line
    if (showEma && ema20Points.length > 1) {
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 1.75;
      ctx.beginPath();
      ctx.moveTo(ema20Points[0].x, ema20Points[0].y);
      for (let i = 1; i < ema20Points.length; i++) {
        ctx.lineTo(ema20Points[i].x, ema20Points[i].y);
      }
      ctx.stroke();
    }

    // Draw Current Live Price line across chart
    const currentY = getY(currentPrice);
    ctx.strokeStyle = candles[candles.length - 1]?.isBullish ? '#10b981' : '#f43f5e';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 2]);
    ctx.beginPath();
    ctx.moveTo(0, currentY);
    ctx.lineTo(width, currentY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Live Price tag pill on right axis
    ctx.fillStyle = candles[candles.length - 1]?.isBullish ? '#10b981' : '#f43f5e';
    ctx.fillRect(width - 65, currentY - 9, 65, 18);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px JetBrains Mono, monospace';
    ctx.fillText(currentPrice.toFixed(selectedAsset.base > 100 ? 2 : 5), width - 62, currentY + 3);
  }, [candles, currentPrice, showEma, selectedAsset]);

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 space-y-4">
      {/* Top Asset & Payout Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-400">
              {language === 'bn' ? 'অ্যাসেট:' : 'Pair:'}
            </span>
            <select
              id="asset-selector"
              value={selectedAsset.id}
              onChange={(e) => {
                const found = ASSETS.find((a) => a.id === e.target.value);
                if (found) {
                  soundFx.playTick();
                  setSelectedAsset(found);
                }
              }}
              className="bg-slate-950 border border-slate-700 text-white font-bold rounded-xl px-3 py-1.5 text-xs sm:text-sm focus:outline-none focus:border-cyan-500"
            >
              {ASSETS.map((asset) => (
                <option key={asset.id} value={asset.id}>
                  {asset.name} ({asset.payout}% Payout)
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-400">{language === 'bn' ? 'বর্তমান প্রাইস:' : 'Price:'}</span>
            <span
              className={`font-bold text-sm ${
                candles[candles.length - 1]?.isBullish ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {currentPrice.toFixed(selectedAsset.base > 100 ? 2 : 5)}
            </span>
          </div>
        </div>

        {/* Timeframe & Candle Timer Countdown */}
        <div className="flex items-center gap-2">
          {/* Candle countdown timer */}
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono">
            <Clock className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="text-slate-400">{language === 'bn' ? 'ক্যান্ডেল বাকি:' : 'New Bar:'}</span>
            <span className="text-emerald-400 font-bold">
              00:{countdown < 10 ? `0${countdown}` : countdown}s
            </span>
          </div>

          {/* Timeframe selector */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-mono">
            {[10, 30, 60, 300].map((sec) => (
              <button
                key={sec}
                id={`tf-btn-${sec}`}
                onClick={() => {
                  soundFx.playTick();
                  setTimeframeSeconds(sec);
                }}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  timeframeSeconds === sec
                    ? 'bg-slate-800 text-cyan-400 font-bold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {sec < 60 ? `${sec}s` : `${sec / 60}m`}
              </button>
            ))}
          </div>

          {/* Pause / Play */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            title={isPaused ? 'Resume' : 'Pause'}
          >
            {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Grid: Live Candlestick Canvas + Radar Forecast Box */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: Interactive Canvas Chart (8 Cols) */}
        <div className="lg:col-span-8 rounded-2xl bg-slate-950 border border-slate-800 p-3 flex flex-col justify-between shadow-xl">
          <div className="flex items-center justify-between mb-2 px-1 text-xs">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 font-bold text-white">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                {selectedAsset.name}
              </span>
              <label className="flex items-center gap-1 text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={showEma}
                  onChange={(e) => setShowEma(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500"
                />
                <span className="text-[11px]">EMA 20</span>
              </label>
            </div>

            <span className="text-[11px] text-slate-500 font-mono">
              Volume & Price Action Matrix
            </span>
          </div>

          {/* Canvas */}
          <div className="relative w-full overflow-hidden rounded-xl bg-[#080c15]">
            <canvas
              ref={canvasRef}
              width={750}
              height={360}
              className="w-full h-[280px] sm:h-[340px] block"
            />
          </div>

          {/* Chart footer status */}
          <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400 px-1">
            <span>
              {language === 'bn'
                ? 'সরাসরি টিক অনুযায়ী ক্যান্ডেল আপডেট হচ্ছে'
                : 'Real-time synthetic candle stream'}
            </span>
            <button
              onClick={onNavigateToScan}
              className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
            >
              <span>{language === 'bn' ? 'স্ক্রিনশট আপলোড করে স্ক্যান করুন' : 'Scan Screenshot Instead'}</span>
              →
            </button>
          </div>
        </div>

        {/* Right: Live Next Candle Radar Signal Card (4 Cols) */}
        <div className="lg:col-span-4 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-4 space-y-4 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-bold uppercase tracking-wider font-mono">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>{language === 'bn' ? 'লাইভ ক্যান্ডেল সিগন্যাল' : 'Live Signal Radar'}</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
                Active
              </span>
            </div>

            {/* Glowing Big Signal Display */}
            <div className="mt-4 p-4 rounded-2xl bg-slate-950/80 border border-slate-800 text-center space-y-2">
              <span className="text-[10px] text-slate-400 uppercase font-mono block">
                {language === 'bn' ? 'পরবর্তী ক্যান্ডেলের দিক' : 'Predicted Next Bar Direction'}
              </span>

              <div className="flex items-center justify-center gap-2">
                {liveSignal === 'CALL' ? (
                  <div className="flex items-center gap-2 px-5 py-2 rounded-2xl bg-emerald-500/20 border-2 border-emerald-500 text-emerald-300 shadow-lg shadow-emerald-500/20">
                    <TrendingUp className="w-8 h-8 text-emerald-400" />
                    <span className="text-3xl font-black font-sans">CALL (UP)</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 px-5 py-2 rounded-2xl bg-rose-500/20 border-2 border-rose-500 text-rose-300 shadow-lg shadow-rose-500/20">
                    <TrendingDown className="w-8 h-8 text-rose-400" />
                    <span className="text-3xl font-black font-sans">PUT (DOWN)</span>
                  </div>
                )}
              </div>

              {/* Confidence Score */}
              <div className="pt-2 flex items-center justify-between text-xs px-2">
                <span className="text-slate-400">{language === 'bn' ? 'উইন সম্ভাবনা:' : 'Win Probability:'}</span>
                <span className="font-mono font-bold text-cyan-400 text-base">{confidence}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400"
                  style={{ width: `${confidence}%` }}
                ></div>
              </div>
            </div>

            {/* Detected Pattern */}
            <div className="mt-3.5 space-y-2">
              <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs">
                <span className="text-[10px] text-slate-400 block font-mono">
                  {language === 'bn' ? 'শনাক্তকৃত প্যাটার্ন:' : 'Pattern Detected:'}
                </span>
                <span className="font-semibold text-slate-200 block mt-0.5">{activePattern}</span>
              </div>

              {/* Entry Tip */}
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সেফ এন্ট্রি কৌশল:' : 'Safe Execution Advice:'}</span>
                </div>
                <p className="text-slate-300 text-xs leading-relaxed">{entryAdvice}</p>
              </div>
            </div>
          </div>

          {/* 5-Point Confluence Checklist mini bar */}
          <div className="pt-3 border-t border-slate-800/80 space-y-1.5">
            <span className="text-[10px] text-slate-400 font-mono uppercase block">
              {language === 'bn' ? '৫-পয়েন্ট কনফ্লুয়েন্স ভ্যালিডেশন' : '5-Point Confluence Status'}
            </span>
            <div className="grid grid-cols-5 gap-1 text-[9px] font-mono text-center">
              <div className="p-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                TREND ✓
              </div>
              <div className="p-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                SnR ✓
              </div>
              <div className="p-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                WICK ✓
              </div>
              <div className="p-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                EMA ✓
              </div>
              <div className="p-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                SAFETY ✓
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
