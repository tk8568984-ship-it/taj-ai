import React, { useEffect, useRef } from 'react';

interface DualHolographicOrbProps {
  isListening: boolean;
  isSpeaking: boolean;
  isSleeping?: boolean;
  statusText?: string;
  onOrbClick?: () => void;
  size?: 'normal' | 'compact';
}

interface Particle3D {
  x: number;
  y: number;
  z: number;
  baseRadius: number;
  size: number;
  speed: number;
  opacity: number;
}

export const DualHolographicOrb: React.FC<DualHolographicOrbProps> = ({
  isListening,
  isSpeaking,
  isSleeping = false,
  statusText,
  onOrbClick,
  size = 'normal',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const isCompact = size === 'compact';
  const canvasWidth = isCompact ? 180 : 320;
  const canvasHeight = isCompact ? 180 : 280;

  // Particle Sphere 3D simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Initialize 3D particles on a sphere
    const particleCount = isCompact ? 140 : 260;
    const sphereRadius = isCompact ? 55 : 95;
    const particles: Particle3D[] = [];

    for (let i = 0; i < particleCount; i++) {
      // Uniform spherical coordinates distribution
      const theta = Math.acos(2 * Math.random() - 1);
      const phi = Math.random() * Math.PI * 2;

      const x = sphereRadius * Math.sin(theta) * Math.cos(phi);
      const y = sphereRadius * Math.sin(theta) * Math.sin(phi);
      const z = sphereRadius * Math.cos(theta);

      particles.push({
        x,
        y,
        z,
        baseRadius: sphereRadius,
        size: Math.random() * 2.2 + 1.2,
        speed: (Math.random() * 0.006 + 0.004) * (Math.random() > 0.5 ? 1 : -1),
        opacity: Math.random() * 0.5 + 0.5,
      });
    }

    let angleX = 0;
    let angleY = 0;
    let pulsePhase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Rotation speeds change dynamically based on assistant state
      let rotSpeedX = 0.005;
      let rotSpeedY = 0.008;
      let pulseAmp = 1.0;

      if (isSleeping) {
        rotSpeedX = 0.001;
        rotSpeedY = 0.001;
        pulsePhase += 0.01;
        pulseAmp = 0.7 + Math.sin(pulsePhase) * 0.03;
      } else if (isSpeaking) {
        rotSpeedX = 0.015;
        rotSpeedY = 0.022;
        pulsePhase += 0.12;
        pulseAmp = 1.0 + Math.sin(pulsePhase) * 0.18;
      } else if (isListening) {
        rotSpeedX = 0.02;
        rotSpeedY = 0.012;
        pulsePhase += 0.18;
        pulseAmp = 1.0 + Math.sin(pulsePhase) * 0.25;
      } else {
        pulsePhase += 0.03;
        pulseAmp = 1.0 + Math.sin(pulsePhase) * 0.06;
      }

      angleX += rotSpeedX;
      angleY += rotSpeedY;

      // Radial glow behind particle sphere
      const gradient = ctx.createRadialGradient(
        centerX,
        centerY,
        10,
        centerX,
        centerY,
        sphereRadius * pulseAmp * 1.4
      );
      if (isSleeping) {
        gradient.addColorStop(0, 'rgba(100, 116, 139, 0.12)');
        gradient.addColorStop(0.7, 'rgba(15, 23, 42, 0.02)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (isSpeaking) {
        gradient.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
        gradient.addColorStop(0.6, 'rgba(34, 197, 94, 0.08)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (isListening) {
        gradient.addColorStop(0, 'rgba(239, 68, 68, 0.25)');
        gradient.addColorStop(0.6, 'rgba(244, 63, 94, 0.08)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else {
        gradient.addColorStop(0, 'rgba(34, 197, 94, 0.15)');
        gradient.addColorStop(0.7, 'rgba(16, 185, 129, 0.04)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, sphereRadius * pulseAmp * 1.4, 0, Math.PI * 2);
      ctx.fill();

      // Sort particles by Z-depth for 3D realism
      const cosX = Math.cos(angleX);
      const sinX = Math.sin(angleX);
      const cosY = Math.cos(angleY);
      const sinY = Math.sin(angleY);

      const projected = particles.map((p) => {
        // Rotate around Y
        let x1 = p.x * cosY + p.z * sinY;
        let y1 = p.y;
        let z1 = -p.x * sinY + p.z * cosY;

        // Rotate around X
        let x2 = x1;
        let y2 = y1 * cosX - z1 * sinX;
        let z2 = y1 * sinX + z1 * cosX;

        // Apply pulse
        x2 *= pulseAmp;
        y2 *= pulseAmp;
        z2 *= pulseAmp;

        // Perspective projection
        const fov = 350;
        const scale = fov / (fov + z2);
        const projX = centerX + x2 * scale;
        const projY = centerY + y2 * scale;

        return {
          projX,
          projY,
          scale,
          z: z2,
          size: p.size * scale,
          opacity: p.opacity * Math.max(0.2, (z2 + sphereRadius) / (sphereRadius * 2)),
        };
      });

      projected.sort((a, b) => a.z - b.z);

      // Draw each particle with vibrant neon green glow
      for (const pt of projected) {
        ctx.beginPath();
        ctx.arc(pt.projX, pt.projY, pt.size, 0, Math.PI * 2);

        if (isSleeping) {
          ctx.fillStyle = `rgba(148, 163, 184, ${pt.opacity * 0.4})`;
          ctx.shadowColor = '#475569';
        } else if (isListening) {
          ctx.fillStyle = `rgba(248, 113, 113, ${pt.opacity})`;
          ctx.shadowColor = '#ef4444';
        } else if (isSpeaking) {
          ctx.fillStyle = `rgba(74, 222, 128, ${pt.opacity})`;
          ctx.shadowColor = '#22c55e';
        } else {
          ctx.fillStyle = `rgba(52, 211, 153, ${pt.opacity * 0.9})`;
          ctx.shadowColor = '#10b981';
        }

        ctx.shadowBlur = pt.size > 2 ? 6 : 2;
        ctx.fill();
      }

      ctx.shadowBlur = 0;
      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [isListening, isSpeaking, isSleeping, isCompact]);

  return (
    <div
      onClick={onOrbClick}
      className="flex flex-col items-center justify-center select-none cursor-pointer group transition-all"
    >
      {/* 1. UPPER ATOMIC RED ORB (Exact match from the video) */}
      {!isCompact && !isSleeping && (
        <div className="relative mb-2 flex items-center justify-center">
          {/* Outer glowing halo */}
          <div className="absolute w-28 h-28 bg-rose-600/20 rounded-full blur-xl pointer-events-none animate-pulse"></div>

          {/* Atomic orbital rotating rings */}
          <div className="relative w-24 h-24 flex items-center justify-center">
            {/* Ring 1 - Elliptical tilt 45deg */}
            <div
              className={`absolute w-20 h-10 border border-rose-500/70 rounded-full shadow-[0_0_12px_rgba(244,63,94,0.4)] ${
                isSpeaking || isListening ? 'animate-[spin_2.5s_linear_infinite]' : 'animate-[spin_6s_linear_infinite]'
              }`}
              style={{ transform: 'rotate(45deg)' }}
            >
              <div className="w-1.5 h-1.5 bg-rose-300 rounded-full shadow-[0_0_8px_#ff4444] absolute -top-0.5 left-1/2"></div>
            </div>

            {/* Ring 2 - Elliptical tilt -45deg */}
            <div
              className={`absolute w-20 h-10 border border-red-400/60 rounded-full shadow-[0_0_10px_rgba(239,68,68,0.4)] ${
                isSpeaking || isListening ? 'animate-[spin_3s_linear_infinite_reverse]' : 'animate-[spin_8s_linear_infinite_reverse]'
              }`}
              style={{ transform: 'rotate(-45deg)' }}
            >
              <div className="w-1.5 h-1.5 bg-amber-200 rounded-full shadow-[0_0_8px_#ffa500] absolute -bottom-0.5 right-1/4"></div>
            </div>

            {/* Ring 3 - Horizontal Ring */}
            <div
              className={`absolute w-22 h-9 border border-rose-600/50 rounded-full shadow-[0_0_10px_rgba(225,29,72,0.3)] ${
                isSpeaking || isListening ? 'animate-[spin_2s_linear_infinite]' : 'animate-[spin_5s_linear_infinite]'
              }`}
            ></div>

            {/* Inner Red Core Nucleus */}
            <div
              className={`w-7 h-7 rounded-full bg-gradient-to-tr from-rose-700 via-red-500 to-amber-400 shadow-[0_0_18px_rgba(244,63,94,0.9)] flex items-center justify-center transition-transform duration-300 ${
                isSpeaking ? 'scale-125' : isListening ? 'scale-130' : 'scale-100'
              }`}
            >
              <div className="w-2 h-2 rounded-full bg-white/90 shadow-[0_0_6px_#ffffff]"></div>
            </div>
          </div>
        </div>
      )}

      {/* 2. AUDIO EQUALIZER WAVEFORM (between/above the orbs) */}
      {!isSleeping && (
        <div className="flex items-center gap-1 my-1 px-4 py-1">
          {[4, 8, 14, 22, 16, 26, 12, 18, 10, 5].map((h, i) => {
            let dynamicHeight = h;
            if (isSpeaking) {
              dynamicHeight = Math.min(28, Math.max(4, h * (1 + Math.sin(Date.now() / 150 + i))));
            } else if (isListening) {
              dynamicHeight = Math.min(30, Math.max(6, (i % 2 === 0 ? 24 : 10) * (1 + Math.cos(Date.now() / 120 + i))));
            } else {
              dynamicHeight = Math.max(3, h * 0.4);
            }

            return (
              <span
                key={i}
                className={`w-1 rounded-full transition-all duration-150 ${
                  isListening
                    ? 'bg-rose-500 shadow-[0_0_6px_#f43f5e]'
                    : isSpeaking
                    ? 'bg-emerald-400 shadow-[0_0_6px_#10b981]'
                    : 'bg-emerald-500/40'
                }`}
                style={{ height: `${dynamicHeight}px` }}
              />
            );
          })}
        </div>
      )}

      {/* 3. 3D GREEN PARTICLE SPHERE CANVAS (Signature MYRA visual from video) */}
      <div className="relative flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={canvasWidth}
          height={canvasHeight}
          className="rounded-full pointer-events-none drop-shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-transform duration-300 group-hover:scale-105"
        />

        {/* Center clickable microphone trigger button inside orb */}
        <div
          className={`absolute w-12 h-12 rounded-full border flex items-center justify-center backdrop-blur-md transition-all duration-300 shadow-xl ${
            isListening
              ? 'bg-rose-950/80 border-rose-500 text-rose-300 shadow-rose-600/50 scale-110'
              : isSpeaking
              ? 'bg-emerald-950/80 border-emerald-400 text-emerald-300 shadow-emerald-500/50 scale-105'
              : 'bg-slate-950/70 border-emerald-500/40 text-emerald-400 hover:border-emerald-400 group-hover:scale-110'
          }`}
        >
          <div
            className={`w-4 h-4 rounded-full transition-all ${
              isListening
                ? 'bg-rose-500 animate-ping'
                : isSpeaking
                ? 'bg-emerald-400 animate-pulse'
                : 'bg-emerald-500/80'
            }`}
          />
        </div>
      </div>

      {/* Status Pill beneath Orb */}
      {statusText && (
        <div className="mt-2 flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800 shadow-md">
          <span
            className={`w-2 h-2 rounded-full ${
              isListening
                ? 'bg-rose-500 animate-ping'
                : isSpeaking
                ? 'bg-emerald-400 animate-pulse'
                : 'bg-emerald-500'
            }`}
          />
          <span className="text-[11px] font-mono font-medium text-slate-300">
            {statusText}
          </span>
        </div>
      )}
    </div>
  );
};
