import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Flame,
  Zap,
  TrendingUp,
  Check,
} from 'lucide-react';
import { AppLanguage, TradingRule } from '../types/trading';
import { THIRTY_TRADING_STEPS } from '../data/thirtyTradingSteps';
import { soundFx } from '../utils/soundEffects';

interface ThirtyTradingStepsTabProps {
  language: AppLanguage;
  onNavigateToScan: () => void;
}

export const ThirtyTradingStepsTab: React.FC<ThirtyTradingStepsTabProps> = ({
  language,
  onNavigateToScan,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedRuleId, setExpandedRuleId] = useState<number | null>(1);

  // Pre-Trade 5-Point Confluence Checklist interactive state
  const [confluenceChecks, setConfluenceChecks] = useState({
    trend: true,
    level: true,
    candlestick: true,
    indicator: false,
    marginOfSafety: true,
  });

  const categories = [
    { id: 'all', nameBn: 'সব ধাপ (৩০টি)', nameEn: 'All 30 Steps' },
    { id: 'structure', nameBn: 'মার্কেট স্ট্রাকচার (১-৮)', nameEn: 'Structure (1-8)' },
    { id: 'smc', nameBn: 'এসএমসি ও লিকুইডিটি (৯-১৫)', nameEn: 'SMC & Liquidity (9-15)' },
    { id: 'indicators', nameBn: 'টেকনিক্যাল ইন্ডিকেটর (১৬-২১)', nameEn: 'Indicators (16-21)' },
    { id: 'binary', nameBn: 'বাইনারি ও ওটিসি (২২-২৫)', nameEn: 'Binary & OTC (22-25)' },
    { id: 'psychology', nameBn: 'রিস্ক ও সাইকোলজি (২৬-৩০)', nameEn: 'Psychology (26-30)' },
  ];

  const filteredRules = THIRTY_TRADING_STEPS.filter((rule) => {
    const matchesCategory = selectedCategory === 'all' || rule.category === selectedCategory;
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesCategory;

    const matchesSearch =
      rule.titleBn.toLowerCase().includes(query) ||
      rule.titleEn.toLowerCase().includes(query) ||
      rule.summaryBn.toLowerCase().includes(query) ||
      rule.detailsBn.toLowerCase().includes(query) ||
      rule.id.toString() === query;

    return matchesCategory && matchesSearch;
  });

  const toggleConfluence = (key: keyof typeof confluenceChecks) => {
    soundFx.playTick();
    setConfluenceChecks((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const checkedCount = Object.values(confluenceChecks).filter(Boolean).length;

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 space-y-5">
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-amber-950/20 to-slate-900 border border-slate-800 p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {language === 'bn' ? 'ট্রেডিং জগতের ৩০টি ধাপ (কমপ্লিট মাস্টারক্লাস)' : 'The 30 Golden Steps of Trading'}
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                100% Rules
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'bn'
                ? 'বাইনারি ও ফরেক্স ট্রেডিংয়ের প্রাইজ অ্যাকশন, এসএমসি, অর্ডার ব্লক, ওটিসি ট্র্যাপ এবং সাইকোলজির ৩০টি নীতি।'
                : 'Complete encyclopedia of 30 trading principles for consistent profitability.'}
            </p>
          </div>
        </div>

        <button
          onClick={onNavigateToScan}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-600/20 transition-all shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>{language === 'bn' ? 'চার্ট স্ক্যানারে টেস্ট করুন' : 'Test on Chart Scanner'}</span>
        </button>
      </div>

      {/* Interactive 5-Point Pre-Trade Confluence Calculator (Step 30 Feature) */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 space-y-3 shadow-lg">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">
              {language === 'bn' ? 'ধাপ ৩০: লাইভ ৫-পয়েন্ট কনফ্লুয়েন্স ক্যালকুলেটর' : 'Step 30: 5-Point Confluence Gatekeeper'}
            </h3>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">{language === 'bn' ? 'কনফ্লুয়েন্স স্কোর:' : 'Score:'}</span>
            <span
              className={`font-mono font-bold text-sm px-2 py-0.5 rounded-lg border ${
                checkedCount >= 4
                  ? 'bg-emerald-950 text-emerald-300 border-emerald-500'
                  : checkedCount === 3
                  ? 'bg-amber-950 text-amber-300 border-amber-500'
                  : 'bg-rose-950 text-rose-300 border-rose-500'
              }`}
            >
              {checkedCount} / 5 {checkedCount >= 4 ? 'A+ ট্রেড' : checkedCount === 3 ? 'রিস্কি' : 'নো-ট্রেড'}
            </span>
          </div>
        </div>

        {/* 5 Interactive Checkboxes */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 pt-1 text-xs">
          {[
            {
              id: 'trend',
              labelBn: '১. ট্রেন্ড পক্ষে আছে?',
              labelEn: '1. Trend Direction Aligned',
            },
            {
              id: 'level',
              labelBn: '২. কি-লেভেল (SnR/OB) প্রেজেন্ট?',
              labelEn: '2. Major Level Present',
            },
            {
              id: 'candlestick',
              labelBn: '৩. ক্যান্ডেল রিজেকশন উইক?',
              labelEn: '3. Rejection Wick / Pinbar',
            },
            {
              id: 'indicator',
              labelBn: '৪. EMA/RSI কনফার্মেশন?',
              labelEn: '4. EMA 20 / RSI Confluence',
            },
            {
              id: 'marginOfSafety',
              labelBn: '৫. মার্জিন অফ সেফটি এন্ট্রি?',
              labelEn: '5. Margin of Safety Pullback',
            },
          ].map((item) => {
            const isChecked = (confluenceChecks as any)[item.id];
            return (
              <button
                key={item.id}
                onClick={() => toggleConfluence(item.id as any)}
                className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                  isChecked
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span className="font-medium text-[11px]">
                  {language === 'bn' ? item.labelBn : item.labelEn}
                </span>
                <div
                  className={`w-4 h-4 rounded flex items-center justify-center text-[10px] ${
                    isChecked ? 'bg-emerald-500 text-slate-950 font-bold' : 'border border-slate-700'
                  }`}
                >
                  {isChecked && <Check className="w-3 h-3" />}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            id="trading-steps-search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              language === 'bn'
                ? 'যেকোনো ধাপ বা স্ট্র্যাটেজি খুঁজুন (যেমন: হ্যামার, এসএমসি, অর্ডার ব্লক, ওটিসি, ফিবোনাচ্চি)...'
                : 'Search any step or strategy (e.g. Hammer, SMC, Order Block, OTC, Fibonacci)...'
            }
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Categories Horizontal Scroll */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              id={`cat-filter-${cat.id}`}
              onClick={() => {
                soundFx.playTick();
                setSelectedCategory(cat.id);
              }}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {language === 'bn' ? cat.nameBn : cat.nameEn}
            </button>
          ))}
        </div>
      </div>

      {/* 30 Steps Cards List */}
      <div className="space-y-3">
        {filteredRules.map((rule) => {
          const isExpanded = expandedRuleId === rule.id;

          return (
            <div
              key={rule.id}
              id={`trading-step-card-${rule.id}`}
              className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                isExpanded
                  ? 'bg-slate-900/95 border-amber-500/40 shadow-xl'
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Card Header Accordion Trigger */}
              <div
                onClick={() => {
                  soundFx.playTick();
                  setExpandedRuleId(isExpanded ? null : rule.id);
                }}
                className="p-3.5 sm:p-4 cursor-pointer flex items-center justify-between gap-3 select-none"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 text-amber-400 font-mono font-bold text-xs flex items-center justify-center shrink-0">
                    #{rule.id}
                  </span>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                      <span>{language === 'bn' ? rule.titleBn : rule.titleEn}</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                      {language === 'bn' ? rule.summaryBn : rule.summaryEn}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 hidden sm:inline-block">
                    {rule.categoryBn}
                  </span>
                  <div className="p-1 rounded-lg bg-slate-800 text-slate-400">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </div>
              </div>

              {/* Expanded Card Details Body */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 space-y-3.5 text-xs">
                  {/* Detailed Description */}
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-slate-200 leading-relaxed whitespace-pre-line text-xs sm:text-sm">
                    {language === 'bn' ? rule.detailsBn : rule.detailsEn}
                  </div>

                  {/* 3 Key Checklist Points */}
                  <div className="space-y-1.5">
                    <span className="font-bold text-slate-300 block font-mono text-[11px] uppercase tracking-wider">
                      {language === 'bn' ? 'কার্যকরী চেকলিস্ট:' : 'Actionable Checklist:'}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {rule.keyChecklistBn.map((item, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-start gap-2"
                        >
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span className="text-slate-300 text-xs">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Pro Tip Golden Banner */}
                  <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-amber-300 font-semibold">
                      <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                      <span>{language === 'bn' ? rule.winTipBn : rule.winTipEn}</span>
                    </div>
                    <button
                      onClick={onNavigateToScan}
                      className="text-xs text-amber-400 hover:underline shrink-0 font-bold hidden sm:block"
                    >
                      {language === 'bn' ? 'চার্টে টেস্ট করুন' : 'Test on Chart'} →
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
