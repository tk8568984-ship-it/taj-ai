import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Eye,
  X,
  Maximize2,
  Volume2,
  Sparkles,
  Layers,
  ChevronDown,
} from 'lucide-react';
import { AppLanguage } from '../types/trading';
import { DualHolographicOrb } from './DualHolographicOrb';
import { soundFx } from '../utils/soundEffects';

interface FloatingOrbOverlayProps {
  isVisible: boolean;
  onToggleVisible: () => void;
  language: AppLanguage;
  isListening: boolean;
  isSpeaking: boolean;
  onToggleMic: () => void;
  onOpenScreenVision: () => void;
  statusText?: string;
}

export const FloatingOrbOverlay: React.FC<FloatingOrbOverlayProps> = ({
  isVisible,
  onToggleVisible,
  language,
  isListening,
  isSpeaking,
  onToggleMic,
  onOpenScreenVision,
  statusText,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [pipSupported, setPipSupported] = useState(false);
  const videoPipRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (typeof document !== 'undefined' && 'pictureInPictureEnabled' in document) {
      setPipSupported(true);
    }
  }, []);

  // Picture-in-Picture mode for the floating orb
  const handleLaunchPiP = async () => {
    try {
      soundFx.playBeep();
      // Create offscreen canvas stream to video element
      const canvas = document.createElement('canvas');
      canvas.width = 240;
      canvas.height = 240;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Draw green particle sphere in canvas
      let angle = 0;
      const stream = (canvas as any).captureStream ? (canvas as any).captureStream(30) : null;
      if (!stream) {
        alert(language === 'bn' ? 'আপনার ব্রাউজারে পিকচার-ইন-পিকচার সমর্থিত নয়।' : 'PiP stream not supported.');
        return;
      }

      const video = document.createElement('video');
      video.muted = true;
      video.srcObject = stream;
      await video.play();

      // Continuous loop animation in offscreen canvas
      const loop = () => {
        ctx.fillStyle = '#090d16';
        ctx.fillRect(0, 0, 240, 240);

        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(120, 120, 60 + Math.sin(angle) * 8, 0, Math.PI * 2);
        ctx.stroke();

        for (let i = 0; i < 40; i++) {
          const a = angle + (i * Math.PI) / 20;
          const r = 50 + (i % 5) * 6;
          ctx.fillStyle = '#34d399';
          ctx.beginPath();
          ctx.arc(120 + Math.cos(a) * r, 120 + Math.sin(a) * r, 2.5, 0, Math.PI * 2);
          ctx.fill();
        }

        angle += 0.05;
        requestAnimationFrame(loop);
      };
      loop();

      await video.requestPictureInPicture();
    } catch (e: any) {
      console.warn('PiP error:', e);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 select-none animate-fadeIn">
      {!isExpanded ? (
        // Compact floating green particle bubble (matches the video when app is minimized)
        <div className="relative group flex items-center">
          {/* Outer glowing ripple */}
          <div
            className={`absolute -inset-1.5 rounded-full blur-md transition-all ${
              isListening
                ? 'bg-rose-500/50 animate-ping'
                : isSpeaking
                ? 'bg-emerald-500/50 animate-pulse'
                : 'bg-emerald-500/30 group-hover:bg-emerald-500/50'
            }`}
          />

          <button
            onClick={() => {
              soundFx.playBeep();
              setIsExpanded(true);
            }}
            className="relative w-16 h-16 rounded-full bg-[#090d16] border-2 border-emerald-500/80 shadow-[0_0_20px_rgba(16,185,129,0.5)] flex items-center justify-center p-1 transition-transform group-hover:scale-105"
            title={language === 'bn' ? 'ভাসমান এআই অর্ব (ক্লিক করুন)' : 'Floating AI Orb (Click to expand)'}
          >
            <DualHolographicOrb
              isListening={isListening}
              isSpeaking={isSpeaking}
              size="compact"
            />
          </button>
        </div>
      ) : (
        // Expanded control panel
        <div className="w-72 bg-[#090d16]/95 border border-emerald-500/40 rounded-2xl p-4 shadow-2xl backdrop-blur-xl space-y-3 animate-scaleUp">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-bold text-emerald-400 font-sans">
                {language === 'bn' ? 'ভাসমান এআই অ্যাসিস্ট্যান্ট' : 'Floating AI Overlay'}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setIsExpanded(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
                title={language === 'bn' ? 'মিনিমাইজ' : 'Minimize'}
              >
                <ChevronDown className="w-4 h-4" />
              </button>
              <button
                onClick={onToggleVisible}
                className="p-1 text-slate-400 hover:text-rose-400 rounded-lg transition-colors"
                title={language === 'bn' ? 'বন্ধ করুন' : 'Close'}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Mini Dual Orb Visualizer */}
          <div className="flex justify-center py-1">
            <DualHolographicOrb
              isListening={isListening}
              isSpeaking={isSpeaking}
              size="compact"
              statusText={statusText}
            />
          </div>

          {/* Controls Bar */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={onToggleMic}
              className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 transition-all ${
                isListening
                  ? 'bg-rose-600 border-rose-500 text-white animate-pulse shadow-lg shadow-rose-900/50'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-emerald-500/60'
              }`}
            >
              {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-slate-400" />}
              <span>{isListening ? (language === 'bn' ? 'শুনছি...' : 'Listening') : (language === 'bn' ? 'ভয়েস বলুন' : 'Speak')}</span>
            </button>

            <button
              onClick={onOpenScreenVision}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/60 text-slate-300 hover:text-white text-xs font-medium flex items-center justify-center gap-2 transition-all"
            >
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>{language === 'bn' ? 'স্ক্রিন ভিশন' : 'Screen Vision'}</span>
            </button>
          </div>

          {pipSupported && (
            <button
              onClick={handleLaunchPiP}
              className="w-full py-2 rounded-xl bg-emerald-950/60 border border-emerald-500/30 hover:bg-emerald-900/40 text-emerald-300 text-[11px] font-medium flex items-center justify-center gap-1.5 transition-colors"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'পিকচার-ইন-পিকচার (স্ক্রিনে ভাসিয়ে রাখুন)' : 'Picture-in-Picture Float'}</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
