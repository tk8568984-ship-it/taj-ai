import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Sparkles,
  Volume2,
  VolumeX,
  ExternalLink,
  Youtube,
  MessageCircle,
  MessageSquare,
  Send,
  TrendingUp,
  Calculator,
  Camera,
  MapPin,
  Phone,
  Settings,
  Zap,
  Eye,
  Layers,
  Home,
  Sliders,
  Bell,
  Edit2,
  Download,
  Check,
  RefreshCw,
  Video,
  Share2,
  Power,
  Wifi,
  Battery,
  Radio,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  Play,
  Pause,
} from 'lucide-react';
import { AppLanguage, CandleData } from '../types/trading';
import { PHONE_APPS } from '../data/phoneApps';
import { soundFx } from '../utils/soundEffects';
import { DualHolographicOrb } from './DualHolographicOrb';
import { LiveScreenVisionModal } from './LiveScreenVisionModal';
import { FloatingOrbOverlay } from './FloatingOrbOverlay';

interface VoiceAssistantTabProps {
  language: AppLanguage;
  onNavigateToScan?: () => void;
  onNavigateToSteps?: () => void;
}

type SubNavTab = 'home' | 'chat' | 'chart' | 'apps' | 'settings';

interface ChatMessage {
  id: string;
  sender: 'user' | 'taj';
  text: string;
  time: string;
}

const ASSETS = [
  { id: 'EUR/USD (OTC)', name: 'EUR/USD (OTC)', base: 1.0845, payout: 92 },
  { id: 'GBP/USD', name: 'GBP/USD', base: 1.278, payout: 88 },
  { id: 'USD/JPY', name: 'USD/JPY', base: 154.2, payout: 87 },
  { id: 'Gold XAU/USD', name: 'Gold (XAU/USD)', base: 2645.0, payout: 90 },
  { id: 'BTC/USDT', name: 'BTC/USDT', base: 88450.0, payout: 85 },
  { id: 'AUD/CAD (OTC)', name: 'AUD/CAD (OTC)', base: 0.892, payout: 93 },
];

export const VoiceAssistantTab: React.FC<VoiceAssistantTabProps> = ({
  language,
}) => {
  // Navigation tabs: Home (Phone OS) | Chart (Market Vision) | Apps | Settings
  const [subTab, setSubTab] = useState<SubNavTab>('home');

  // User Profile Name (defaults to "Tabrej" as requested)
  const [userName, setUserName] = useState('Tabrej');
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempUserName, setTempUserName] = useState('Tabrej');

  // Assistant Persona Name
  const [assistantName, setAssistantName] = useState('TAJ');

  // Sleep state (Video feature: user says "band ho jao / sleep" -> assistant goes dormant without touching phone)
  const [isSleeping, setIsSleeping] = useState(false);

  // Continuous Hands-Free Voice Mode
  const [isContinuousMode, setIsContinuousMode] = useState(true);

  // Live Screen Vision Modal
  const [isScreenVisionOpen, setIsScreenVisionOpen] = useState(false);

  // Floating Overlay State (the floating green particle orb on screen)
  const [isFloatingOverlayVisible, setIsFloatingOverlayVisible] = useState(false);

  // Voice Interaction States
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [voiceLiveText, setVoiceLiveText] = useState('');
  const [speechNotice, setSpeechNotice] = useState<string | null>(null);
  const [lastSpokenReply, setLastSpokenReply] = useState<string>('');

  // Chat conversation state for the Chat Tab
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'taj',
      text: language === 'bn'
        ? `হ্যালো ${userName} বস! আমি আপনার ব্যক্তিগত এআই অ্যাসিস্ট্যান্ট তাজ। আপনি এখানে লিখে প্রশ্ন করতে পারেন অথবা মুখে ভয়েসে কথা বলতে পারেন।`
        : `Hello Boss! I am TAJ, your personal voice and trading assistant. You can chat here with text or speak using voice.`,
      time: '12:00 PM',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (subTab === 'chat') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, subTab]);

  // Clock for the smartphone status bar
  const [currentTimeStr, setCurrentTimeStr] = useState('');

  // ----------------- CANDLESTICK CHART STATE FOR TRADING VISION -----------------
  const [selectedAsset, setSelectedAsset] = useState(ASSETS[0]);
  const [timeframeSeconds, setTimeframeSeconds] = useState(60);
  const [countdown, setCountdown] = useState(60);
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [currentPrice, setCurrentPrice] = useState(ASSETS[0].base);
  const [isChartAnalyzing, setIsChartAnalyzing] = useState(false);
  const [liveTradingSignal, setLiveTradingSignal] = useState<{
    direction: 'CALL' | 'PUT' | 'WAIT';
    confidence: number;
    pattern: string;
    advice: string;
  }>({
    direction: 'CALL',
    confidence: 84,
    pattern: 'Bullish Pinbar Rejection at EMA 20',
    advice: 'পরবর্তী ক্যান্ডেল আপ (CALL / সবুজ) হওয়ার সম্ভাবনা প্রায় ৮৪%।',
  });

  const chartCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const recognitionRef = useRef<any>(null);
  const continuousModeRef = useRef(isContinuousMode);
  continuousModeRef.current = isContinuousMode;
  const isSleepingRef = useRef(isSleeping);
  isSleepingRef.current = isSleeping;
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // ----------------- INITIALIZE CANDLESTICK CHART DATA -----------------
  useEffect(() => {
    let p = selectedAsset.base;
    const initialCandles: CandleData[] = [];
    const now = Date.now();

    for (let i = 24; i >= 0; i--) {
      const open = p;
      const variation = (Math.random() - 0.48) * (selectedAsset.base * 0.0008);
      const close = open + variation;
      const high = Math.max(open, close) + Math.random() * (selectedAsset.base * 0.0004);
      const low = Math.min(open, close) - Math.random() * (selectedAsset.base * 0.0004);
      p = close;

      initialCandles.push({
        time: new Date(now - i * timeframeSeconds * 1000).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
        timestamp: now - i * timeframeSeconds * 1000,
        open,
        high,
        low,
        close,
        volume: Math.floor(Math.random() * 800) + 200,
        isBullish: close >= open,
      });
    }

    setCandles(initialCandles);
    setCurrentPrice(p);
    setCountdown(timeframeSeconds);
  }, [selectedAsset, timeframeSeconds]);

  // Real-time ticking engine for candlesticks
  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((prevCount) => {
        if (prevCount <= 1) {
          setCandles((prevCandles) => {
            const last = prevCandles[prevCandles.length - 1];
            if (!last) return prevCandles;

            const newOpen = last.close;
            const newCandle: CandleData = {
              time: new Date().toLocaleTimeString([], {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
              }),
              timestamp: Date.now(),
              open: newOpen,
              high: newOpen,
              low: newOpen,
              close: newOpen,
              volume: 120,
              isBullish: true,
            };

            return [...prevCandles.slice(1), newCandle];
          });

          return timeframeSeconds;
        }

        // Price tick
        const tickMove = (Math.random() - 0.49) * (selectedAsset.base * 0.0002);
        setCurrentPrice((prevPrice) => {
          const nextPrice = Number((prevPrice + tickMove).toFixed(selectedAsset.base > 100 ? 2 : 5));

          setCandles((prevCandles) => {
            if (prevCandles.length === 0) return prevCandles;
            const lastIdx = prevCandles.length - 1;
            const last = prevCandles[lastIdx];

            const newHigh = Math.max(last.high, nextPrice);
            const newLow = Math.min(last.low, nextPrice);
            const isBull = nextPrice >= last.open;

            const updatedCandles = [...prevCandles];
            updatedCandles[lastIdx] = {
              ...last,
              high: newHigh,
              low: newLow,
              close: nextPrice,
              volume: last.volume + Math.floor(Math.random() * 4),
              isBullish: isBull,
            };

            return updatedCandles;
          });

          return nextPrice;
        });

        return prevCount - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [selectedAsset, timeframeSeconds]);

  // Draw Candlestick Canvas
  useEffect(() => {
    const canvas = chartCanvasRef.current;
    if (!canvas || candles.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Dark grid background
    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
    ctx.lineWidth = 1;
    for (let y = 30; y < height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    for (let x = 40; x < width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Min & Max Price
    const allPrices = candles.flatMap((c) => [c.high, c.low]);
    const minP = Math.min(...allPrices);
    const maxP = Math.max(...allPrices);
    const rangeP = maxP - minP || 1;

    const paddingY = 25;
    const chartHeight = height - paddingY * 2;

    const getY = (val: number) => {
      return height - paddingY - ((val - minP) / rangeP) * chartHeight;
    };

    const candleWidth = Math.max(6, Math.floor((width - 40) / candles.length) - 4);
    const spacing = (width - 20) / candles.length;

    // Draw EMA 20 line
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    candles.forEach((c, idx) => {
      const x = 10 + idx * spacing + candleWidth / 2;
      const y = getY(c.close);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Draw Candlesticks
    candles.forEach((c, idx) => {
      const x = 10 + idx * spacing;
      const openY = getY(c.open);
      const closeY = getY(c.close);
      const highY = getY(c.high);
      const lowY = getY(c.low);

      const isBull = c.close >= c.open;
      const color = isBull ? '#22c55e' : '#ef4444';

      // Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x + candleWidth / 2, highY);
      ctx.lineTo(x + candleWidth / 2, lowY);
      ctx.stroke();

      // Body
      ctx.fillStyle = color;
      const bodyY = Math.min(openY, closeY);
      const bodyH = Math.max(3, Math.abs(closeY - openY));
      ctx.fillRect(x, bodyY, candleWidth, bodyH);
    });

    // Current Price Pulsing Line
    const currentY = getY(currentPrice);
    ctx.strokeStyle = '#10b981';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, currentY);
    ctx.lineTo(width, currentY);
    ctx.stroke();
    ctx.setLineDash([]);

    // Price badge on right
    ctx.fillStyle = '#10b981';
    ctx.fillRect(width - 65, currentY - 10, 65, 20);
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 10px monospace';
    ctx.fillText(currentPrice.toFixed(selectedAsset.base > 100 ? 1 : 4), width - 60, currentY + 4);
  }, [candles, currentPrice, selectedAsset]);

  // ----------------- CAPTURE CURRENT CANDLESTICK CANVAS FOR AI -----------------
  const captureChartSnapshot = (): string | null => {
    if (!chartCanvasRef.current) return null;
    return chartCanvasRef.current.toDataURL('image/jpeg', 0.85);
  };

  // ----------------- SPEECH RECOGNITION SETUP -----------------
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (SpeechRecognition) {
        try {
          const recognition = new SpeechRecognition();
          recognition.continuous = false;
          recognition.interimResults = true;
          recognition.lang = language === 'bn' ? 'bn-BD' : 'en-US';

          recognition.onstart = () => {
            setIsListening(true);
            setSpeechNotice(null);
          };

          recognition.onresult = (event: any) => {
            let interim = '';
            let final = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
              const piece = event.results[i][0].transcript;
              if (event.results[i].isFinal) {
                final += piece;
              } else {
                interim += piece;
              }
            }

            const recognizedText = (final || interim).trim();
            if (recognizedText) {
              setVoiceLiveText(recognizedText);
            }

            if (final.trim()) {
              setVoiceLiveText('');
              handleProcessVoiceCommand(final.trim());
            }
          };

          recognition.onerror = (event: any) => {
            console.warn('Speech recognition error:', event.error);
            setIsListening(false);
            if (event.error === 'not-allowed') {
              setSpeechNotice(
                language === 'bn'
                  ? 'মাইক্রোফোনের অনুমতি দেওয়া হয়নি (Browser Settings-এ গিয়ে Allow করুন)।'
                  : 'Microphone permission denied. Please allow mic in browser.'
              );
            } else if (event.error === 'no-speech') {
              if (continuousModeRef.current && !currentAudioRef.current) {
                setTimeout(() => {
                  if (continuousModeRef.current && !currentAudioRef.current) {
                    startListening();
                  }
                }, 400);
              }
            }
          };

          recognition.onend = () => {
            setIsListening(false);
            if (continuousModeRef.current && !currentAudioRef.current) {
              setTimeout(() => {
                if (continuousModeRef.current && !currentAudioRef.current) {
                  startListening();
                }
              }, 600);
            }
          };

          recognitionRef.current = recognition;
        } catch (initErr) {
          console.warn('SpeechRecognition init error:', initErr);
        }
      }
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
      stopSpeaking();
    };
  }, [language]);

  // Persistent unlocked audio element for mobile browsers
  const persistentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Prime/unlock audio context on user gesture (crucial for Mobile Chrome)
  const unlockAudio = () => {
    if (!persistentAudioRef.current && typeof window !== 'undefined') {
      const audio = new Audio();
      audio.preload = 'auto';
      persistentAudioRef.current = audio;
    }
  };

  // Stop TTS speech playback
  const stopSpeaking = () => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current.currentTime = 0;
      currentAudioRef.current = null;
    }
    if (persistentAudioRef.current) {
      persistentAudioRef.current.pause();
      persistentAudioRef.current.currentTime = 0;
    }
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  // Start speech listening (clean, without mic track locking)
  const startListening = () => {
    unlockAudio();
    setSpeechNotice(null);
    stopSpeaking();

    if (!recognitionRef.current) {
      setSpeechNotice(
        language === 'bn'
          ? 'আপনার ব্রাউজারে ভয়েস রিকগনিশন সাপোর্ট নেই। গুগল ক্রোম ব্রাউজার ব্যবহার করুন।'
          : 'Voice recognition is not supported in this browser. Please use Google Chrome.'
      );
      return;
    }

    try {
      soundFx.playBeep();
      recognitionRef.current.start();
      setIsListening(true);
    } catch (e: any) {
      console.warn('Recognition start exception, retrying:', e?.message);
      try {
        recognitionRef.current.abort();
        setTimeout(() => {
          recognitionRef.current?.start();
          setIsListening(true);
        }, 150);
      } catch (e2) {}
    }
  };

  const stopListening = () => {
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.stop();
    } catch (e) {}
    setIsListening(false);
    setVoiceLiveText('');
  };

  const toggleListening = () => {
    if (isSleeping) {
      // Wake up on tap
      setIsSleeping(false);
      speakVoice(`জি ${userName} বস, আমি জেগে আছি! বলুন কি করতে হবে?`);
      return;
    }

    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Web Speech API fallback
  const fallbackSpeechSynthesis = (cleanSpeech: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) {
      setIsSpeaking(false);
      return;
    }
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanSpeech.slice(0, 300));
      utterance.lang = language === 'bn' ? 'bn-BD' : 'en-US';
      utterance.rate = speechRate;
      utterance.pitch = 1.05;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => {
        setIsSpeaking(false);
        if (continuousModeRef.current) {
          setTimeout(() => startListening(), 600);
        }
      };
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      setIsSpeaking(false);
    }
  };

  // High-Quality Native Audio Playback via /api/tts (Google Bengali TTS)
  const speakVoice = (text: string) => {
    if (!autoSpeak) return;
    stopSpeaking();

    const cleanSpeech = text
      .replace(/[#*`_~]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanSpeech) return;
    setLastSpokenReply(cleanSpeech);

    try {
      const langCode = language === 'bn' ? 'bn' : 'en';
      const audioUrl = `/api/tts?text=${encodeURIComponent(cleanSpeech)}&lang=${langCode}`;

      let audio = persistentAudioRef.current;
      if (!audio) {
        audio = new Audio();
        persistentAudioRef.current = audio;
      }
      audio.src = audioUrl;
      audio.playbackRate = speechRate;
      currentAudioRef.current = audio;

      audio.onplay = () => {
        setIsSpeaking(true);
      };

      audio.onended = () => {
        setIsSpeaking(false);
      };

      audio.onerror = (e) => {
        console.warn('TTS Audio element failed, falling back to Web Speech API:', e);
        fallbackSpeechSynthesis(cleanSpeech);
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn('Audio autoplay blocked, falling back to Web Speech:', err);
          fallbackSpeechSynthesis(cleanSpeech);
        });
      }
    } catch (err) {
      fallbackSpeechSynthesis(cleanSpeech);
    }
  };

  // Phone App Launcher
  const launchApp = (app: (typeof PHONE_APPS)[0]) => {
    soundFx.playBeep();
    const targetUrl = app.webFallback || app.urlScheme;

    if (app.urlScheme.startsWith('tel:') || app.urlScheme.startsWith('camera:') || app.urlScheme.startsWith('calc:')) {
      window.location.href = app.urlScheme;
      return;
    }

    if (targetUrl) {
      window.open(targetUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // ----------------- VOICE ENGINE: PROCESS USER VOICE SPOKEN QUERY -----------------
  const handleProcessVoiceCommand = async (voiceQuery: string, attachedScreenshot?: string) => {
    const query = voiceQuery.trim();
    if (!query) return;

    // Add query to chatMessages if not already the latest
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setChatMessages((prev) => {
      if (prev.length > 0 && prev[prev.length - 1].sender === 'user' && prev[prev.length - 1].text === query) {
        return prev;
      }
      return [...prev, { id: Date.now().toString(), sender: 'user', text: query, time: nowTime }];
    });

    const lower = query.toLowerCase();

    // 1. SLEEP VOICE COMMAND (video feature: "band ho jao, sone ja raha hoon, bye")
    const isSleepCmd =
      lower.includes('shut down') ||
      lower.includes('shutdown') ||
      lower.includes('শাট ডাউন') ||
      lower.includes('বন্ধ হও') ||
      lower.includes('বন্ধ হয়ে যাও') ||
      lower.includes('ঘুমাও') ||
      lower.includes('স্লিপ') ||
      lower.includes('থামো') ||
      lower.includes('বাই তাজ') ||
      lower.includes('bye taj') ||
      lower.includes('band ho jao');

    if (isSleepCmd) {
      soundFx.playBeep();
      setIsSleeping(true);
      const byeText =
        language === 'bn'
          ? `ঠিক আছে ${userName} বস, আমি স্লিপ মোডে যাচ্ছি। আপনি ভালো থাকুন, কাল কথা হবে, শুভরাত্রি!`
          : `Understood ${userName} Boss, entering sleep mode. Sleep well, good night!`;
      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: byeText, time: nowTime },
      ]);
      speakVoice(byeText);
      return;
    }

    // 2. WAKE UP VOICE COMMAND
    if (isSleepingRef.current) {
      const isWakeCmd =
        lower.includes('তাজ') ||
        lower.includes('taj') ||
        lower.includes('ওঠো') ||
        lower.includes('জেগে ওঠো') ||
        lower.includes('হ্যালো') ||
        lower.includes('হাই') ||
        lower.includes('hey') ||
        lower.includes('wake up');

      if (isWakeCmd) {
        soundFx.playBeep();
        setIsSleeping(false);
        const wakeText =
          language === 'bn'
            ? `জি ${userName} বস, আমি জেগে আছি! বলুন কি সাহায্য করতে পারি?`
            : `Yes ${userName} Boss, I am awake! How can I assist you?`;
        setChatMessages((prev) => [
          ...prev,
          { id: (Date.now() + 1).toString(), sender: 'taj', text: wakeText, time: nowTime },
        ]);
        speakVoice(wakeText);
        return;
      }
      return;
    }

    // 3. TRADING & CHART VISION INTENT CHECK
    const isTradingQuestion =
      lower.includes('মার্কেট') ||
      lower.includes('ক্যান্ডেল') ||
      lower.includes('ক্যান্ডেলস্টিক') ||
      lower.includes('কোন দিকে') ||
      lower.includes('কল') ||
      lower.includes('পুট') ||
      lower.includes('ট্রেড') ||
      lower.includes('ট্রেডিং') ||
      lower.includes('চার্ট') ||
      lower.includes('chart') ||
      lower.includes('candle') ||
      lower.includes('call') ||
      lower.includes('put');

    // If user specifically says "ট্রেডিংভিউ খোল" or "চার্ট অন কর"
    if (
      lower.includes('ট্রেডিংভিউ খোল') ||
      lower.includes('ট্রেডিংভিউ ওপেন') ||
      lower.includes('চার্ট খোল') ||
      lower.includes('চার্ট দেখাও') ||
      lower.includes('ব্রোকার খোল') ||
      lower.includes('open tradingview')
    ) {
      setSubTab('chart');
      const chartOpenText =
        language === 'bn'
          ? `হ্যাঁ ${userName} বস, ট্রেডিং চার্ট ওপেন করেছি! আপনি এখন যেকোনো প্রশ্ন করতে পারেন, আমি ক্যান্ডেল দেখে বলে দিচ্ছি।`
          : `Opening live trading chart, ${userName} Boss! Ask me anytime about next candle direction.`;
      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: chartOpenText, time: nowTime },
      ]);
      speakVoice(chartOpenText);
      return;
    }

    // 4. SCREEN VISION INTENT
    if (
      lower.includes('স্ক্রিন দেখ') ||
      lower.includes('স্ক্রিন শেয়ার') ||
      lower.includes('ব্রোকার স্ক্রিন দেখ') ||
      lower.includes('আমার স্ক্রিন দেখ') ||
      lower.includes('see screen') ||
      lower.includes('look at screen')
    ) {
      setIsScreenVisionOpen(true);
      const visionText =
        language === 'bn'
          ? `হ্যাঁ ${userName} বস, আমি আপনার স্ক্রিন দেখার জন্য প্রস্তুত। স্ক্রিন শেয়ার উইন্ডো ওপেন হয়েছে!`
          : `Ready to see your screen, ${userName} Boss!`;
      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: visionText, time: nowTime },
      ]);
      speakVoice(visionText);
      return;
    }

    // 5. PHONE APP LAUNCH INTENT
    const matchedApp = PHONE_APPS.find((app) => {
      if (lower.includes(app.id)) return true;
      if (lower.includes(app.nameEn.toLowerCase())) return true;
      if (lower.includes(app.commandVoiceBn)) return true;
      if (app.id === 'tiktok' && (lower.includes('টিকটক') || lower.includes('tiktok'))) return true;
      if (app.id === 'facebook' && (lower.includes('ফেসবুক') || lower.includes('facebook'))) return true;
      if (app.id === 'youtube' && (lower.includes('ইউটিউব') || lower.includes('ভিডিও'))) return true;
      if (app.id === 'whatsapp' && lower.includes('হোয়াটসঅ্যাপ')) return true;
      if (app.id === 'telegram' && lower.includes('টেলিগ্রাম')) return true;
      if (app.id === 'tradingview' && lower.includes('ট্রেডিংভিউ')) return true;
      if (app.id === 'quotex' && lower.includes('কোটেক্স')) return true;
      if (app.id === 'pocketoption' && lower.includes('পকেট অপশন')) return true;
      if (app.id === 'calculator' && lower.includes('ক্যালকুলেটর')) return true;
      if (app.id === 'camera' && lower.includes('ক্যামেরা')) return true;
      if (app.id === 'phone' && (lower.includes('কল') || lower.includes('ফোন'))) return true;
      if (app.id === 'maps' && (lower.includes('ম্যাপ') || lower.includes('লোকেশন'))) return true;
      return false;
    });

    if (matchedApp && (lower.includes('খোল') || lower.includes('ওপেন') || lower.includes('চালু') || lower.includes('চালাও') || lower.includes('open') || lower.includes('launch'))) {
      launchApp(matchedApp);
      const appOpenText =
        language === 'bn'
          ? `জি ${userName} বস, আপনার ${matchedApp.nameBn} ওপেন করছি!`
          : `Opening ${matchedApp.nameEn} for you, Boss!`;
      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: appOpenText, time: nowTime },
      ]);
      speakVoice(appOpenText);
      return;
    }

    // 6. CALL GEMINI BACKEND FOR NATURAL VOICE REPLY OR TRADING ANALYSIS
    setIsLoading(true);
    setIsChartAnalyzing(isTradingQuestion);

    // If trading question, attach the live chart snapshot if available
    let chartSnapshot = attachedScreenshot;
    if (isTradingQuestion && !chartSnapshot) {
      chartSnapshot = captureChartSnapshot() || undefined;
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          language,
          screenShotBase64: chartSnapshot,
        }),
      });

      const data = await response.json();
      let botReply = data.reply || (language === 'bn' ? 'জি বস, আমি বুঝতে পেরেছি।' : 'Yes Boss, understood.');

      // Check actions returned from API
      if (data.action) {
        if (data.action.type === 'SLEEP') {
          setIsSleeping(true);
        } else if (data.action.type === 'WAKE') {
          setIsSleeping(false);
        } else if (data.action.type === 'OPEN_APP' && data.action.app) {
          const appToOpen = PHONE_APPS.find((a) => a.id === data.action.app);
          if (appToOpen) launchApp(appToOpen);
        }
      }

      // If trading analysis was performed, update the live radar card
      if (isTradingQuestion) {
        const isPut = botReply.includes('PUT') || botReply.includes('পুট') || botReply.includes('ডাউন');
        const isCall = botReply.includes('CALL') || botReply.includes('কল') || botReply.includes('আপ');
        setLiveTradingSignal({
          direction: isPut ? 'PUT' : isCall ? 'CALL' : 'WAIT',
          confidence: Math.floor(Math.random() * 10) + 82,
          pattern: isPut ? 'Bearish Shooting Star & EMA Resistance' : 'Bullish Hammer Bounce & EMA 20 Support',
          advice: botReply.slice(0, 150),
        });
      }

      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: botReply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
      speakVoice(botReply);
    } catch (err: any) {
      console.error('AI chat error:', err);
      const errReply =
        language === 'bn'
          ? 'দুঃখিত তাবরেজ বস, সার্ভারে সংযোগ পেতে সমস্যা হয়েছে। দয়া করে আরেকবার বলুন।'
          : 'Sorry Boss, connection error. Please speak again.';
      setChatMessages((prev) => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'taj', text: errReply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
      speakVoice(errReply);
    } finally {
      setIsLoading(false);
      setIsChartAnalyzing(false);
    }
  };

  // One-click chart analysis via voice
  const handleAnalyzeChartViaVoice = () => {
    handleProcessVoiceCommand('তাজ, চার্ট দেখে বল এখন মার্কেট কোন দিকে যাবে এবং পরবর্তী ক্যান্ডেল কি হবে?');
  };

  return (
    <div className="max-w-4xl mx-auto px-2 sm:px-4 py-3 space-y-4">
      {/* ========================================================================= */}
      {/* 1. TOP HEADER                                                             */}
      {/* ========================================================================= */}
      <div className="flex flex-col items-center justify-center text-center pt-1 pb-1 relative select-none">
        {/* Personalized Heading "Hello, Tabrej" */}
        <div className="flex items-center justify-center gap-2">
          {isEditingName ? (
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={tempUserName}
                onChange={(e) => setTempUserName(e.target.value)}
                className="px-2 py-0.5 rounded bg-slate-900 border border-cyan-500 text-base sm:text-xl font-bold text-white text-center focus:outline-none"
              />
              <button
                onClick={() => {
                  setUserName(tempUserName.trim() || 'Tabrej');
                  setIsEditingName(false);
                }}
                className="p-1 rounded bg-cyan-600 text-white"
              >
                <Check className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <h1 className="text-xl sm:text-2xl font-extrabold text-white font-sans flex items-center gap-2 tracking-wide">
              <span>Hello, {userName}</span>
              <button
                onClick={() => {
                  setTempUserName(userName);
                  setIsEditingName(true);
                }}
                className="p-1 rounded text-slate-500 hover:text-slate-300 transition-colors"
                title="Edit Name"
              >
                <Edit2 className="w-3.5 h-3.5" />
              </button>
            </h1>
          )}
        </div>

        <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
          {language === 'bn' ? 'মুখের কথায় ফোন ও ট্রেডিং কন্ট্রোল করুন' : 'Voice-controlled personal assistant & market analyst'}
        </p>

        {/* Top Action Shortcuts: Floating Orb & APK ZIP */}
        <div className="absolute right-1 top-1 flex items-center gap-1.5 sm:gap-2">
          <a
            href="/taj-ai-app.zip"
            download="taj-ai-app.zip"
            className="px-2.5 py-1 rounded-full text-[10px] font-semibold border bg-emerald-950/80 text-emerald-300 border-emerald-500/80 hover:bg-emerald-900/90 flex items-center gap-1 shadow-md transition-all"
            title="Download APK Source ZIP"
          >
            <Download className="w-3 h-3 text-emerald-400" />
            <span>ZIP ডাউনলোড</span>
          </a>

          <button
            onClick={() => setIsFloatingOverlayVisible(!isFloatingOverlayVisible)}
            className={`px-2.5 py-1 rounded-full text-[10px] font-medium border flex items-center gap-1.5 transition-all ${
              isFloatingOverlayVisible
                ? 'bg-cyan-950 text-cyan-300 border-cyan-500 shadow-md shadow-cyan-900/40'
                : 'bg-slate-900/80 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
            title="Toggle floating screen orb"
          >
            <Layers className="w-3 h-3" />
            <span className="hidden sm:inline">
              {isFloatingOverlayVisible
                ? language === 'bn' ? 'ভাসমান অর্ব চালু' : 'Floating Orb ON'
                : language === 'bn' ? 'ভাসমান অর্ব' : 'Floating Orb'}
            </span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. REAL-TIME ACOUSTIC VOICE STATUS HUD                                    */}
      {/* ========================================================================= */}
      {speechNotice && (
        <div className="p-2.5 px-3.5 rounded-2xl bg-amber-950/80 border border-amber-500/50 text-amber-200 text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-amber-400">⚠️</span>
            <span>{speechNotice}</span>
          </div>
          <button
            onClick={() => setSpeechNotice(null)}
            className="text-[10px] underline ml-2 text-amber-300 hover:text-white"
          >
            {language === 'bn' ? 'ঠিক আছে' : 'OK'}
          </button>
        </div>
      )}

      {/* When Listening */}
      {isListening && !isSleeping && (
        <div className="p-2.5 px-4 rounded-2xl bg-emerald-950/90 border border-emerald-500/70 text-emerald-300 text-xs flex items-center justify-between shadow-lg shadow-emerald-900/30 animate-pulse">
          <div className="flex items-center gap-2 truncate">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
            <span className="font-bold text-white shrink-0">
              {language === 'bn' ? '🎙️ শুনছি:' : '🎙️ Listening:'}
            </span>
            <span className="truncate text-emerald-200 italic font-medium">
              {voiceLiveText || (language === 'bn' ? 'কথা বলুন, আমি শুনছি...' : 'Speak now, TAJ is listening...')}
            </span>
          </div>
          <button
            onClick={stopListening}
            className="text-[10px] px-2.5 py-1 rounded-lg bg-emerald-800 hover:bg-rose-600 text-white transition-colors shrink-0 ml-2 shadow font-medium"
          >
            {language === 'bn' ? 'থামান' : 'Stop'}
          </button>
        </div>
      )}

      {/* When Speaking */}
      {isSpeaking && (
        <div className="p-2.5 px-4 rounded-2xl bg-cyan-950/90 border border-cyan-500/70 text-cyan-200 text-xs flex items-center justify-between shadow-lg shadow-cyan-900/30">
          <div className="flex items-center gap-2.5 truncate">
            <Volume2 className="w-4 h-4 text-cyan-400 animate-bounce shrink-0" />
            <div className="truncate">
              <span className="font-bold text-white mr-1.5">
                {language === 'bn' ? '🔊 তাজ মুখে বলছে:' : '🔊 TAJ speaking:'}
              </span>
              <span className="text-cyan-200 text-xs truncate">
                {lastSpokenReply ? lastSpokenReply.slice(0, 75) + '...' : ''}
              </span>
            </div>
          </div>
          <button
            onClick={stopSpeaking}
            className="text-[10px] px-2.5 py-1 rounded-lg bg-cyan-800 hover:bg-rose-600 text-white transition-colors shrink-0 ml-2 font-medium"
          >
            {language === 'bn' ? 'ভয়েস থামান' : 'Mute'}
          </button>
        </div>
      )}

      {/* When Thinking or Analyzing */}
      {isLoading && (
        <div className="p-2.5 px-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-cyan-300 text-xs flex items-center gap-2 shadow-lg">
          <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
          <span>
            {isChartAnalyzing
              ? language === 'bn'
                ? '🔍 ক্যান্ডেলস্টিক প্যাটার্ন ও টেকনিক্যাল ইন্ডিকেটর এনালাইসিস করছি...'
                : '🔍 Analyzing candlesticks, wicks and EMA levels...'
              : language === 'bn'
              ? 'তাজ চিন্তা করছে ও উত্তর প্রস্তুত করছে...'
              : 'TAJ is thinking and preparing reply...'}
          </span>
        </div>
      )}

      {/* When Sleeping (Dormant mode from video) */}
      {isSleeping && (
        <div className="p-3 px-4 rounded-2xl bg-slate-950/90 border border-slate-800 text-slate-400 text-xs flex items-center justify-between shadow-xl">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
            <span className="font-medium text-slate-300">
              {language === 'bn'
                ? '💤 তাজ স্লিপ মোডে আছে • মুখে বলুন "তাজ ওঠো" বা অর্বে ট্যাপ করুন'
                : '💤 TAJ is in Sleep Mode • Say "Wake up" or tap orb'}
            </span>
          </div>
          <button
            onClick={() => {
              setIsSleeping(false);
              speakVoice(`জি ${userName} বস, আমি জেগে আছি! বলুন কি করতে হবে?`);
            }}
            className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow transition-all"
          >
            {language === 'bn' ? 'জেগে ওঠো' : 'Wake Up'}
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. SUB-TAB VIEWS                                                          */}
      {/* ========================================================================= */}

      {/* -------------------- VIEW 1: HOME (CLEAN DUAL ORB & VOICE) -------------------- */}
      {subTab === 'home' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-gradient-to-b from-[#060913] via-[#091122] to-[#04070f] border border-slate-800/90 p-6 sm:p-8 shadow-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[380px]">
            {/* Ambient Lighting & Hologram Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* THE SIGNATURE HOLOGRAPHIC GLOWING PARTICLE ORB (Red Atomic Orbital Rings + Green 3D Particle Sphere) */}
            <div className="my-2">
              <DualHolographicOrb
                isListening={isListening}
                isSpeaking={isSpeaking}
                isSleeping={isSleeping}
                onOrbClick={toggleListening}
                statusText={
                  isSleeping
                    ? 'Sleep Mode • Say "Wake up"'
                    : isListening
                    ? 'Listening... speak now'
                    : isSpeaking
                    ? `${assistantName} speaking...`
                    : 'Ready • Speak anything to TAJ'
                }
              />
            </div>

            {/* Clean Voice Controls: Mic Trigger & Live Screen Vision */}
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                onClick={toggleListening}
                className={`px-5 py-2.5 rounded-full text-xs font-semibold border flex items-center gap-2 transition-all shadow-lg ${
                  isListening
                    ? 'bg-rose-600 border-rose-400 text-white shadow-rose-600/50 animate-pulse'
                    : isSpeaking
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-emerald-500/40'
                    : 'bg-slate-900/90 border-slate-700 hover:border-emerald-500/70 text-slate-200 hover:text-white hover:bg-slate-800'
                }`}
                title="Tap to speak"
              >
                {isListening ? (
                  <>
                    <Mic className="w-4 h-4 animate-bounce" />
                    <span>Listening...</span>
                  </>
                ) : isSpeaking ? (
                  <>
                    <Volume2 className="w-4 h-4 animate-bounce" />
                    <span>Speaking...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 text-emerald-400" />
                    <span>Speak to TAJ</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setIsScreenVisionOpen(true)}
                className="px-4 py-2.5 rounded-full text-xs font-semibold bg-cyan-950/80 border border-cyan-500/80 text-cyan-300 hover:bg-cyan-900/60 transition-all flex items-center gap-2 shadow-md shadow-cyan-950/50"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Live Screen Vision</span>
              </button>
            </div>

            {/* Live Voice Hearing Indicator & Last Spoken Response Bubble */}
            {voiceLiveText && (
              <div className="w-full mt-4 p-3 rounded-2xl bg-rose-950/40 border border-rose-800/60 text-center animate-pulse">
                <p className="text-[11px] text-rose-400 font-semibold mb-0.5">🎙️ শুনছি...</p>
                <p className="text-xs text-rose-100 font-medium">"{voiceLiveText}"</p>
              </div>
            )}

            {lastSpokenReply && !voiceLiveText && (
              <div className="w-full mt-4 p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-400 mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>তাজের উত্তর:</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed line-clamp-3">
                    {lastSpokenReply}
                  </p>
                </div>
                <button
                  onClick={() => speakVoice(lastSpokenReply)}
                  className="shrink-0 px-3 py-1.5 rounded-xl bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
                  title="Play voice again"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>শুনুন</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* -------------------- VIEW 2: CHAT (DIRECT TEXT & VOICE MESSAGING) -------------------- */}
      {subTab === 'chat' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-[#060913] border border-slate-800 p-4 sm:p-5 shadow-2xl flex flex-col h-[520px]">
            {/* Chat Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white shadow-md">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>{assistantName} Assistant</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {language === 'bn' ? 'ব্যক্তিগত ভয়েস ও ট্রেডিং চ্যাট' : 'Personal voice & trading chat'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setChatMessages([
                    {
                      id: Date.now().toString(),
                      sender: 'taj',
                      text: language === 'bn'
                        ? `চ্যাট হিস্ট্রি ক্লিয়ার হয়েছে। বলুন ${userName} বস, আপনাকে কিভাবে সাহায্য করতে পারি?`
                        : `Chat history cleared. How can I help you today, Boss?`,
                      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    },
                  ]);
                }}
                className="text-[11px] text-slate-400 hover:text-rose-400 px-2.5 py-1 rounded-lg border border-slate-800 hover:border-rose-900 transition-colors"
              >
                {language === 'bn' ? 'পরিষ্কার করুন' : 'Clear Chat'}
              </button>
            </div>

            {/* Chat Messages Body */}
            <div className="flex-1 overflow-y-auto py-3 space-y-3 px-1 scrollbar-thin">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'taj' && (
                    <div className="w-7 h-7 rounded-full bg-emerald-950 border border-emerald-500/50 flex items-center justify-center shrink-0 mt-0.5">
                      <div className="w-2 h-2 rounded-full bg-emerald-400" />
                    </div>
                  )}

                  <div
                    className={`max-w-[82%] sm:max-w-[70%] p-3 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-md ${
                      msg.sender === 'user'
                        ? 'bg-rose-950/80 border border-rose-800/80 text-rose-100 rounded-tr-none'
                        : 'bg-slate-900/95 border border-slate-800 text-slate-200 rounded-tl-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <div className="flex items-center justify-between gap-3 mt-1.5 text-[10px] text-slate-400">
                      <span>{msg.time}</span>
                      {msg.sender === 'taj' && (
                        <button
                          onClick={() => speakVoice(msg.text)}
                          className="hover:text-emerald-300 transition-colors flex items-center gap-1"
                          title="Listen with voice"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>{language === 'bn' ? 'শুনুন' : 'Listen'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-950/50 border border-emerald-900/60 px-3 py-2 rounded-xl w-fit animate-pulse">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>{language === 'bn' ? 'তাজ চিন্তা করছে ও উত্তর প্রস্তুত করছে...' : 'TAJ is thinking and preparing reply...'}</span>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Chat Input Bar */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const q = chatInput.trim();
                if (!q || isLoading) return;

                const userMsg: ChatMessage = {
                  id: Date.now().toString(),
                  sender: 'user',
                  text: q,
                  time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                };
                setChatMessages((prev) => [...prev, userMsg]);
                setChatInput('');

                await handleProcessVoiceCommand(q);
              }}
              className="pt-2 border-t border-slate-800/80 flex items-center gap-2"
            >
              <button
                type="button"
                onClick={toggleListening}
                className={`p-2.5 rounded-xl border transition-all ${
                  isListening
                    ? 'bg-rose-600 border-rose-500 text-white animate-pulse'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-emerald-400'
                }`}
                title="Speak voice into chat"
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder={
                  language === 'bn'
                    ? 'তাজকে কিছু লিখুন (উদা: পরবর্তী ক্যান্ডেল কি হবে?)...'
                    : 'Type a message to TAJ (e.g. Next candle prediction)...'
                }
                className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />

              <button
                type="submit"
                disabled={!chatInput.trim() || isLoading}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white shadow-md transition-all"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- VIEW 2: CHART (MARKET & CANDLESTICK VISION) -------------------- */}
      {subTab === 'chart' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-[#060913] border border-slate-800 p-4 sm:p-5 shadow-2xl space-y-4">
            {/* Chart Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-base sm:text-lg font-bold text-white">
                    {language === 'bn' ? 'লাইভ ক্যান্ডেলস্টিক ও ব্রোকার চার্ট ভিশন' : 'Live Candlestick & Market Vision'}
                  </h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {language === 'bn'
                    ? 'তাজ এই চার্টটি দেখে ক্যান্ডেলস্টিক ও ইন্ডিকেটর এনালাইসিস করে মুখে বলবে পরবর্তী ক্যান্ডেল কি হবে।'
                    : 'TAJ inspects candles and indicators on this chart to predict next candle aloud.'}
                </p>
              </div>

              {/* Asset Selector */}
              <div className="flex items-center gap-2 flex-wrap">
                <select
                  value={selectedAsset.id}
                  onChange={(e) => {
                    const found = ASSETS.find((a) => a.id === e.target.value);
                    if (found) setSelectedAsset(found);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-bold text-emerald-300 focus:outline-none"
                >
                  {ASSETS.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} ({a.payout}%)
                    </option>
                  ))}
                </select>

                <div className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-cyan-400 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{countdown}s</span>
                </div>
              </div>
            </div>

            {/* LIVE CANDLESTICK CANVAS */}
            <div className="relative rounded-2xl overflow-hidden border border-slate-800/80 shadow-inner">
              <canvas
                ref={chartCanvasRef}
                width={700}
                height={300}
                className="w-full h-[260px] sm:h-[300px] block"
              />

              {/* Live Indicators Overlay Badge */}
              <div className="absolute top-2 left-2 flex items-center gap-2 text-[10px] font-mono bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded-lg text-slate-300 backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-emerald-400 font-bold">{selectedAsset.name}</span>
                <span>• EMA 20: 38bdf8</span>
                <span>• Live Price: {currentPrice.toFixed(selectedAsset.base > 100 ? 2 : 4)}</span>
              </div>

              {/* Compact Floating Voice Orb inside Chart corner */}
              <div className="absolute top-2 right-2 flex items-center gap-2">
                <button
                  onClick={toggleListening}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-lg backdrop-blur-md transition-all ${
                    isListening
                      ? 'bg-rose-600 border border-rose-400 text-white animate-pulse'
                      : isSpeaking
                      ? 'bg-emerald-600 border border-emerald-400 text-white animate-bounce'
                      : 'bg-slate-900/90 border border-emerald-500/60 text-emerald-300 hover:bg-slate-800'
                  }`}
                >
                  <Mic className="w-3.5 h-3.5" />
                  <span>{isListening ? 'শুনছি...' : isSpeaking ? 'বলছে...' : 'কথা বলুন'}</span>
                </button>
              </div>
            </div>

            {/* ACTION ROW: ONE-CLICK VOICE CHART ANALYSIS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Voice Trigger Button */}
              <button
                onClick={handleAnalyzeChartViaVoice}
                disabled={isLoading}
                className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50 transition-all group"
              >
                <Sparkles className="w-4 h-4 group-hover:rotate-12 transition-transform" />
                <span>{language === 'bn' ? '🎙️ তাজকে চার্ট দেখতে বলুন (ভয়েসে বলবে)' : '🎙️ Ask TAJ to Analyze Chart Now'}</span>
              </button>

              {/* Share External Broker Screen */}
              <button
                onClick={() => setIsScreenVisionOpen(true)}
                className="p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow transition-all"
              >
                <Eye className="w-4 h-4 text-cyan-400" />
                <span>{language === 'bn' ? '👁️ আপনার কোটেক্স / ব্রোকার স্ক্রিন শেয়ার করুন' : '👁️ Share Quotex / External Broker'}</span>
              </button>
            </div>

            {/* TAJ'S LATEST CANDLE PREDICTION RADAR CARD */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  {language === 'bn' ? 'তাজের পরবর্তী ক্যান্ডেল প্রেডিকশন:' : 'TAJ Next Candle Radar:'}
                </span>

                <div className="flex items-center gap-2">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-black flex items-center gap-1 shadow ${
                      liveTradingSignal.direction === 'CALL'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50'
                        : liveTradingSignal.direction === 'PUT'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/50'
                        : 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                    }`}
                  >
                    {liveTradingSignal.direction === 'CALL' && <ArrowUpRight className="w-4 h-4" />}
                    {liveTradingSignal.direction === 'PUT' && <ArrowDownRight className="w-4 h-4" />}
                    <span>{liveTradingSignal.direction} ({liveTradingSignal.confidence}%)</span>
                  </span>
                </div>
              </div>

              <div className="text-xs text-slate-300 font-medium">
                <span className="text-slate-400">{language === 'bn' ? 'প্যাটার্ন: ' : 'Pattern: '}</span>
                <span className="text-cyan-300 font-semibold">{liveTradingSignal.pattern}</span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/60">
                {liveTradingSignal.advice}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* -------------------- VIEW 3: APPS (PHONE APPLICATIONS LAUNCHER) -------------------- */}
      {subTab === 'apps' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-[#060913] border border-slate-800 p-4 sm:p-5 space-y-4 shadow-2xl">
            <div className="border-b border-slate-800/80 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                {language === 'bn' ? 'ফোন অ্যাপ্লিকেশনসমূহ ও সিস্টেম কন্ট্রোল' : 'Phone Applications & System Controls'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'bn'
                  ? 'তাজকে মুখে বললে সে সরাসরি যেকোনো অ্যাপ চালু করবে (যেমন: "টিকটক ওপেন কর", "ইউটিউব চালাও")।'
                  : 'Speak to TAJ to launch any app directly via voice.'}
              </p>
            </div>

            {/* App Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {PHONE_APPS.map((app) => (
                <button
                  key={app.id}
                  onClick={() => launchApp(app)}
                  className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 flex flex-col items-center justify-center gap-2 group transition-all shadow-md"
                >
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-110"
                    style={{ backgroundColor: app.color }}
                  >
                    {app.id === 'tiktok' && <Video className="w-5 h-5" />}
                    {app.id === 'facebook' && <Share2 className="w-5 h-5" />}
                    {app.id === 'youtube' && <Youtube className="w-5 h-5" />}
                    {app.id === 'whatsapp' && <MessageCircle className="w-5 h-5" />}
                    {app.id === 'telegram' && <SendIcon className="w-5 h-5" />}
                    {app.id === 'tradingview' && <TrendingUp className="w-5 h-5" />}
                    {app.id === 'quotex' && <TrendingUp className="w-5 h-5" />}
                    {app.id === 'pocketoption' && <TrendingUp className="w-5 h-5" />}
                    {app.id === 'calculator' && <Calculator className="w-5 h-5" />}
                    {app.id === 'camera' && <Camera className="w-5 h-5" />}
                    {app.id === 'maps' && <MapPin className="w-5 h-5" />}
                    {app.id === 'phone' && <Phone className="w-5 h-5" />}
                    {app.id === 'settings' && <Settings className="w-5 h-5" />}
                  </div>
                  <div className="text-center">
                    <span className="text-xs font-bold text-white block group-hover:text-cyan-400">
                      {app.nameEn}
                    </span>
                    <span className="text-[10px] text-slate-400 block truncate">
                      {app.nameBn}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* -------------------- VIEW 4: SETTINGS -------------------- */}
      {subTab === 'settings' && (
        <div className="space-y-4">
          <div className="rounded-3xl bg-[#060913] border border-slate-800 p-4 sm:p-5 space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800/80 pb-3">
              <Settings className="w-4 h-4 text-cyan-400" />
              {language === 'bn' ? 'অ্যাসিস্ট্যান্ট কনফিগারেশন ও সেটিংস' : 'Assistant Configuration & Settings'}
            </h3>

            {/* User Name & Persona */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">
                  {language === 'bn' ? 'আপনার নাম (User Name):' : 'Your Name:'}
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">
                  {language === 'bn' ? 'অ্যাসিস্ট্যান্টের নাম (Persona Name):' : 'Assistant Name:'}
                </label>
                <input
                  type="text"
                  value={assistantName}
                  onChange={(e) => setAssistantName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Voice and Speech Controls */}
            <div className="pt-2 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-medium text-slate-200">
                    {language === 'bn' ? 'হ্যান্ডস-ফ্রি কন্টিনিউয়াস ভয়েস লুপ:' : 'Hands-Free Continuous Voice Loop:'}
                  </span>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn'
                      ? 'ভিডিওর মতো এআই কথা শেষ করলেই নিজে নিজে আপনার পরবর্তী কথা শুনবে।'
                      : 'Automatically listens back after AI finishes speaking, hands-free.'}
                  </p>
                </div>
                <button
                  onClick={() => setIsContinuousMode(!isContinuousMode)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    isContinuousMode ? 'bg-emerald-600' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                      isContinuousMode ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-medium text-slate-200">
                    {language === 'bn' ? 'ভয়েস অডিও আউটপুট (Auto-Speak):' : 'Voice Audio Output (Auto-Speak):'}
                  </span>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn' ? 'এআই উত্তরগুলো মুখে উচ্চারণ করে শোনাবে।' : 'AI reads answers aloud.'}
                  </p>
                </div>
                <button
                  onClick={() => setAutoSpeak(!autoSpeak)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    autoSpeak ? 'bg-cyan-600' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`block w-4 h-4 rounded-full bg-white transition-transform ${
                      autoSpeak ? 'translate-x-7' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              {/* Speed Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-slate-300">
                  <span>{language === 'bn' ? 'ভয়েসের গতি (Speed):' : 'Voice Speed:'}</span>
                  <span className="font-mono text-cyan-400">{speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.3"
                  step="0.05"
                  value={speechRate}
                  onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                  className="w-full accent-cyan-500"
                />
              </div>
            </div>

            {/* APK Packaging & Source Code Download Card */}
            <div className="pt-4 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{language === 'bn' ? 'অ্যান্ড্রয়েড APK সোর্স জিপ (ZIP File)' : 'Android APK Source ZIP'}</span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {language === 'bn'
                      ? 'Website2APK বা Capacitor দিয়ে পিওর .apk বানানোর সম্পূর্ণ ফাইল।'
                      : 'Full project source code ready for Website2APK or Capacitor build.'}
                  </p>
                </div>

                <a
                  href="/taj-ai-app.zip"
                  download="taj-ai-app.zip"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950/50 transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>{language === 'bn' ? 'ZIP ডাউনলোড' : 'Download ZIP'}</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. BOTTOM NAVIGATION BAR (Home | Chat | Center Voice Orb | Apps | Settings) */}
      {/* ========================================================================= */}
      <div className="sticky bottom-2 z-30 max-w-lg mx-auto bg-[#070b14]/95 border border-slate-800/90 rounded-2xl px-4 py-2 backdrop-blur-xl shadow-2xl flex items-center justify-between">
        {/* Tab 1: Home */}
        <button
          onClick={() => {
            soundFx.playBeep();
            setSubTab('home');
          }}
          className={`flex flex-col items-center justify-center p-1 transition-all ${
            subTab === 'home' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Home</span>
        </button>

        {/* Tab 2: Chat */}
        <button
          onClick={() => {
            soundFx.playBeep();
            setSubTab('chat');
          }}
          className={`flex flex-col items-center justify-center p-1 transition-all ${
            subTab === 'chat' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">{language === 'bn' ? 'চ্যাট' : 'Chat'}</span>
        </button>

        {/* Center Glowing Voice Orb Button */}
        <div className="relative -top-3">
          <button
            onClick={toggleListening}
            className={`w-13 h-13 rounded-full border-2 flex items-center justify-center shadow-xl transition-all transform hover:scale-105 active:scale-95 ${
              isSleeping
                ? 'bg-slate-900 border-slate-700 text-slate-400 shadow-slate-950/80'
                : isListening
                ? 'bg-rose-600 border-rose-400 text-white shadow-rose-600/60 animate-bounce'
                : isSpeaking
                ? 'bg-emerald-600 border-emerald-400 text-white shadow-emerald-500/50'
                : 'bg-gradient-to-tr from-rose-700 via-rose-600 to-amber-500 border-rose-400/80 text-white shadow-rose-900/40'
            }`}
            title="Voice Mic"
          >
            {isListening ? (
              <Mic className="w-6 h-6 animate-pulse" />
            ) : isSleeping ? (
              <Power className="w-5 h-5 text-slate-400" />
            ) : (
              <div className="w-4 h-4 rounded-full bg-white/90 shadow-[0_0_8px_#ffffff]" />
            )}
          </button>
        </div>

        {/* Tab 3: Apps */}
        <button
          onClick={() => {
            soundFx.playBeep();
            setSubTab('apps');
          }}
          className={`flex flex-col items-center justify-center p-1 transition-all ${
            subTab === 'apps' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Apps</span>
        </button>

        {/* Tab 4: Settings */}
        <button
          onClick={() => {
            soundFx.playBeep();
            setSubTab('settings');
          }}
          className={`flex flex-col items-center justify-center p-1 transition-all ${
            subTab === 'settings' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Settings</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 5. LIVE SCREEN VISION MODAL (Quotex, Pocket Option, TradingView Sharing)  */}
      {/* ========================================================================= */}
      <LiveScreenVisionModal
        isOpen={isScreenVisionOpen}
        onClose={() => setIsScreenVisionOpen(false)}
        language={language}
        onSendVisionQuery={async (query: string, imageBase64: string) => {
          await handleProcessVoiceCommand(query, imageBase64);
        }}
        isVoiceSpeaking={isSpeaking}
      />

      {/* ========================================================================= */}
      {/* 6. FLOATING SCREEN ORB OVERLAY (Matches video when navigating phone apps)  */}
      {/* ========================================================================= */}
      <FloatingOrbOverlay
        isVisible={isFloatingOverlayVisible}
        onToggleVisible={() => setIsFloatingOverlayVisible(!isFloatingOverlayVisible)}
        language={language}
        isListening={isListening}
        isSpeaking={isSpeaking}
        onToggleMic={toggleListening}
        onOpenScreenVision={() => setIsScreenVisionOpen(true)}
        statusText={isListening ? 'Listening' : isSpeaking ? 'Speaking' : 'Online'}
      />
    </div>
  );
};

// SendIcon component helper
const SendIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className || 'w-4 h-4'}
  >
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </svg>
);
