import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Smartphone,
  Download,
  Volume2,
  VolumeX,
  Languages,
  Clock,
  ShieldCheck,
  Flame,
} from 'lucide-react';
import { AppLanguage } from '../types/trading';
import { soundFx } from '../utils/soundEffects';

interface NavigationHeaderProps {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenMobileGuide: () => void;
  onDownloadZip: () => void;
  isDownloadingZip: boolean;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  language,
  setLanguage,
  activeTab,
  setActiveTab,
  onOpenMobileGuide,
  onDownloadZip,
  isDownloadingZip,
  soundEnabled,
  setSoundEnabled,
}) => {
  const [time, setTime] = useState({
    utc: '',
    dhaka: '',
    ny: '',
    london: '',
  });

  useEffect(() => {
    const updateTimes = () => {
      const now = new Date();
      setTime({
        utc: now.toLocaleTimeString('en-US', { timeZone: 'UTC', hour12: false }),
        dhaka: now.toLocaleTimeString('en-US', { timeZone: 'Asia/Dhaka', hour12: true }),
        ny: now.toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour12: true }),
        london: now.toLocaleTimeString('en-US', { timeZone: 'Europe/London', hour12: true }),
      });
    };
    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    {
      id: 'assistant',
      labelBn: 'পার্সোনাল অ্যাসিস্ট্যান্ট',
      labelEn: 'AI Assistant',
      badge: 'Jarvis',
      badgeColor: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    },
    {
      id: 'chart_scanner',
      labelBn: 'ক্যান্ডেল স্ক্রিনশট স্ক্যানার',
      labelEn: 'Candle Scanner',
      badge: 'Vision AI',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    },
    {
      id: 'live_predictor',
      labelBn: 'লাইভ ক্যান্ডেল প্রেডিকশন',
      labelEn: 'Live Predictor',
      badge: 'Live Radar',
      badgeColor: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    },
    {
      id: 'trading_steps',
      labelBn: 'ট্রেডিং জগতের ৩০টি ধাপ',
      labelEn: '30 Trading Steps',
      badge: 'Mastery',
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#090d16]/95 backdrop-blur-md">
      {/* Top micro market ticker bar */}
      <div className="hidden lg:flex items-center justify-between px-4 py-1 border-b border-slate-800/40 text-[11px] font-mono text-slate-400 bg-slate-950/40">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            NEURAL CORE ACTIVE
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-cyan-400" />
            <span className="text-slate-300">Dhaka:</span> {time.dhaka || '--:--'}
          </span>
          <span className="flex items-center gap-1">
            <span className="text-slate-400">London:</span> {time.london || '--:--'}
          </span>
          <span className="flex items-center gap-1">
            <span className="text-slate-400">NY:</span> {time.ny || '--:--'}
          </span>
          <span className="flex items-center gap-1">
            <span className="text-slate-400">UTC:</span> {time.utc || '--:--'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-slate-400">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            Binary & Forex Confluence Engine
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            30 Golden Principles Loaded
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div
            id="brand-logo-btn"
            onClick={() => setActiveTab('assistant')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-cyan-500 to-blue-600 p-[1.5px] shadow-lg shadow-cyan-500/10">
              <div className="w-full h-full rounded-[10px] bg-[#090d16] flex items-center justify-center overflow-hidden">
                <Sparkles className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-white font-sans">
                  APEX <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">AI</span>
                </span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  PRO
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-none hidden sm:block">
                {language === 'bn' ? 'পার্সোনাল অ্যাসিস্ট্যান্ট ও ট্রেডিং ব্রেন' : 'Personal AI & Trading Intelligence'}
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs (Desktop / Tablet) */}
        <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-900/70 border border-slate-800 rounded-xl">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => {
                  soundFx.playTick();
                  setActiveTab(item.id);
                }}
                className={`relative px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-gradient-to-r from-slate-800 to-slate-800/90 text-white shadow-sm border border-slate-700/60'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <span>{language === 'bn' ? item.labelBn : item.labelEn}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono border ${item.badgeColor}`}>
                  {item.badge}
                </span>
              </button>
            );
          })}
        </nav>

        {/* Right Action Tools */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Sound Toggle */}
          <button
            id="sound-toggle-btn"
            onClick={() => {
              const next = !soundEnabled;
              setSoundEnabled(next);
              soundFx.enabled = next;
              if (next) soundFx.playBeep();
            }}
            title={soundEnabled ? 'সাউন্ড বন্ধ করুন' : 'সাউন্ড চালু করুন'}
            className="p-2 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* Language Switch */}
          <button
            id="lang-switch-btn"
            onClick={() => {
              soundFx.playTick();
              setLanguage(language === 'bn' ? 'en' : 'bn');
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          >
            <Languages className="w-3.5 h-3.5 text-emerald-400" />
            <span>{language === 'bn' ? 'বাং' : 'EN'}</span>
          </button>

          {/* Phone Install Guide */}
          <button
            id="phone-guide-btn"
            onClick={() => {
              soundFx.playTick();
              onOpenMobileGuide();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-xs font-semibold text-emerald-400 hover:bg-emerald-900/40 transition-colors"
            title="মোবাইলে অ্যাপ হিসেবে ইন্সটল করার নিয়ম"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{language === 'bn' ? 'ফোন অ্যাপ' : 'Mobile App'}</span>
          </button>

          {/* Download ZIP button */}
          <button
            id="download-zip-btn"
            onClick={() => {
              soundFx.playTick();
              onDownloadZip();
            }}
            disabled={isDownloadingZip}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-xs font-bold text-white shadow-md shadow-cyan-600/20 transition-all disabled:opacity-50"
            title="সম্পূর্ণ প্রজেক্টের জিপ ডাউনলোড করুন"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isDownloadingZip ? 'প্যাকিং...' : language === 'bn' ? 'জিপ ডাউনলোড' : 'ZIP Export'}</span>
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/60 bg-slate-950/70 px-1 py-1">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`mobile-tab-${item.id}`}
              onClick={() => {
                soundFx.playTick();
                setActiveTab(item.id);
              }}
              className={`flex-1 py-1.5 px-1 text-center text-[11px] font-medium transition-colors ${
                isActive ? 'text-cyan-400 font-bold border-b-2 border-cyan-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {language === 'bn' ? item.labelBn.split(' ')[0] : item.labelEn.split(' ')[0]}
            </button>
          );
        })}
      </div>
    </header>
  );
};
