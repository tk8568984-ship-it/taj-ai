import React, { useState } from 'react';
import {
  X,
  Smartphone,
  Download,
  CheckCircle2,
  Terminal,
  Layers,
  Copy,
  Check,
  ExternalLink,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import { AppLanguage } from '../types/trading';
import { generateProjectZip, downloadBlob } from '../utils/zipGenerator';
import { soundFx } from '../utils/soundEffects';

interface MobileSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: AppLanguage;
}

export const MobileSetupModal: React.FC<MobileSetupModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setIsGeneratingZip(true);
      soundFx.playBeep();
      const zipBlob = await generateProjectZip();
      downloadBlob(zipBlob, 'apex-ai-trading-assistant.zip');
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
      alert(language === 'bn' ? 'জিপ তৈরিতে সমস্যা হয়েছে।' : 'Error generating ZIP.');
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const copyCode = (text: string, idx: number) => {
    soundFx.playTick();
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-6 space-y-5 text-slate-100">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFx.playTick();
            onClose();
          }}
          className="absolute right-4 top-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-600/30">
            <Smartphone className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white">
              {language === 'bn'
                ? 'মোবাইলে অ্যাপ রান ও জিপ ফাইল ডাউনলোড'
                : 'Mobile Setup & Project ZIP Export'}
            </h2>
            <p className="text-xs text-slate-400">
              {language === 'bn'
                ? 'আপনার ফোনে ফুলস্ক্রিন অ্যাপ হিসেবে চালানো ও সোর্স কোড ডাউনলোড করার পূর্ণাঙ্গ নির্দেশিকা।'
                : 'Run as a native fullscreen mobile app or export full source code.'}
            </p>
          </div>
        </div>

        {/* High Priority One-Click ZIP Download Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/60 to-blue-950/60 border border-cyan-500/40 space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                {language === 'bn' ? 'রেডি-টু-রান জিপ প্যাকেজ' : 'Ready-to-Run Project ZIP'}
              </span>
              <p className="text-[11px] text-slate-300">
                {language === 'bn'
                  ? 'সমস্ত ফাইল, এআই কনফিগ, ট্রেডিং রুলস এবং মোবাইল সেটআপ গাইড সম্বলিত জিপ ফাইল।'
                  : 'Includes all source code, AI routers, 30 rules, and mobile APK build configs.'}
              </p>
            </div>

            <button
              id="modal-download-zip-btn"
              onClick={handleDownload}
              disabled={isGeneratingZip}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 disabled:opacity-50 transition-all shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>
                {isGeneratingZip
                  ? language === 'bn'
                    ? 'প্যাকিং হচ্ছে...'
                    : 'Generating...'
                  : language === 'bn'
                  ? 'জিপ ডাউনলোড করুন'
                  : 'Download ZIP'}
              </span>
            </button>
          </div>
        </div>

        {/* 3 Step-by-Step Methods */}
        <div className="space-y-4 text-xs">
          {/* Method 1: Instant PWA Install on Mobile */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-xs">
                ১
              </span>
              <span>
                {language === 'bn'
                  ? 'পদ্ধতি ১: কোনো কোডিং ছাড়াই ৫ সেকেন্ডে ফোনে ইনস্টল (PWA)'
                  : 'Method 1: Instant 5-Second Mobile Install (PWA)'}
              </span>
            </div>
            <p className="text-slate-300 leading-relaxed pl-8 text-xs">
              {language === 'bn' ? (
                <>
                  ১. আপনার ফোনের <strong>Google Chrome</strong> অথবা <strong>Safari</strong> ব্রাউজারে এই অ্যাপের লিংকটি ওপেন করুন।
                  <br />
                  ২. ব্রাউজারের উপরে ডানদিকের ৩-ডট মেন্যুতে (⋮) বা শেয়ার বাটনে ক্লিক করুন।
                  <br />
                  ৩. <strong>"Install app"</strong> অথবা <strong>"Add to Home Screen" (হোম স্ক্রিনে যোগ করুন)</strong> এ ট্যাপ করুন।
                  <br />
                  ৪. সাথে সাথে এটি আপনার ফোনের হোমস্ক্রিনে অ্যাপ আইকন হয়ে বসে যাবে এবং ফুলস্ক্রিনে চলবে!
                </>
              ) : (
                <>
                  1. Open this app link in Chrome or Safari on your phone.
                  <br />
                  2. Tap the browser menu (⋮) or Share icon.
                  <br />
                  3. Tap <strong>"Install App"</strong> or <strong>"Add to Home Screen"</strong>.
                  <br />
                  4. The app icon will appear on your phone launcher and run fullscreen like a native app.
                </>
              )}
            </p>
          </div>

          {/* Method 2: Run with Node.js / Local WiFi */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-xs">
                ২
              </span>
              <span>
                {language === 'bn'
                  ? 'পদ্ধতি ২: কম্পিউটারে চালিয়ে ফোনে ওয়াইফাই দিয়ে চালানো'
                  : 'Method 2: Run Locally & View on Phone over Wi-Fi'}
              </span>
            </div>
            <p className="text-slate-300 pl-8 text-xs">
              {language === 'bn'
                ? 'ডাউনলোড করা জিপ ফাইলটি আনজিপ করে টার্মিনালে নিচের কমান্ডগুলো দিন:'
                : 'Extract the downloaded ZIP and execute in your terminal:'}
            </p>

            <div className="ml-8 p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-emerald-400 flex items-center justify-between">
              <code>npm install && npm run dev</code>
              <button
                onClick={() => copyCode('npm install && npm run dev', 1)}
                className="text-slate-400 hover:text-white p-1"
                title="কপি করুন"
              >
                {copiedIndex === 1 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 pl-8">
              {language === 'bn'
                ? 'টার্মিনালে "Network: http://192.168.x.x:3000" লিংকটি আপনার ফোনের ব্রাউজারে টাইপ করলেই চলবে।'
                : 'Open the Network URL shown in the terminal on your mobile browser.'}
            </p>
          </div>

          {/* Method 3: Build Android APK (.apk) */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xs">
                ৩
              </span>
              <span>
                {language === 'bn'
                  ? 'পদ্ধতি ৩: সরাসরি অ্যান্ড্রয়েড APK (.apk) ফাইল তৈরি করা'
                  : 'Method 3: Build Native Android APK with Capacitor'}
              </span>
            </div>
            <p className="text-slate-300 pl-8 text-xs">
              {language === 'bn'
                ? 'Capacitor দিয়ে সরাসরি অ্যান্ড্রয়েড স্টুডিওতে APK বিল্ড করার কমান্ড:'
                : 'Turn this web app into an Android Studio project:'}
            </p>

            <div className="ml-8 p-2.5 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-amber-300 flex items-center justify-between">
              <code>npm run build && npx cap add android && npx cap open android</code>
              <button
                onClick={() =>
                  copyCode('npm run build && npx cap add android && npx cap open android', 2)
                }
                className="text-slate-400 hover:text-white p-1"
                title="কপি করুন"
              >
                {copiedIndex === 2 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            {language === 'bn' ? 'মোবাইল ফ্রেন্ডলি রেসপনসিভ ডিজাইন' : 'Mobile Responsive & PWA Ready'}
          </span>
          <button
            onClick={() => {
              soundFx.playTick();
              onClose();
            }}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors"
          >
            {language === 'bn' ? 'বুঝেছি / বন্ধ করুন' : 'Got it'}
          </button>
        </div>
      </div>
    </div>
  );
};
