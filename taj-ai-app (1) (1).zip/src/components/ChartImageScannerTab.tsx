import React, { useState, useEffect, useRef } from 'react';
import {
  Upload,
  Image as ImageIcon,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  HelpCircle,
  RefreshCw,
  Eye,
  Sliders,
  ArrowUpRight,
  ArrowDownRight,
  Info,
} from 'lucide-react';
import { AppLanguage, NextCandlePrediction } from '../types/trading';
import { SAMPLE_CHARTS, SampleChart } from '../data/sampleCharts';
import { soundFx } from '../utils/soundEffects';
import { convertSvgToPngDataUrl } from '../utils/imageHelpers';

interface ChartImageScannerTabProps {
  language: AppLanguage;
  onNavigateToSteps: () => void;
}

export const ChartImageScannerTab: React.FC<ChartImageScannerTabProps> = ({
  language,
  onNavigateToSteps,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(SAMPLE_CHARTS[0].svgDataUri);
  const [activeAsset, setActiveAsset] = useState('EUR/USD (OTC)');
  const [activeTimeframe, setActiveTimeframe] = useState('1m');
  const [userNotes, setUserNotes] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [prediction, setPrediction] = useState<NextCandlePrediction | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-analyze initial sample on first mount or allow user to trigger
  useEffect(() => {
    // Run initial analysis on the default sample chart
    handleScanImage(SAMPLE_CHARTS[0].svgDataUri, 'EUR/USD (OTC)', '1m');
  }, []);

  // Handle Clipboard Paste (Ctrl+V)
  useEffect(() => {
    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const file = items[i].getAsFile();
          if (file) {
            const reader = new FileReader();
            reader.onload = (uploadEvent) => {
              const base64 = uploadEvent.target?.result as string;
              setSelectedImage(base64);
              handleScanImage(base64, activeAsset, activeTimeframe);
            };
            reader.readAsDataURL(file);
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [activeAsset, activeTimeframe]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const base64 = uploadEvent.target?.result as string;
      setSelectedImage(base64);
      handleScanImage(base64, activeAsset, activeTimeframe);
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSample = (sample: SampleChart) => {
    soundFx.playTick();
    setSelectedImage(sample.svgDataUri);
    setActiveAsset(sample.asset);
    setActiveTimeframe(sample.timeframe);
    handleScanImage(sample.svgDataUri, sample.asset, sample.timeframe);
  };

  const handleScanImage = async (
    imgBase64: string,
    assetName = activeAsset,
    tf = activeTimeframe
  ) => {
    if (!imgBase64 || isScanning) return;

    setIsScanning(true);
    setErrorMessage(null);
    soundFx.playBeep();

    try {
      // If the image is SVG, convert it to a crisp raster PNG data URI first
      let payloadImage = imgBase64;
      if (imgBase64.includes('svg')) {
        try {
          payloadImage = await convertSvgToPngDataUrl(imgBase64);
        } catch (convErr) {
          console.warn('SVG to PNG conversion fallback:', convErr);
        }
      }

      const response = await fetch('/api/analyze-chart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: payloadImage,
          asset: assetName,
          timeframe: tf,
          notes: userNotes,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data: NextCandlePrediction = await response.json();
      if (data && data.signal) {
        setPrediction(data);

        if (data.signal === 'CALL') {
          soundFx.playCallSignal();
        } else if (data.signal === 'PUT') {
          soundFx.playPutSignal();
        } else {
          soundFx.playBeep();
        }
      }
    } catch (err: any) {
      console.error('Scan error:', err);
      setErrorMessage(
        language === 'bn'
          ? 'এআই অ্যানালাইসিস করতে ব্যর্থ হয়েছে। স্পষ্ট ক্যান্ডেলস্টিক চার্ট দিয়ে পুনরায় চেষ্টা করুন।'
          : 'Failed to analyze chart. Please provide a clear candlestick image.'
      );
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-2 sm:px-4 py-4 space-y-5">
      {/* Top Banner & Instructions */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-emerald-950/40 border border-slate-800 p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Eye className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white">
                {language === 'bn' ? 'ক্যান্ডেল দেখে পরের ক্যান্ডেল প্রেডিকশন' : 'Candle Chart AI Predictor'}
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'bn'
                  ? 'Quotex, Pocket Option, TradingView বা যেকোনো চার্টের স্ক্রিনশট আপলোড করলেই এআই পরের ক্যান্ডেল (CALL / PUT) বলে দেবে।'
                  : 'Upload any screenshot from Quotex, Pocket Option, or TradingView to predict next candle.'}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Sample Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[11px] text-slate-400 font-medium">
            {language === 'bn' ? 'টেস্টিং চার্ট:' : 'Sample Charts:'}
          </span>
          {SAMPLE_CHARTS.map((sample) => (
            <button
              key={sample.id}
              id={`sample-chart-btn-${sample.id}`}
              onClick={() => handleSelectSample(sample)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-[11px] font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  sample.expectedSignal === 'CALL' ? 'bg-emerald-400' : 'bg-rose-400'
                }`}
              ></span>
              <span>{sample.asset}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Upload & Chart View (Left) vs AI Verdict (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Image Canvas & Upload Box (7 Cols) */}
        <div className="lg:col-span-7 space-y-3">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <label className="text-slate-400 font-medium">{language === 'bn' ? 'অ্যাসেট:' : 'Asset:'}</label>
              <input
                type="text"
                value={activeAsset}
                onChange={(e) => setActiveAsset(e.target.value)}
                placeholder="EUR/USD, BTC, Gold"
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white w-28 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <label className="text-slate-400 font-medium">{language === 'bn' ? 'টাইমফ্রেম:' : 'TF:'}</label>
              <select
                value={activeTimeframe}
                onChange={(e) => setActiveTimeframe(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="1m">1-Minute (বাইনারি ১ মিনিট)</option>
                <option value="5m">5-Minute (বাইনারি ৫ মিনিট)</option>
                <option value="15m">15-Minute (ফরেক্স)</option>
                <option value="1h">1-Hour</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="upload-screenshot-btn"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'স্ক্রিনশট আপলোড' : 'Upload'}</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Chart Display Area */}
          <div className="relative rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden min-h-[320px] flex items-center justify-center group shadow-xl">
            {selectedImage ? (
              <div className="relative w-full h-full flex items-center justify-center p-2">
                <img
                  src={selectedImage}
                  alt="Candlestick Chart to Analyze"
                  className="max-h-[380px] w-full object-contain rounded-xl"
                />

                {/* Scanning Radar Laser Line Animation */}
                {isScanning && (
                  <div className="absolute inset-0 bg-cyan-500/10 backdrop-blur-[1px] flex flex-col justify-between overflow-hidden">
                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-pulse"></div>
                    <div className="flex items-center justify-center h-full">
                      <div className="px-4 py-2 rounded-xl bg-slate-900/90 border border-cyan-500 text-cyan-300 text-xs font-mono font-bold flex items-center gap-2 shadow-2xl">
                        <RefreshCw className="w-4 h-4 animate-spin text-cyan-400" />
                        <span>
                          {language === 'bn'
                            ? 'ক্যান্ডেলের সাইকোলজি ও ৩০টি ধাপ স্ক্যান হচ্ছে...'
                            : 'Scanning 30 trading rules & wicks...'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-8 text-center cursor-pointer hover:border-cyan-500 transition-colors"
              >
                <Upload className="w-10 h-10 text-slate-500 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-300">
                  {language === 'bn'
                    ? 'ক্যান্ডেলস্টিক চার্টের স্ক্রিনশট এখানে ড্র্যাগ করুন বা ক্লিক করে আপলোড করুন'
                    : 'Click or Drag & Drop Candlestick Chart Screenshot'}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  (বা কীবোর্ডে <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">Ctrl + V</kbd> চেপে সরাসরি পেস্ট করুন)
                </p>
              </div>
            )}
          </div>

          {/* Quick Rescan Trigger */}
          {selectedImage && (
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-slate-400 flex items-center gap-1">
                <Info className="w-3.5 h-3.5 text-cyan-400" />
                {language === 'bn'
                  ? 'টিপস: চার্টে অন্তত ৫-১০টি ক্যান্ডেল পরিষ্কার দেখা গেলে প্রেডিকশন নিখুঁত হয়।'
                  : 'Tip: 5-10 visible candles guarantee the highest confluence.'}
              </span>
              <button
                id="rescan-chart-btn"
                onClick={() => handleScanImage(selectedImage)}
                disabled={isScanning}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                <span>{language === 'bn' ? 'পুনরায় স্ক্যান করুন' : 'Re-Scan Chart'}</span>
              </button>
            </div>
          )}
        </div>

        {/* Right Column: Next Candle Verdict & 30-Rule Confluence (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          {prediction ? (
            <div className="rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 p-4 space-y-4 shadow-xl relative overflow-hidden">
              {/* Signal Badge Header */}
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                    {language === 'bn' ? 'পরবর্তী ক্যান্ডেল সিগন্যাল' : 'Next Candle Signal'}
                  </span>
                  <div className="flex items-center gap-2 mt-1">
                    <span
                      className={`text-2xl sm:text-3xl font-black font-sans tracking-tight px-3 py-1 rounded-xl border flex items-center gap-1.5 shadow-lg ${
                        prediction.signal === 'CALL'
                          ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500 shadow-emerald-500/20'
                          : prediction.signal === 'PUT'
                          ? 'bg-rose-950/80 text-rose-300 border-rose-500 shadow-rose-500/20'
                          : 'bg-amber-950/80 text-amber-300 border-amber-500 shadow-amber-500/20'
                      }`}
                    >
                      {prediction.signal === 'CALL' && <TrendingUp className="w-6 h-6 text-emerald-400" />}
                      {prediction.signal === 'PUT' && <TrendingDown className="w-6 h-6 text-rose-400" />}
                      {prediction.signal === 'WAIT' && <AlertTriangle className="w-6 h-6 text-amber-400" />}
                      <span>{prediction.signal}</span>
                      <span className="text-xs font-medium opacity-80">
                        {prediction.signal === 'CALL'
                          ? '(গ্রিন / UP)'
                          : prediction.signal === 'PUT'
                          ? '(রেড / DOWN)'
                          : '(অপেক্ষা)'}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Win Confidence Gauge */}
                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">
                    {language === 'bn' ? 'উইন কনফিডেন্স' : 'Confidence'}
                  </span>
                  <div className="text-2xl sm:text-3xl font-black font-mono text-cyan-400">
                    {prediction.confidence}%
                  </div>
                  <div className="w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1 ml-auto">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400"
                      style={{ width: `${prediction.confidence}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Quick Details Badges */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-mono">
                    {language === 'bn' ? 'ক্যান্ডেলস্টিক প্যাটার্ন' : 'Pattern'}
                  </span>
                  <span className="font-semibold text-slate-200 truncate block">
                    {prediction.pattern}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-mono">
                    {language === 'bn' ? 'সুপারিশকৃত এক্সপায়ারি' : 'Expiry Time'}
                  </span>
                  <span className="font-semibold text-emerald-400">
                    {prediction.recommendedExpiry || '1-Minute'}
                  </span>
                </div>
              </div>

              {/* Safe Margin of Safety Entry Advice */}
              <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 space-y-1">
                <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-bold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>{language === 'bn' ? 'মার্জিন অফ সেফটি এন্ট্রি টিপ:' : 'Margin of Safety Entry:'}</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {prediction.entryAdvice}
                </p>
              </div>

              {/* Bengali AI Detailed Explanation */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  {language === 'bn' ? 'এআই ক্যান্ডেলস্টিক বিশ্লেষণ:' : 'AI Candlestick Analysis:'}
                </span>
                <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  {language === 'bn' ? prediction.bengaliExplanation : prediction.englishSummary}
                </p>
              </div>

              {/* Confluence Checkpoints */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-300">
                  {language === 'bn' ? '৪টি কনফ্লুয়েন্স ফ্যাক্টর (যুক্তিসমূহ):' : 'Key Confluence Reasons:'}
                </span>
                <ul className="space-y-1.5 text-xs">
                  {prediction.confluences?.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Risk Management Reminder */}
              <div className="p-2.5 rounded-xl bg-slate-950/80 border border-amber-500/30 text-[11px] text-amber-300/90 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{prediction.riskNote}</span>
              </div>
            </div>
          ) : isScanning ? (
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-8 flex flex-col items-center justify-center text-center space-y-3 min-h-[360px]">
              <div className="w-12 h-12 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin"></div>
              <p className="text-sm font-semibold text-white">
                {language === 'bn'
                  ? 'চার্ট স্ক্যান করা হচ্ছে... অনুগ্রহ করে অপেক্ষা করুন'
                  : 'Analyzing candlestick formations...'}
              </p>
              <p className="text-xs text-slate-400 max-w-xs">
                {language === 'bn'
                  ? 'ট্রেডিং জগতের ৩০টি ধাপ এবং ক্যান্ডেলের বডি ও উইক অনুপাত গণনা করা হচ্ছে।'
                  : 'Calculating body-to-wick ratio and 30-step confluence rules.'}
              </p>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 text-center text-slate-400 text-xs space-y-2">
              <p>
                {language === 'bn'
                  ? 'বামে যেকোনো চার্ট সিলেক্ট করুন বা স্ক্রিনশট আপলোড করুন।'
                  : 'Select or upload any candlestick chart to see the AI prediction.'}
              </p>
            </div>
          )}

          {/* Quick link to 30 steps */}
          <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              {language === 'bn' ? 'ট্রেডিংয়ের নিয়মগুলো শিখতে চান?' : 'Want to study the 30 rules?'}
            </span>
            <button
              onClick={onNavigateToSteps}
              className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1"
            >
              <span>{language === 'bn' ? '৩০টি ধাপ দেখুন' : 'Explore 30 Steps'}</span>
              →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
