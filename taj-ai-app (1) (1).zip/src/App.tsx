import React, { useState } from 'react';
import { AppLanguage } from './types/trading';
import { VoiceAssistantTab } from './components/VoiceAssistantTab';
import { MobileSetupModal } from './components/MobileSetupModal';
import { generateProjectZip, downloadBlob } from './utils/zipGenerator';
import { soundFx } from './utils/soundEffects';
import { Volume2, VolumeX, Smartphone, Download, Sparkles, Languages } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<AppLanguage>('bn');
  const [isMobileGuideOpen, setIsMobileGuideOpen] = useState<boolean>(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const handleDownloadZip = async () => {
    try {
      setIsDownloadingZip(true);
      soundFx.playBeep();
      const zipBlob = await generateProjectZip();
      downloadBlob(zipBlob, 'taj-ai-personal-assistant.zip');
    } catch (err) {
      console.error('Failed to download ZIP:', err);
      alert(language === 'bn' ? 'জিপ তৈরিতে সমস্যা হয়েছে।' : 'Error generating ZIP.');
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const toggleSound = () => {
    const newState = !soundEnabled;
    setSoundEnabled(newState);
    soundFx.enabled = newState;
    if (newState) soundFx.playBeep();
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Sleek Top Navigation Bar for TAJ AI */}
      <header className="sticky top-0 z-40 bg-[#070b14]/90 border-b border-slate-800/80 backdrop-blur-md px-3 sm:px-6 py-2.5">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          {/* Brand Logo & Identity */}
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 via-cyan-600 to-rose-500 shadow-md shadow-emerald-500/20">
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-white text-base tracking-wider">TAJ AI</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  OS v3.8
                </span>
              </div>
              <p className="text-[10px] text-slate-400 -mt-0.5">
                {language === 'bn' ? 'পার্সোনাল এআই অ্যাসিস্ট্যান্ট' : 'Personal AI Assistant'}
              </p>
            </div>
          </div>

          {/* Controls: Language, Sound, Mobile Setup, ZIP */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Language Toggle */}
            <button
              onClick={() => {
                soundFx.playBeep();
                setLanguage(language === 'bn' ? 'en' : 'bn');
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-white flex items-center gap-1.5 transition-all shadow-sm"
              title="Switch Language"
            >
              <Languages className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-medium text-[11px]">{language === 'bn' ? 'বাং' : 'EN'}</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={toggleSound}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all shadow-sm"
              title={soundEnabled ? 'Mute sound' : 'Enable sound'}
            >
              {soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </button>

            {/* Mobile Setup Guide */}
            <button
              onClick={() => {
                soundFx.playBeep();
                setIsMobileGuideOpen(true);
              }}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-xs text-slate-300 hover:text-cyan-300 transition-all shadow-sm"
              title="Mobile Setup Guide"
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[11px]">{language === 'bn' ? 'মোবাইল গাইড' : 'Mobile'}</span>
            </button>

            {/* ZIP Download */}
            <button
              onClick={handleDownloadZip}
              disabled={isDownloadingZip}
              className="p-1.5 sm:px-2.5 sm:py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-xs text-slate-300 hover:text-emerald-300 transition-all shadow-sm flex items-center gap-1.5"
              title="Download Project ZIP"
            >
              <Download className={`w-4 h-4 text-emerald-400 ${isDownloadingZip ? 'animate-bounce' : ''}`} />
              <span className="hidden sm:inline text-[11px]">{language === 'bn' ? 'জিপ' : 'ZIP'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main TAJ Assistant Screen (Matches the reference video) */}
      <main className="flex-1 pb-10">
        <VoiceAssistantTab
          language={language}
        />
      </main>

      {/* Clean Minimalist Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-3 px-4 text-center text-xs text-slate-500">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-1.5 text-[11px]">
          <p>
            TAJ AI © 2026 — {language === 'bn' ? 'পার্সোনাল এআই অ্যাসিস্ট্যান্ট' : 'Personal AI Assistant'}
          </p>
          <div className="flex items-center gap-3 text-slate-400">
            <button
              onClick={() => setIsMobileGuideOpen(true)}
              className="hover:text-cyan-400 transition-colors"
            >
              {language === 'bn' ? 'মোবাইল ইনস্টল গাইড' : 'Mobile Guide'}
            </button>
            <span>•</span>
            <button
              onClick={handleDownloadZip}
              className="hover:text-emerald-400 transition-colors"
            >
              {language === 'bn' ? 'জিপ ডাউনলোড' : 'Download ZIP'}
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Setup & ZIP Modal */}
      <MobileSetupModal
        isOpen={isMobileGuideOpen}
        onClose={() => setIsMobileGuideOpen(false)}
        language={language}
      />
    </div>
  );
}
