import { TradingRule } from '../types/trading';

export const THIRTY_TRADING_STEPS: TradingRule[] = [
  // --- PHASE 1: MARKET STRUCTURE & CANDLESTICK ANATOMY (ধাপ ১ - ৮) ---
  {
    id: 1,
    titleBn: 'মার্কেট স্ট্রাকচার ও ট্রেন্ড সনাক্তকরণ (HH, HL, LH, LL)',
    titleEn: 'Market Structure & Trend Dynamics',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'মার্কেট কোন দিকে যাচ্ছে তা বোঝা ট্রেডিংয়ের প্রথম ও প্রধান শর্ত।',
    summaryEn: 'Understanding market directional bias through Higher Highs and Lower Lows.',
    detailsBn: 'মার্কেটের মূল তিনটি অবস্থা: আপট্রেন্ড (Higher High + Higher Low), ডাউনট্রেন্ড (Lower High + Lower Low) এবং সাইডওয়েজ (রেঞ্জ মার্কেট)। আপট্রেন্ডে কখনোই বিপরীত দিকে PUT ট্রেড নেওয়া যাবে না, ট্রেন্ডের দিকেই এন্ট্রি নেওয়া সর্বোচ্চ উইন রেটের নিশ্চয়তা দেয়।',
    detailsEn: 'Markets move in three phases: Uptrend (HH + HL), Downtrend (LH + LL), and Range/Consolidation. Never trade against the macro trend.',
    keyChecklistBn: [
      'লাস্ট সুইং হাই/লো ব্রেক হয়েছে কিনা লক্ষ্য করুন',
      'আপট্রেন্ডে কেবল CALL এবং ডাউনট্রেন্ডে কেবল PUT খুঁজুন',
      'সাইডওয়েজ মার্কেটে সাপোর্ট থেকে CALL ও রেজিস্ট্যান্স থেকে PUT নিন'
    ],
    candleType: 'bullish',
    winTipBn: 'Trend is your friend — ট্রেন্ডের সাথে ট্রেড নিলে লস হওয়ার ঝুঁকি ৭০% কমে যায়।',
    winTipEn: 'Always trade with the prevailing trend to maximize edge.'
  },
  {
    id: 2,
    titleBn: 'স্ট্রং সাপোর্ট ও রেজিস্ট্যান্স (SnR Zones & Polarities)',
    titleEn: 'Key Support & Resistance Zones',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'প্রাইস যে লেভেলগুলোতে এসে বারবার বাউন্স বা রিভার্স করে।',
    summaryEn: 'Identifying key historical bounce levels and support/resistance flips.',
    detailsBn: 'সাপোর্ট বা রেজিস্ট্যান্স কোনো সিঙ্গেল লাইন নয়, এটি একটি জোন (Zone)। আগের স্ট্রং রেজিস্ট্যান্স ব্রেক হলে তা সাপোর্টে পরিণত হয় (Role Reversal)। যে লেভেলে প্রাইস অন্তত ৩ বার রিঅ্যাক্ট করেছে, সেটি অত্যন্ত শক্তিশালী।',
    detailsEn: 'SnR represents liquidity zones where buyers or sellers heavily defend their positions.',
    keyChecklistBn: [
      'অতীতের অন্তত ২-৩টি রিজেকশন পয়েন্ট চেক করুন',
      'বডি টু বডি এবং উইক টু উইক মিলিয়ে জোন ড্র করুন',
      'রাউন্ড নম্বরের (.000, .500) সাথে SnR মিলে গেলে তা শক্তিশালী'
    ],
    candleType: 'reversal',
    winTipBn: 'সাপোর্টে গ্রিন রিজেকশন দেখলে CALL এবং রেজিস্ট্যান্সে রেড রিজেকশন দেখলে PUT নিন।',
    winTipEn: 'Wait for candle rejection confirmation at the level before execution.'
  },
  {
    id: 3,
    titleBn: 'ক্যান্ডেলস্টিক সাইকোলজি ও বডি-উইক অনুপাত',
    titleEn: 'Candlestick Anatomy & Body-to-Wick Ratio',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'প্রতিটি ক্যান্ডেলের বডি ও উইক ক্রেতা-বিক্রেতার যুদ্ধের জীবন্ত প্রমাণ।',
    summaryEn: 'Reading buyer vs seller pressure through candle body size and shadows.',
    detailsBn: 'বড় বডি মানে শক্তিশালী মোমেন্টাম। লম্বা লোয়ার উইক মানে বায়ারদের তীব্র চাপ (Buying Pressure)। লম্বা আপার উইক মানে সেলারদের তীব্র চাপ (Selling Pressure)। ক্ষুদ্র বডি ও উভয় পাশে সমান উইক মানে সিদ্ধান্তহীনতা (Indecision)।',
    detailsEn: 'A long lower shadow indicates strong buyer rejection from lows; a long upper shadow indicates seller rejection.',
    keyChecklistBn: [
      'উইক কি বডির চেয়ে দ্বিগুণ বা তিনগুণ বড়?',
      'রিজেকশনটি কি কোনো কি-লেভেলে ঘটেছে?',
      'পরবর্তী ক্যান্ডেল সাধারণত উইকের বিপরীতে যায়'
    ],
    candleType: 'reversal',
    winTipBn: 'বড় লোয়ার উইক = পরবর্তী ক্যান্ডেল গ্রিন হবার ৮০% সম্ভাবনা!',
    winTipEn: 'Long lower wick at support predicts green candle next.'
  },
  {
    id: 4,
    titleBn: 'ট্রেন্ডলাইন ও অ্যাঙ্গেল চ্যানেল বাউন্স',
    titleEn: 'Trendlines & Dynamic Channel Trading',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'কৌণিক সাপোর্ট ও রেজিস্ট্যান্সের মাধ্যমে পরবর্তী ক্যান্ডেল নির্ণয়।',
    summaryEn: 'Trading dynamic angled support and resistance trendlines.',
    detailsBn: 'অন্তত ৩টি হাই বা ৩টি লো যুক্ত করে একটি পারফেক্ট ট্রেন্ডলাইন পাওয়া যায়। ৩য় বা ৪র্থ টাচে ট্রেন্ডলাইন থেকে সবচেয়ে শক্তিশালী রিভার্সাল ক্যান্ডেল তৈরি হয়।',
    detailsEn: 'The 3rd touch of a validated trendline is statistically the highest probability bounce.',
    keyChecklistBn: [
      '৩য় টাচে ক্যান্ডেলের রিজেকশন অপেক্ষা করুন',
      'চ্যানেলের মাঝামাঝি ট্রেড নেওয়া থেকে বিরত থাকুন',
      'ট্রেন্ডলাইন ব্রেক হলে তাড়াহুড়া না করে রিটেস্টের জন্য অপেক্ষা করুন'
    ],
    candleType: 'bullish',
    winTipBn: 'ট্রেন্ডলাইনের ৩য় টাচে রিজেকশন দেখে পরের ক্যান্ডেলে ১-মিনিট ট্রেড সবচেয়ে সফল।',
    winTipEn: 'Third touch bounce provides optimal 1-minute expiration setups.'
  },
  {
    id: 5,
    titleBn: 'সিঙ্গেল ক্যান্ডেলস্টিক প্যাটার্ন (Hammer, Shooting Star, Doji)',
    titleEn: 'Single Candlestick Patterns Mastery',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'একটি মাত্র ক্যান্ডেল দেখেই পরবর্তী ক্যান্ডেলের দিক নির্ধারণ করা।',
    summaryEn: 'Mastering standalone reversal candles like Pinbars, Hammers, and Dojis.',
    detailsBn: 'হ্যামার (Hammer) সাপোর্টে আসলে পরের ক্যান্ডেল গ্রিন হয়। শুটিং স্টার (Shooting Star) রেজিস্ট্যান্সে আসলে পরের ক্যান্ডেল রেড হয়। ড্রাগনফ্লাই ডোজি তীব্র বুলিশ এবং গ্রেভস্টোন ডোজি তীব্র বেয়ারিশ রিভার্সাল নির্দেশ করে।',
    detailsEn: 'Pinbars at key boundaries indicate instant price rejection and next-candle reversal.',
    keyChecklistBn: [
      'হ্যামারের বডি ছোট এবং নিচের উইক বডির অন্তত ২ গুণ',
      'শুটিং স্টারের উপরের উইক বডির অন্তত ২ গুণ',
      'প্যাটার্নটি অবশ্যই ট্রেন্ডের শেষে বা কি-লেভেলে হতে হবে'
    ],
    candleType: 'reversal',
    winTipBn: 'মাঝামাঝি হ্যামার এলে এড়িয়ে চলুন, কেবল সাপোর্টে গঠিত হ্যামারে CALL নিন।',
    winTipEn: 'Only trade hammers and shooting stars at validated horizontal levels.'
  },
  {
    id: 6,
    titleBn: 'ডাবল ক্যান্ডেলস্টিক প্যাটার্ন (Engulfing, Tweezers, Piercing)',
    titleEn: 'Double Candlestick Formations',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'পরপর দুইটি ক্যান্ডেলের সমন্বয়ে শক্তিশালী দিক পরিবর্তন।',
    summaryEn: 'Bullish & Bearish Engulfing, Tweezers, and Piercing Line setups.',
    detailsBn: 'বুলিশ এনগালফিং: একটি ছোট রেড ক্যান্ডেলকে পরবর্তী বড় গ্রিন ক্যান্ডেল সম্পূর্ণ গিলে নেয়। বেয়ারিশ এনগালফিং: একটি ছোট গ্রিন ক্যান্ডেলকে বড় রেড ক্যান্ডেল গিলে ফেলে। টুইজার বটম: একই লেভেলে দুইটি ক্যান্ডেলের সমান লো রিজেকশন।',
    detailsEn: 'Engulfing patterns represent immediate shifts in institutional control.',
    keyChecklistBn: [
      '২য় ক্যান্ডেলের বডি যেন ১ম ক্যান্ডেলের চেয়ে বড় হয়',
      'সাপোর্টে বুলিশ এনগালফিং হলে পরবর্তী ক্যান্ডেলে নিশ্চিত CALL',
      'টুইজার হাই হলে পরবর্তী ক্যান্ডেলে নিশ্চিত PUT'
    ],
    candleType: 'bullish',
    winTipBn: 'এনগালফিং ক্যান্ডেলের ক্লোজিং যদি রেজিস্ট্যান্স না ছুঁয়ে থাকে, তবে কন্টিনিউয়েশন নিশ্চিত।',
    winTipEn: 'Engulfing candles closing before next SnR have 85%+ continuation rate.'
  },
  {
    id: 7,
    titleBn: 'ট্রিপল ক্যান্ডেল প্যাটার্ন (Morning Star & Evening Star)',
    titleEn: 'Triple Candlestick Reversals',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'তিনটি ক্যান্ডেল দ্বারা গঠিত নিশ্চিত ট্রেন্ড রিভার্সাল সিগন্যাল।',
    summaryEn: 'Morning Star, Evening Star, Three White Soldiers, and Three Black Crows.',
    detailsBn: 'মর্নিং স্টার: ১টি বড় রেড ক্যান্ডেল + ১টি ছোট ডোজি/স্পিনিং টপ + ১টি বড় গ্রিন ক্যান্ডেল। এটি ডাউনট্রেন্ডের পরিসমাপ্তি ঘটিয়ে তীব্র আপট্রেন্ড শুরু করে। ইভনিং স্টার রেজিস্ট্যান্সে তীব্র ডাউনট্রেন্ড আনে।',
    detailsEn: 'Morning Star at support signifies guaranteed exhaustion of sellers.',
    keyChecklistBn: [
      '৩য় ক্যান্ডেল যেন ১ম ক্যান্ডেলের অন্তত ৫০% এর উপরে ক্লোজ হয়',
      'মাঝখানের ক্যান্ডেলের ভলিউম কম থাকা ভালো',
      'কনফার্মেশন পেলেই ৩য় ক্যান্ডেলের পর ট্রেড নেওয়া নিরাপদ'
    ],
    candleType: 'reversal',
    winTipBn: 'মর্নিং স্টার সম্পূর্ণ হলে ৪র্থ ক্যান্ডেলে ১-৫ মিনিট নিশ্চিত CALL এন্ট্রি।',
    winTipEn: 'Enter immediately on the candle following the completed Morning Star.'
  },
  {
    id: 8,
    titleBn: 'কন্টিনিউয়েশন প্যাটার্ন (Marubozu & Three Line Strike)',
    titleEn: 'Trend Continuation & Momentum Candlesticks',
    category: 'structure',
    categoryBn: 'মার্কেট স্ট্রাকচার',
    summaryBn: 'ক্যান্ডেল দেখে বোঝা মার্কেট কি আগের ট্রেন্ডই বজায় রাখবে কিনা।',
    summaryEn: 'Marubozu momentum, strong breakouts, and continuation patterns.',
    detailsBn: 'মারুবজু (Marubozu) হলো এমন ক্যান্ডেল যার কোনো উইক নেই বা অতি ক্ষুদ্র উইক। গ্রিন মারুবজু মানে বায়ারদের সম্পূর্ণ আধিপত্য, ফলে পরবর্তী ক্যান্ডেলও গ্রিন হওয়ার সুযোগ থাকে।',
    detailsEn: 'Marubozu shows extreme buyer/seller conviction with zero or tiny wicks.',
    keyChecklistBn: [
      'মারুবজুর সামনে কোনো তাৎক্ষণিক রেজিস্ট্যান্স আছে কি না পরীক্ষা করুন',
      'যদি স্পেস (Space to SnR) থাকে, তবে পরবর্তী ক্যান্ডেলে সেইম ডিরেকশন ট্রেড নিন',
      'যদি মারুবজু রেজিস্ট্যান্সে গিয়ে আঘাত হানে, তবে রিভার্সাল হতে পারে'
    ],
    candleType: 'bullish',
    winTipBn: 'মার্কেট লেভেলের মাঝে মারুবজু ক্যান্ডেল তৈরি হলে ট্রেন্ড কন্টিনিউয়েশনে ট্রেড নিন।',
    winTipEn: 'Trade continuation only when there is adequate space to the next major level.'
  },

  // --- PHASE 2: SMC & LIQUIDITY CONCEPTS (ধাপ ৯ - ১৫) ---
  {
    id: 9,
    titleBn: 'রিয়েল ব্রেকআউট বনাম রিটেস্ট কনফার্মেশন',
    titleEn: 'Real Breakout & Retest Confirmation',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'ব্রেকআউট হওয়ার পর অন্ধের মত না ঢুকে রিটেস্ট কনফার্মেশন নেওয়া।',
    summaryEn: 'Distinguishing true structural breakouts from premature entries.',
    detailsBn: 'একটি কি-লেভেল ভাঙার পর প্রাইস অধিকাংশ সময়েই সেই লেভেলে পুনরায় রিটেস্ট (Retest) করতে আসে। রিটেস্টে উইক রিজেকশন দেখলে ব্রেকআউটের দিকে নিশ্চিত এন্ট্রি নেওয়া যায়।',
    detailsEn: 'Wait for the retest candle to touch the broken level and print a rejection wick.',
    keyChecklistBn: [
      'ক্যান্ডেল বডি যেন লেভেলের বাইরে পরিষ্কারভাবে ক্লোজ হয়',
      'রিটেস্ট ক্যান্ডেল লেভেল স্পর্শ করে বিপরীত রিজেকশন দিচ্ছে কিনা দেখুন',
      'রিটেস্ট কনফার্ম হলে ব্রেকআউটের দিকে ট্রেড প্রেস করুন'
    ],
    candleType: 'bullish',
    winTipBn: 'কখনই ব্রেকআউট ক্যান্ডেলে সাথে সাথে ঢুকবেন না, রিটেস্ট পর্যন্ত অপেক্ষা করুন।',
    winTipEn: 'Patience pays: always wait for the retest candle to validate support-resistance flip.'
  },
  {
    id: 10,
    titleBn: 'ফেইক ব্রেকআউট (Fakeout & Liquidity Trap)',
    titleEn: 'Fake Breakout & Bull/Bear Trap Identification',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'নতুন ট্রেডারদের ফাঁদে ফেলে বড় প্লেয়ারদের রিভার্সাল চাল বোঝা।',
    summaryEn: 'Identifying false breakouts and trading the aggressive snapback.',
    detailsBn: 'ক্যান্ডেল লেভেল ব্রেক করে বাইরে গিয়ে বড় উইক তৈরি করে ভেতরে এসে ক্লোজ হলে তাকে ফেইকআউট বলে। এটি রিটেইল ট্রেডারদের স্টপ লস খাওয়ার জন্য তৈরি হয়। ফেইকআউটের পর পরবর্তী ক্যান্ডেলে রিভার্সাল ট্রেড ১০০% নিরাপদ।',
    detailsEn: 'When price breaks a level with a wick but closes inside the zone, a sharp reversal follows.',
    keyChecklistBn: [
      'ক্যান্ডেল বডি লেভেলের ভেতরে ক্লোজ হয়েছে কি না?',
      'ব্রেকআউট সাইডে বড় উইক থাকলে বুঝতে হবে সেলার বা বায়ার রিজেক্টেড',
      'পরবর্তী ক্যান্ডেলে রিভার্সাল ট্রেড নিন (সাপোর্টে ফেইক হলে CALL)'
    ],
    candleType: 'reversal',
    winTipBn: 'ফেইকআউট দেখলে বিপরীত দিকে ট্রেড নিন — এটি ট্রেডিংয়ের সবচেয়ে লাভজনক প্যাটার্ন!',
    winTipEn: 'Fakeouts provide the highest risk-to-reward reversal opportunities.'
  },
  {
    id: 11,
    titleBn: 'অর্ডার ব্লক (Order Blocks - Institutional Footprints)',
    titleEn: 'Institutional Order Blocks (OB)',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'বড় ব্যাংক ও ইনস্টিটিউশনের বিশাল অর্ডারের জোন চিহ্নিত করা।',
    summaryEn: 'Identifying where smart money placed their last major mitigation orders.',
    detailsBn: 'একটি বড় আপট্রেন্ড মুভ শুরু হওয়ার আগের শেষ রেড ক্যান্ডেলটি হলো বুলিশ অর্ডার ব্লক (Bullish OB)। প্রাইস যখন ভবিষ্যতে আবার ওই ব্লকে আসে, ব্যাংক তাদের অবশিষ্ট অর্ডার ফিল করে মার্কেটকে রকেটের মতো উপরে তুলে দেয়।',
    detailsEn: 'The last opposing candle prior to a violent displacement move represents the Order Block.',
    keyChecklistBn: [
      'ইমপালসিভ মুভের আগের বিপরীত ক্যান্ডেলটি চিহ্নিত করুন',
      'ক্যান্ডেলটির হাই ও লো দিয়ে জোন আঁকুন',
      'প্রাইস জোনে এলে ছোট টাইমফ্রেমে রিজেকশন দেখে এন্ট্রি নিন'
    ],
    candleType: 'bullish',
    winTipBn: 'আনমিটিগেটেড (Unmitigated) অর্ডার ব্লকে ১ম টাচ সবসময় ৯৫% বাউন্স দেয়।',
    winTipEn: 'The first touch of an unmitigated Order Block has an extremely high win rate.'
  },
  {
    id: 12,
    titleBn: 'ফেয়ার ভ্যালু গ্যাপ (FVG - Fair Value Gap & Imbalance)',
    titleEn: 'Fair Value Gaps & Market Imbalance Fill',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'মার্কেটের অসম ভারসাম্য এবং গ্যাপ পূরণ করার চুম্বকীয় আকর্ষণ।',
    summaryEn: 'Exploiting 3-candle price gaps that market makers must rebalance.',
    detailsBn: 'পরপর তিনটি ক্যান্ডেলের ১ম ক্যান্ডেলের হাই এবং ৩য় ক্যান্ডেলের লো এর মাঝে ফাঁকা জায়গা থাকলে তাকে FVG বলে। মার্কেট এই গ্যাপটিকে চুম্বকের মত টেনে পূর্ণ করে। তাই গ্যাপ পূর্ণ হওয়া মাত্রই ট্রেন্ডের দিকে পরবর্তী ক্যান্ডেল পূর্বাভাস দেওয়া সম্ভব।',
    detailsEn: 'FVG is an inefficient price delivery zone between candle 1 and candle 3 that gets filled.',
    keyChecklistBn: [
      'বড় ক্যান্ডেলের মাঝে কোনো ফাঁকা গ্যাপ রয়েছে কিনা দেখুন',
      'গ্যাপের ৫০% (Consequent Encroachment) লেভেলে প্রাইস রিয়্যাক্ট করে',
      'গ্যাপ ফিল হওয়া মাত্রই রিভার্সাল বা কন্টিনিউয়েশন এন্ট্রি নিন'
    ],
    candleType: 'bullish',
    winTipBn: 'FVG লেভেলের ৫০% টাচ করলে তাৎক্ষণিক ১-মিনিট বিপরীত রিজেকশন ট্রেড নিন।',
    winTipEn: 'The 50% midpoint of an FVG acts as an institutional pivot point.'
  },
  {
    id: 13,
    titleBn: 'লিকুইডিটি সুইপ (Liquidity Sweeps & Stop Hunts)',
    titleEn: 'Liquidity Sweeps & Stop Hunts',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'ইকুয়াল হাই বা লো শিকার করে প্রকৃত ট্রেন্ড শুরু করা।',
    summaryEn: 'Hunting retail stops resting above equal highs or below equal lows.',
    detailsBn: 'যেখানে অনেক রিটেইল ট্রেডারের স্টপ লস থাকে (যেমন ডাবল টপ বা ডাবল বটমের সামান্য উপরে/নিচে), মার্কেট একটি ক্যান্ডেল দিয়ে সেই লেভেল সুইপ করে সাথে সাথে উল্টো দিকে ধাবিত হয়।',
    detailsEn: 'Price purges liquidity pools before taking off in the true anticipated direction.',
    keyChecklistBn: [
      'ইকুয়াল হাই (Equal Highs) বা লো চিহ্নিত করুন',
      'ক্যান্ডেল যদি শুধুমাত্র উইক দিয়ে হাই ক্রস করে ক্লোজ নিচে দেয়, তবে সুইপ সম্পন্ন',
      'সুইপ সম্পন্ন হওয়ার পর পরবর্তী ক্যান্ডেলে উল্টো দিকে নিশ্চিত ট্রেড'
    ],
    candleType: 'reversal',
    winTipBn: 'লিকুইডিটি সুইপের পরের ক্যান্ডেল ৯০% নিশ্চিত রিভার্সাল প্রদান করে।',
    winTipEn: 'A swift liquidity sweep candle followed by immediate rejection is an A+ setup.'
  },
  {
    id: 14,
    titleBn: 'মার্কেট স্ট্রাকচার শিফট (MSS & CHoCH বনাম BOS)',
    titleEn: 'Market Structure Shift (MSS) & Change of Character',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'ট্রেন্ড বদলের প্রথম অফিসিয়াল সংকেত বোঝা।',
    summaryEn: 'Catching the earliest structural trend change signal.',
    detailsBn: 'BOS (Break of Structure) মানে ট্রেন্ড বজায় থাকা। CHoCH (Change of Character) মানে ট্রেন্ড সম্পূর্ণ বদলে যাওয়া। যখন আপট্রেন্ডে লাস্ট Higher Low টি ব্রেক হয়ে নিচে ক্যান্ডেল ক্লোজ হয়, তখন আপট্রেন্ড শেষ এবং নতুন ডাউনট্রেন্ড শুরু।',
    detailsEn: 'CHoCH signals the reversal of trend when the previous significant swing point breaks.',
    keyChecklistBn: [
      'লাস্ট সুইং লো বা হাই ব্রেক হয়েছে কিনা লক্ষ্য করুন',
      'CHoCH এর পর সরাসরি ঢুকবেন না, প্রথম পুলব্যাক বা রিটেস্টে ঢুকুন',
      'নতুন ট্রেন্ডের দিকে পরবর্তী ক্যান্ডেলগুলোর পূর্বাভাস দিন'
    ],
    candleType: 'reversal',
    winTipBn: 'CHoCH এর পর প্রথম পুলব্যাকে নেওয়া ট্রেড সবচেয়ে কম ঝুঁকিপূর্ণ।',
    winTipEn: 'Wait for the first pullback after a confirmed CHoCH before execution.'
  },
  {
    id: 15,
    titleBn: 'ফিবোনাচ্চি গোল্ডেন জোন রিট্রেসমেন্ট (0.5 - 0.618)',
    titleEn: 'Fibonacci Golden Pocket Retracement',
    category: 'smc',
    categoryBn: 'স্মার্ট মানি ও লিকুইডিটি',
    summaryBn: 'প্রাইস কত দূর পুলব্যাক করবে তা গাণিতিকভাবে পরিমাপ করা।',
    summaryEn: 'Measuring institutional pullback exhaustion at 50% and 61.8% ratios.',
    detailsBn: 'একটি ইমপালসিভ মুভের শুরু থেকে শেষ পর্যন্ত ফিবোনাচ্চি টানলে ৫০% এবং ৬১.৮% লেভেলকে গোল্ডেন পকেট বলা হয়। মার্কেট প্রায়ই এই পকেটে এসে শান্ত হয় এবং রিভার্স ক্যান্ডেল তৈরি করে।',
    detailsEn: 'The 0.5 to 0.618 Fibonacci zone offers the tightest entries with structural confluence.',
    keyChecklistBn: [
      'সুইং লো থেকে সুইং হাই পর্যন্ত ফিব টুল ড্র করুন',
      '০.৬১৮ লেভেলে কোনো আগের সাপোর্ট বা রেজিস্ট্যান্স আছে কি না দেখুন',
      'গোল্ডেন জোনে রিজেকশন ক্যান্ডেল পেলেই মূল ট্রেন্ডে CALL/PUT নিন'
    ],
    candleType: 'bullish',
    winTipBn: 'ফিবোনাচ্চি ০.৬১৮ এবং SnR একসাথে মিললে উইন রেট ৯২% এর উপরে ওঠে।',
    winTipEn: 'Fibonacci 61.8% overlapping with horizontal SnR is unbeatable.'
  },

  // --- PHASE 3: TECHNICAL INDICATORS & CONFLUENCES (ধাপ ১৬ - ২১) ---
  {
    id: 16,
    titleBn: 'ডায়নামিক মুভিং অ্যাভারেজ (EMA 20, 50, 200 বাউন্স)',
    titleEn: 'Dynamic Moving Averages (EMA 20/50/200)',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'মুভিং লাইনগুলো জীবন্ত সাপোর্ট ও রেজিস্ট্যান্সের মতো আচরণ করে।',
    summaryEn: 'Trading dynamic support/resistance bounces and moving average crosses.',
    detailsBn: 'EMA 20 ট্রেন্ডের স্বল্পমেয়াদী গতি বোঝায়। প্রাইস যখন স্ট্রং ট্রেন্ডে থাকে, তখন প্রতিবার EMA 20 ছুয়ে বাউন্স করে গ্রিন ক্যান্ডেল দেয়। EMA 200 হলো লং-টার্ম ট্রেন্ডের রাজা; এর উপরে মার্কেট বুলিশ, নিচে বেয়ারিশ।',
    detailsEn: 'EMA 20 provides reliable dynamic bounce entries in strong 1-minute trending markets.',
    keyChecklistBn: [
      'প্রাইস EMA 20 টাচ করে ক্যান্ডেলে রিজেকশন উইক আছে কি না দেখুন',
      'EMA 20 এবং 50 একই দিকে মুখ করে থাকলে ট্রেন্ড তীব্র',
      'EMA 200 এর বিপরীতে কখনোই ১-মিনিট কাউন্টার ট্রেড করবেন না'
    ],
    candleType: 'bullish',
    winTipBn: 'স্ট্রং আপট্রেন্ডে ক্যান্ডেল EMA 20 তে টাচ করলেই চোখ বন্ধ করে CALL!',
    winTipEn: 'Look for EMA 20 pullbacks with rejection wicks for easy continuation calls.'
  },
  {
    id: 17,
    titleBn: 'আরএসআই ডাইভারজেন্স (RSI Regular & Hidden Divergence)',
    titleEn: 'RSI Divergence: Catching Trend Reversals',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'প্রাইস ও মোমেন্টামের বৈপরীত্য দেখে বিশাল রিভার্সাল ক্যান্ডেল ধরা।',
    summaryEn: 'Spotting divergence between price highs/lows and RSI momentum oscillator.',
    detailsBn: 'রেগুলার ডাইভারজেন্স: প্রাইস নতুন হাই (HH) বানাচ্ছে কিন্তু আরএসআই লোয়ার হাই (LH) বানাচ্ছে — এটি নির্দেশ করে বায়াররা দুর্বল, পরবর্তী ক্যান্ডেল থেকে তীব্র ডাউনট্রেন্ড শুরু হবে। হিডেন ডাইভারজেন্স ট্রেন্ড কন্টিনিউয়েশন নিশ্চিত করে।',
    detailsEn: 'Bearish divergence (price makes HH while RSI makes LH) warns of an imminent drop.',
    keyChecklistBn: [
      'RSI ৭০ এর উপরে ওভারবট এবং ৩০ এর নিচে ওভারসোল্ড',
      'প্রাইস পিক এবং RSI পিকের তুলনা করুন',
      'ডাইভারজেন্স এর সাথে কি-লেভেল মিললে রিভার্সাল ট্রেড কনফার্ম'
    ],
    candleType: 'reversal',
    winTipBn: 'RSI ওভারবট + ডাইভারজেন্স + রেজিস্ট্যান্স = নিশ্চিত রেড ক্যান্ডেল!',
    winTipEn: 'Divergence at SnR is one of the most reliable reversal triggers.'
  },
  {
    id: 18,
    titleBn: 'ম্যাকডি মোমেন্টাম ও হিস্টোগ্রাম এক্সপ্যানশন (MACD)',
    titleEn: 'MACD Momentum & Histogram Expansion',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'মোমেন্টামের বিস্ফোরণ ও ক্রসওভার দেখে ক্যান্ডেলের শক্তি অনুমান।',
    summaryEn: 'Confirming volume momentum and signal line crossovers.',
    detailsBn: 'MACD লাইন সিগন্যাল লাইনকে নিচের দিক থেকে উপরের দিকে ক্রস করলে বুলিশ মোমেন্টাম শুরু। হিস্টোগ্রামের বারগুলো যখন আগের বারের চেয়ে ছোট হতে শুরু করে, তখন বুঝতে হবে চলমান ক্যান্ডেলটির পরেই গতি কমবে।',
    detailsEn: 'Histogram bar shrinkage warns that the current directional wave is dying.',
    keyChecklistBn: [
      'জিরো লাইনের উপরে ক্রসওভার বেশি শক্তিশালী',
      'হিস্টোগ্রামের আকার বৃদ্ধি মানে স্ট্রং মোমেন্টাম ক্যান্ডেল',
      'বিপরীত ক্রসওভার শুরু হওয়া মাত্রই আগের পজিশন ক্লোজ করুন'
    ],
    candleType: 'bullish',
    winTipBn: 'হিস্টোগ্রাম যখন রঙ পরিবর্তন করে, তখন পরবর্তী ২-৩টি ক্যান্ডেল নিশ্চিত সেই দিকে চলে।',
    winTipEn: 'Trade in the direction of newly expanding histogram bars.'
  },
  {
    id: 19,
    titleBn: 'বলিঞ্জার ব্যান্ডস স্কুইজ ও ব্যান্ড রিজেকশন (Bollinger Bands)',
    titleEn: 'Bollinger Bands Volatility & Band Bounces',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'ব্যান্ডের বাইরে ক্যান্ডেল ক্লোজ হলে ৯৫% সময়েই পরবর্তী ক্যান্ডেল ভেতরে ফিরে আসে।',
    summaryEn: 'Mean-reversion trading when candles pierce outer 2-standard-deviation bands.',
    detailsBn: 'বলিঞ্জার ব্যান্ডের আপার বা লোয়ার ব্যান্ড ভাঙা কঠিন। যখন কোনো ক্যান্ডেল আপার ব্যান্ডের বাইরে সম্পূর্ণভাবে পিয়ার্স করে রিজেকশন তৈরি করে, পরের ক্যান্ডেলটি ব্যান্ডের ভেতরে ফিরে আসতে বাধ্য (Mean Reversion)।',
    detailsEn: 'Candles protruding outside the upper/lower 2-SD band snap back towards the middle EMA.',
    keyChecklistBn: [
      'ব্যান্ডের বাইরের উইক রিজেকশন লক্ষ্য করুন',
      'স্কুইজ (ব্যান্ড সরু হওয়া) এর পর বড় ক্যান্ডেল ব্রেকআউট আসে',
      'সাইডওয়েজ মার্কেটে আপার ব্যান্ডে PUT ও লোয়ার ব্যান্ডে CALL নিন'
    ],
    candleType: 'reversal',
    winTipBn: 'বাইনারিতে আপার ব্যান্ডের বাইরে লম্বা উইক রিজেকশন দেখলে পরবর্তী ১-মিনিট PUT নিশ্চিত উইন।',
    winTipEn: 'A wick piercing outside the upper band followed by rejection is an instant PUT.'
  },
  {
    id: 20,
    titleBn: 'ভলিউম স্প্রেড অ্যানালাইসিস (VSA - Volume Anomaly)',
    titleEn: 'Volume Spread Analysis (VSA Anomaly)',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'ক্যান্ডেলের আকারের সাথে ভলিউমের তুলনা করে সত্য উন্মোচন।',
    summaryEn: 'Detecting smart money accumulation and distribution via volume discrepancies.',
    detailsBn: 'যদি কোনো ক্যান্ডেলের আকার বিশাল হয় কিন্তু ভলিউম খুব কম থাকে, তবে তা ভুয়া মুভ। আবার ক্যান্ডেল একদম ক্ষুদ্র কিন্তু ভলিউম অস্বাভাবিক বেশি — তার মানে ভেতরে বড় প্লেয়াররা রিভার্স অর্ডারের প্রস্তুতি নিচ্ছে।',
    detailsEn: 'High volume with an ultra-small candle body signals impending explosive reversal.',
    keyChecklistBn: [
      'স্বাভাবিকের চেয়ে ২ গুণ বড় ভলিউম বার খুঁজুন',
      'রেজিস্ট্যান্সে হাই ভলিউম ডোজি ক্যান্ডেল মানে সেলার প্রবেশ',
      'ভলিউম ড্রাই-আপ (Volume dry-up) রিট্রেসমেন্টের সমাপ্তি বোঝায়'
    ],
    candleType: 'neutral',
    winTipBn: 'সাপোর্টে হাই ভলিউম কিন্তু ক্ষুদ্র রেড ক্যান্ডেল = পরবর্তী ক্যান্ডেলে বিশাল গ্রিন পাম্প!',
    winTipEn: 'High volume pinbar at support indicates complete seller absorption.'
  },
  {
    id: 21,
    titleBn: 'মাল্টি-টাইমফ্রেম বিশ্লেষণ (MTF: 15m -> 5m -> 1m)',
    titleEn: 'Multi-Timeframe Top-Down Analysis',
    category: 'indicators',
    categoryBn: 'টেকনিক্যাল ইন্ডিকেটর',
    summaryBn: 'বড় টাইমফ্রেমে ট্রেন্ড দেখা এবং ছোট টাইমফ্রেমে পারফেক্ট এন্ট্রি নেওয়া।',
    summaryEn: 'Aligning 15m macro context with 5m structure and 1m sniper entries.',
    detailsBn: 'কখনই শুধু ১-মিনিট চার্ট দেখে ট্রেড করবেন না। প্রথমে ১৫-মিনিট চার্টে বড় সাপোর্ট-রেজিস্ট্যান্স এবং ট্রেন্ড মার্ক করুন। তারপর ৫-মিনিটে স্ট্রাকচার দেখুন, এবং সর্বশেষে ১-মিনিট বা ৩০-সেকেন্ডে নিখুঁত এন্ট্রি পয়েন্ট নিন।',
    detailsEn: '15-minute chart sets the directional road; 1-minute chart is just the steering wheel.',
    keyChecklistBn: [
      '১৫-মিনিটে মেজর ট্রেন্ড আপ না ডাউন দেখে নিন',
      '১৫-মিনিটের কি-লেভেলে প্রাইস আসলে তবেই ১-মিনিটে রিজেকশন খুঁজুন',
      'বড় টাইমফ্রেমের ট্রেন্ডের বিরুদ্ধে কখনও ট্রেড করবেন না'
    ],
    candleType: 'bullish',
    winTipBn: '১৫-মিনিটের সাপোর্টে যখন ১-মিনিটের হ্যামার ক্যান্ডেল পাবেন, সেটি শতভাগ নিশ্চিত সিগন্যাল।',
    winTipEn: 'Confluence across 15m S/R and 1m candlestick pattern guarantees elite execution.'
  },

  // --- PHASE 4: BINARY 1-MIN EXPIRY & OTC SECRETS (ধাপ ২২ - ২৫) ---
  {
    id: 22,
    titleBn: 'বাইনারি ১-মিনিট ও ৫-মিনিট এক্সপায়ারি সাইন্টিফিক রুলস',
    titleEn: 'Binary Options 1-Min & 5-Min Expiry Rules',
    category: 'binary',
    categoryBn: 'বাইনারি ও ওটিসি স্ট্র্যাটেজি',
    summaryBn: 'টাইমিং এবং মার্জিন অফ সেফটি দিয়ে প্রতিটি ক্যান্ডেল জয় করা।',
    summaryEn: 'Precision timing, 00-second execution, and margin of safety entry.',
    detailsBn: 'বাইনারিতে ক্যান্ডেলের রঙ সঠিক হওয়া সত্ত্বেও অনেক সময় টাইমিংয়ের কারণে লস হয়। সর্বদা ক্যান্ডেল শুরুর প্রথম ৫-১০ সেকেন্ডে সামান্য বিপরীত রিট্রেসমেন্ট (Pullback) হওয়ার জন্য অপেক্ষা করুন, তারপর মার্জিন অফ সেফটিতে এন্ট্রি নিন।',
    detailsEn: 'Never enter at the exact open if you can get a 5-second pullback for safety margin.',
    keyChecklistBn: [
      '০০ সেকেন্ডের সময় সতর্ক থাকুন',
      'গ্রিন ক্যান্ডেলের প্রেডিকশন হলে ক্যান্ডেল কিছুটা নিচে নামলে CALL নিন (Margin of Safety)',
      'রেড ক্যান্ডেলের প্রেডিকশন হলে ক্যান্ডেল সামান্য উপরে উঠলে PUT নিন'
    ],
    candleType: 'bullish',
    winTipBn: 'মার্জিন অফ সেফটি নিলে ডোজি ক্যান্ডেল হলেও আপনার ট্রেড উইন হয়ে যাবে!',
    winTipEn: 'Margin of safety protects you even if the next candle ends as an indecision doji.'
  },
  {
    id: 23,
    titleBn: 'ওটিসি (OTC) মার্কেট অ্যালগরিদম কৌশল ও ট্র্যাপ এড়ানো',
    titleEn: 'OTC Market Algorithm Dynamics & Traps',
    category: 'binary',
    categoryBn: 'বাইনারি ও ওটিসি স্ট্র্যাটেজি',
    summaryBn: 'ব্রোকারের নিজস্ব অ্যালগরিদম মার্কেটকে বোঝা এবং তাদের চালে না ফাঁদা।',
    summaryEn: 'Understanding broker OTC momentum trends and avoiding counter-trend traps.',
    detailsBn: 'ওটিসি মার্কেট রিয়েল নিউজে চলে না, এটি কম্পিউটার অ্যালগরিদম দ্বারা পরিচালিত। ওটিসিতে সাধারণ সাপোর্ট-রেজিস্ট্যান্স অনেক সময় ফেইল করে কারণ অ্যালগরিদম ট্রেন্ড বজায় রাখে। তাই ওটিসিতে সবসময় ট্রেন্ড ফলো করুন, কখনও রিভার্সাল খুঁজতে যাবেন না।',
    detailsEn: 'Broker OTC algorithms respect momentum trends far more than technical reversal levels.',
    keyChecklistBn: [
      'ওটিসিতে পরপর ৩টি একই রঙের ক্যান্ডেল হলে ৪র্থ ক্যান্ডেলও সাধারণত সেইম রঙের হয়',
      'ওটিসিতে জোরপূর্বক রিভার্সাল খোঁজা বন্ধ করুন',
      'ক্যান্ডেল ব্রেকআউট দিলে ট্রেন্ডের সাথে চলুন'
    ],
    candleType: 'bullish',
    winTipBn: 'OTC মার্কেটের গোপন সূত্র: "Follow the Momentum, Never Fight the Trend"!',
    winTipEn: 'On OTC pairs, trade pure momentum continuation, never fight consecutive bars.'
  },
  {
    id: 24,
    titleBn: '৫-সেকেন্ড ও ১৫-সেকেন্ড মাইক্রো উইক রিজেকশন টেকনিক',
    titleEn: 'Micro Wick Rejection Technique (5s/15s Confirmation)',
    category: 'binary',
    categoryBn: 'বাইনারি ও ওটিসি স্ট্র্যাটেজি',
    summaryBn: '১-মিনিট ট্রেড নেওয়ার আগে ছোট টাইমফ্রেমে বাউন্স নিশ্চিত হওয়া।',
    summaryEn: 'Using lower timeframe ticks to observe actual buyer/seller absorption.',
    detailsBn: '১-মিনিটের ক্যান্ডেল যখন সাপোর্টে আসে, ৫-সেকেন্ড চার্ট ওপেন করে দেখুন সেখানে কি দ্রুত বায়াররা রিঅ্যাক্ট করছে কিনা। ৫-সেকেন্ডে ডাবল বটম বা স্ট্রং রিজেকশন দেখতে পেলে নিশ্চিত ১-মিনিট ট্রেড নেওয়া যায়।',
    detailsEn: 'Watching 5-second order flow reveals whether buyers are actively stepping into the zone.',
    keyChecklistBn: [
      'কি-লেভেলে আসার পর ক্যান্ডেল বারবার পিংপং বাউন্স করছে কিনা দেখুন',
      'লাস্ট ৫ সেকেন্ডে উইক তৈরি হলে পরবর্তী ক্যান্ডেল বিপরীতমুখী হয়',
      'তীব্র স্পাইক ক্যান্ডেল এড়িয়ে চলুন'
    ],
    candleType: 'reversal',
    winTipBn: 'শেষ ১৫ সেকেন্ডে বড় উইক তৈরি হলে চোখ বন্ধ করে পরবর্তী ক্যান্ডেল রিভার্সাল!',
    winTipEn: 'Aggressive rejection wick formed in the final 15 seconds guarantees next candle flip.'
  },
  {
    id: 25,
    titleBn: 'সাইকোলজিক্যাল রাউন্ড নম্বর (.000, .500, .800 লেভেল)',
    titleEn: 'Psychological Round Numbers & Institutional Reaction',
    category: 'binary',
    categoryBn: 'বাইনারি ও ওটিসি স্ট্র্যাটেজি',
    summaryBn: 'গোলাকার সংখ্যা যেখানে স্বয়ংক্রিয় অর্ডার সেট করা থাকে।',
    summaryEn: 'Trading institutional round numbers like 1.08000, 1.08500, and 1.08800.',
    detailsBn: 'যেসব প্রাইসের শেষে .000 বা .500 বা .800 থাকে, সেগুলোকে রাউন্ড নম্বর বলা হয়। ব্যাংক ও বড় ইন্সটিটিউটগুলো নির্দিষ্ট দশমিকের হিসাব ছাড়া এখানে টেক প্রফিট ও লিমিট অর্ডার বসিয়ে রাখে। প্রাইস এখানে আসলে ৯০% সময় ১টি রিঅ্যাকশন ক্যান্ডেল তৈরি হয়।',
    detailsEn: 'Round numbers contain heavy resting stop and limit orders that cause sharp snaps.',
    keyChecklistBn: [
      'চার্টের ডানপাশের প্রাইস স্কেলে শেষ সংখ্যাগুলো চেক করুন',
      'তিনটি শূন্য (.000) যুক্ত সংখ্যা সবচেয়ে শক্তিশালী ওয়াল (Wall)',
      'রাউন্ড নম্বরের সাথে SnR বা EMA মিললে নিশ্চিত বাউন্স ট্রেড'
    ],
    candleType: 'reversal',
    winTipBn: '.000 লেভেলে ১ম বার প্রাইস হিট করলে নিশ্চিত রিভার্সাল ১-মিনিট ট্রেড পাওয়া যায়।',
    winTipEn: 'First touch of a triple-zero level (.000) produces an immediate 1-minute bounce.'
  },

  // --- PHASE 5: RISK, PSYCHOLOGY & EXECUTION (ধাপ ২৬ - ৩০) ---
  {
    id: 26,
    titleBn: 'হাই-ইমপ্যাক্ট নিউজ ক্যালেন্ডার ও ট্রেডিং সেশন কৌশল',
    titleEn: 'High Impact News & Trading Session Windows',
    category: 'psychology',
    categoryBn: 'রিস্ক ও সাইকোলজি',
    summaryBn: 'কোন সময়ে ট্রেড করবেন আর কোন সময়ে মার্কেট থেকে দূরে থাকবেন।',
    summaryEn: 'London-New York overlap, CPI/NFP economic calendars, and avoiding slippage.',
    detailsBn: 'লন্ডন ও নিউ ইয়র্ক সেশনের ওভারল্যাপে (বাংলাদেশ সময় সন্ধ্যা ৬টা থেকে রাত ১০টা) মার্কেটে সর্বোচ্চ ভলিউম থাকে। ফরেক্সফ্যাক্টরি (ForexFactory) ক্যালেন্ডারে লাল চিহ্নিত হাই-ইমপ্যাক্ট নিউজের (যেমন CPI, NFP, Fed Rates) ১৫ মিনিট আগে ও পরে সমস্ত বাইনারি ট্রেডিং বন্ধ রাখতে হবে।',
    detailsEn: 'Never trade 15 minutes before and after red-folder economic releases due to wild spikes.',
    keyChecklistBn: [
      'ট্রেড শুরু করার আগে ForexFactory ক্যালেন্ডার চেক করুন',
      'হাই ইমপ্যাক্ট নিউজের সময় কোনো টেকনিক্যাল অ্যানালাইসিস কাজ করে না',
      'মার্কেটের ভলিউম সর্বোচ্চ এমন সময়ে (London-NY overlap) ট্রেড করুন'
    ],
    candleType: 'neutral',
    winTipBn: 'নিউজ টাইমে ট্রেড বন্ধ রাখা মানে আপনার ক্যাপিটালকে ১০০% সেফ রাখা।',
    winTipEn: 'Preserving capital during high volatility events is the mark of a professional.'
  },
  {
    id: 27,
    titleBn: '১% - ২% ক্যাপিটাল প্রোটেকশন ও মানি ম্যানেজমেন্ট',
    titleEn: 'Strict 1%-2% Capital Protection Rules',
    category: 'psychology',
    categoryBn: 'রিস্ক ও সাইকোলজি',
    summaryBn: 'আপনার মূলধন না বাঁচলে সমস্ত জ্ঞানই ব্যর্থ।',
    summaryEn: 'Risk allocation, portfolio sizing, and calculating maximum loss limits.',
    detailsBn: 'আপনার অ্যাকাউন্টের মোট ব্যালেন্সের ১% থেকে সর্বোচ্চ ২% প্রতি ট্রেডে বিনিয়োগ করুন (যেমন $100 থাকলে প্রতি ট্রেড $1-$2)। কখনও এক ট্রেডে বড় অ্যামাউন্ট দেবেন না। দিনে সর্বোচ্চ ৫% প্রফিট টার্গেট বা ৩% লস লিমিট স্পর্শ করলে মার্কেট বন্ধ করে দিন।',
    detailsEn: 'Never risk more than 1-2% of total balance per trade. Respect daily profit/loss caps.',
    keyChecklistBn: [
      'প্রতি ট্রেডে ফিক্সড রিস্ক অ্যামাউন্ট নির্ধারণ করুন',
      'দৈনিক প্রফিট টার্গেট পূরণ হলে সাথে সাথে প্ল্যাটফর্ম বন্ধ করুন',
      'কখনই অ্যাকাউন্ট গ্রো করার তাড়াহুড়ো করবেন না'
    ],
    candleType: 'neutral',
    winTipBn: 'ট্রেডিং হলো একটি ম্যারাথন দৌড়, কোনো ১০০ মিটারের স্প্রিন্ট নয়। ধৈর্যই আসল প্রফিট।',
    winTipEn: 'Capital preservation is rule #1. Live to trade another day.'
  },
  {
    id: 28,
    titleBn: 'মার্টিনগেল ডিসিপ্লিন ও রিভেঞ্জ ট্রেডিং নিষেধাজ্ঞা',
    titleEn: 'Disciplined 1-Step Martingale & Anti-Revenge Rules',
    category: 'psychology',
    categoryBn: 'রিস্ক ও সাইকোলজি',
    summaryBn: 'লস রিকভারি করতে গিয়ে পুরো অ্যাকাউন্ট শূন্য করার ফাঁদ থেকে বাঁচা।',
    summaryEn: 'Strict single-step recovery rule and banning emotional revenge bets.',
    detailsBn: 'মার্টিনগেল যদি ব্যবহার করতেই হয়, তবে সর্বোচ্চ ১-ধাপ (১ম ট্রেড লস হলে ২য় ট্রেডে ২.২ গুণ) ব্যবহার করুন। ২য় ট্রেড লস হলে সাথে সাথে সেই সেশনের মত স্টপ! কখনোই ৩য় বা ৪র্থ ধাপে যাবেন না। লসের পর ক্ষোভে অন্ধ হয়ে বড় ট্রেড (Revenge Trading) দেওয়াই অ্যাকাউন্ট জিরো হওয়ার মূল কারণ।',
    detailsEn: 'Cap Martingale strictly at 1-step recovery. Walk away immediately if step 1 fails.',
    keyChecklistBn: [
      '১ম ট্রেড $১ লস -> ২য় ট্রেড $২.২ -> এটি লস হলে ট্রেডিং বন্ধ',
      'পরপর ২টি লস হলে মিনিমাম ২ ঘণ্টার জন্য স্ক্রিন থেকে দূরে থাকুন',
      'রিভেঞ্জ ট্রেড আপনার সবচেয়ে বড় শত্রু'
    ],
    candleType: 'neutral',
    winTipBn: 'স্মার্ট ট্রেডাররা লস মেনে নেয় এবং শান্ত থাকে; অপেশাদাররা রাগ করে ব্যালেন্স খালি করে।',
    winTipEn: 'Accept losses gracefully. Never let a single bad trade wipe out a month of discipline.'
  },
  {
    id: 29,
    titleBn: 'ট্রেডার মাইন্ডসেট, সাইকোলজি ও ৩-ট্রেড স্টপ রুল',
    titleEn: 'Emotional Mastery & The 3-Trade Session Cap',
    category: 'psychology',
    categoryBn: 'রিস্ক ও সাইকোলজি',
    summaryBn: 'লোভ এবং ভয় নিয়ন্ত্রণ করে রোবটের মতো শান্ত ও সুশৃঙ্খল থাকা।',
    summaryEn: 'Overcoming FOMO, greed, and stopping cold after 3 consecutive outcomes.',
    detailsBn: 'ট্রেডিং ৯০% সাইকোলজি এবং ১০% টেকনিক্যাল। টানা ৩টি ট্রেড উইন করলে ওভারকনফিডেন্স চলে আসে, আবার টানা ২টি লস করলে হতাশা চলে আসে। নিয়ম করুন: যেকোনো সেশনে টানা ৩টি ট্রেড উইন হলে প্রফিট লক করে বের হয়ে যাবেন।',
    detailsEn: 'Trading is 90% psychological. Stop trading after 3 wins to lock gains, or 2 losses to stop bleeding.',
    keyChecklistBn: [
      'ট্রেড দেওয়ার সময় হার্টবিট স্বাভাবিক রাখুন',
      'FOMO (Fear Of Missing Out) এর কারণে ছুটে যাওয়া ক্যান্ডেলে লাফ দিয়ে ঢুকবেন না',
      'প্রফিটকে ব্যাংকে উইথড্র করার অভ্যাস গড়ে তুলুন'
    ],
    candleType: 'neutral',
    winTipBn: 'যে ট্রেডার আবেগ নিয়ন্ত্রণ করতে পারে, সে পৃথিবীর যেকোনো মার্কেটে সফল হবে।',
    winTipEn: 'Master your emotions and the markets will yield to your discipline.'
  },
  {
    id: 30,
    titleBn: 'প্রি-ট্রেড ৫-পয়েন্ট কনফ্লুয়েন্স চেকলিস্ট ও ট্রেডিং জার্নাল',
    titleEn: 'The 5-Point Confluence Checklist & Journaling System',
    category: 'psychology',
    categoryBn: 'রিস্ক ও সাইকোলজি',
    summaryBn: 'ট্রেড বাটনে ক্লিক করার আগে ৫টি শর্ত পূরণ হয়েছে কিনা তা মেপে নেওয়া।',
    summaryEn: 'The mandatory pre-flight checklist before pressing CALL or PUT.',
    detailsBn: 'প্রতিটি ট্রেডের পূর্বে ৫টি প্রশ্নের উত্তর হ্যাঁ হতে হবে:\n১. ট্রেন্ড কি আমার পক্ষে আছে?\n২. কোনো কি-লেভেল (SnR / OB / FVG) কি উপস্থিত?\n৩. ক্যান্ডেলস্টিক প্যাটার্ন বা উইক রিজেকশন কনফার্ম করেছে?\n৪. ইন্ডিকেটর (EMA বা RSI) কি সমর্থন দিচ্ছে?\n৫. আমি কি মার্জিন অফ সেফটি এন্ট্রি পাচ্ছি?\nঅন্তত ৪টি প্রশ্নের উত্তর হ্যাঁ না হলে ট্রেড নেওয়া সম্পূর্ণ নিষেধ!',
    detailsEn: 'Never execute unless at least 4 out of 5 confluence criteria are mathematically satisfied.',
    keyChecklistBn: [
      '১. ট্রেন্ড কনফার্মেশন (Trend Bias)',
      '২. কি-লেভেল প্রেজেন্স (SnR / Order Block)',
      '৩. ক্যান্ডেলস্টিক রিজেকশন উইক (Candle Rejection)',
      '৪. ইন্ডিকেটর কনফ্লুয়েন্স (EMA/RSI Confluence)',
      '৫. মার্জিন অফ সেফটি এন্ট্রি (Safety Margin)'
    ],
    candleType: 'bullish',
    winTipBn: 'এই ৫টি শর্ত মেনে ট্রেড করলে আপনার উইন রেট ৯০%+ নিশ্চিত হবে।',
    winTipEn: 'Follow the 5-point confluence formula to join the top 1% of consistent traders.'
  }
];
