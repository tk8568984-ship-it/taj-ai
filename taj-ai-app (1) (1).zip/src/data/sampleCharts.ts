export interface SampleChart {
  id: string;
  titleBn: string;
  titleEn: string;
  asset: string;
  timeframe: string;
  expectedSignal: 'CALL' | 'PUT';
  descriptionBn: string;
  svgDataUri: string;
}

// Generates an SVG candlestick chart converted to data URI
function createSampleChartSvg(type: 'hammer_call' | 'engulfing_put' | 'fvg_call'): string {
  if (type === 'hammer_call') {
    // 1-min chart showing downtrend ending with a classic hammer at green support line
    const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360" style="background:#0b0f19;">
      <defs>
        <linearGradient id="grid" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#1e293b" stop-opacity="0.3"/>
          <stop offset="100%" stop-color="#1e293b" stop-opacity="0.1"/>
        </linearGradient>
      </defs>
      <!-- Background & Grid -->
      <rect width="600" height="360" fill="#090d16"/>
      <line x1="40" y1="80" x2="560" y2="80" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="140" x2="560" y2="140" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="200" x2="560" y2="200" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="260" x2="560" y2="260" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="320" x2="560" y2="320" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>

      <!-- Header -->
      <text x="50" y="35" fill="#f8fafc" font-family="sans-serif" font-size="16" font-weight="bold">EUR/USD (OTC) - 1m</text>
      <text x="220" y="35" fill="#10b981" font-family="sans-serif" font-size="14" font-weight="bold">1.08452 (+0.04%)</text>
      <text x="500" y="35" fill="#64748b" font-family="sans-serif" font-size="12">EXP: 00:58s</text>

      <!-- Support Zone Level -->
      <rect x="40" y="270" width="520" height="15" fill="#10b981" fill-opacity="0.15"/>
      <line x1="40" y1="277" x2="560" y2="277" stroke="#10b981" stroke-width="2"/>
      <text x="460" y="272" fill="#10b981" font-family="sans-serif" font-size="10" font-weight="bold">MAJOR SUPPORT 1.08420</text>

      <!-- EMA 20 Dynamic Line -->
      <path d="M 60,110 Q 200,160 350,210 T 520,265" fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="4,2"/>
      <text x="70" y="105" fill="#06b6d4" font-family="sans-serif" font-size="10">EMA 20</text>

      <!-- Candles: Downtrend leading to Support -->
      <!-- C1: Red -->
      <line x1="90" y1="100" x2="90" y2="160" stroke="#f43f5e" stroke-width="2"/>
      <rect x="80" y="110" width="20" height="40" fill="#f43f5e"/>

      <!-- C2: Red -->
      <line x1="130" y1="135" x2="130" y2="195" stroke="#f43f5e" stroke-width="2"/>
      <rect x="120" y="145" width="20" height="40" fill="#f43f5e"/>

      <!-- C3: Small Green pullback -->
      <line x1="170" y1="165" x2="170" y2="215" stroke="#10b981" stroke-width="2"/>
      <rect x="160" y="175" width="20" height="25" fill="#10b981"/>

      <!-- C4: Strong Red -->
      <line x1="210" y1="180" x2="210" y2="250" stroke="#f43f5e" stroke-width="2"/>
      <rect x="200" y="190" width="20" height="50" fill="#f43f5e"/>

      <!-- C5: Red approaching support -->
      <line x1="250" y1="225" x2="250" y2="275" stroke="#f43f5e" stroke-width="2"/>
      <rect x="240" y="235" width="20" height="35" fill="#f43f5e"/>

      <!-- C6: Red piercing support with lower wick rejection -->
      <line x1="290" y1="245" x2="290" y2="285" stroke="#f43f5e" stroke-width="2"/>
      <rect x="280" y="250" width="20" height="25" fill="#f43f5e"/>

      <!-- C7: Doji on Support -->
      <line x1="330" y1="255" x2="330" y2="285" stroke="#94a3b8" stroke-width="2"/>
      <line x1="322" y1="272" x2="338" y2="272" stroke="#94a3b8" stroke-width="4"/>

      <!-- C8: THE KEY HAMMER (Bullish Rejection Pinbar at Support) -->
      <!-- Lower wick touching support and rejecting hard -->
      <line x1="370" y1="240" x2="370" y2="305" stroke="#10b981" stroke-width="3"/>
      <!-- Small body at the top -->
      <rect x="360" y="242" width="20" height="16" fill="#10b981" stroke="#34d399" stroke-width="1"/>
      <circle cx="370" cy="305" r="4" fill="#10b981"/>

      <!-- Target Box: "LATEST CANDLE: BULLISH HAMMER" -->
      <rect x="330" y="160" width="130" height="45" rx="6" fill="#0f172a" stroke="#10b981" stroke-width="1.5"/>
      <text x="395" y="180" fill="#10b981" font-family="sans-serif" font-size="11" font-weight="bold" text-anchor="middle">LATEST CANDLE</text>
      <text x="395" y="196" fill="#f8fafc" font-family="sans-serif" font-size="10" text-anchor="middle">Hammer Rejection</text>
      <line x1="395" y1="205" x2="375" y2="238" stroke="#10b981" stroke-width="1.5" stroke-dasharray="2,2"/>

      <!-- Predictive Arrow For Next Candle -->
      <path d="M 410,250 L 430,220 L 450,250 Z" fill="#10b981" fill-opacity="0.8"/>
      <rect x="425" y="250" width="10" height="20" fill="#10b981" fill-opacity="0.8"/>
      <text x="430" y="290" fill="#34d399" font-family="sans-serif" font-size="12" font-weight="bold" text-anchor="middle">NEXT: CALL ⬆</text>
    </svg>
    `;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }

  if (type === 'engulfing_put') {
    // 5-min chart showing uptrend into resistance with a massive Bearish Engulfing candle
    const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360" style="background:#0b0f19;">
      <!-- Background & Grid -->
      <rect width="600" height="360" fill="#090d16"/>
      <line x1="40" y1="80" x2="560" y2="80" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="140" x2="560" y2="140" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="200" x2="560" y2="200" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>
      <line x1="40" y1="260" x2="560" y2="260" stroke="#1e293b" stroke-width="1" stroke-dasharray="3,3"/>

      <!-- Header -->
      <text x="50" y="35" fill="#f8fafc" font-family="sans-serif" font-size="16" font-weight="bold">GBP/USD - 5m</text>
      <text x="200" y="35" fill="#f43f5e" font-family="sans-serif" font-size="14" font-weight="bold">1.27850 (-0.12%)</text>
      <text x="500" y="35" fill="#64748b" font-family="sans-serif" font-size="12">EXP: 04:12s</text>

      <!-- Resistance Zone Level -->
      <rect x="40" y="70" width="520" height="15" fill="#f43f5e" fill-opacity="0.2"/>
      <line x1="40" y1="77" x2="560" y2="77" stroke="#f43f5e" stroke-width="2"/>
      <text x="430" y="95" fill="#f43f5e" font-family="sans-serif" font-size="10" font-weight="bold">MAJOR RESISTANCE 1.28000 (.000 RN)</text>

      <!-- Candles: Uptrend hitting resistance -->
      <!-- C1: Green -->
      <line x1="90" y1="220" x2="90" y2="290" stroke="#10b981" stroke-width="2"/>
      <rect x="80" y="230" width="20" height="50" fill="#10b981"/>

      <!-- C2: Green -->
      <line x1="140" y1="180" x2="140" y2="240" stroke="#10b981" stroke-width="2"/>
      <rect x="130" y="190" width="20" height="40" fill="#10b981"/>

      <!-- C3: Green -->
      <line x1="190" y1="130" x2="190" y2="200" stroke="#10b981" stroke-width="2"/>
      <rect x="180" y="140" width="20" height="50" fill="#10b981"/>

      <!-- C4: Small Green Exhaustion candle at resistance -->
      <line x1="240" y1="75" x2="240" y2="150" stroke="#10b981" stroke-width="2"/>
      <rect x="230" y="85" width="20" height="25" fill="#10b981"/>

      <!-- C5: GIANT BEARISH ENGULFING RED CANDLE -->
      <line x1="280" y1="70" x2="280" y2="185" stroke="#f43f5e" stroke-width="3"/>
      <rect x="270" y="80" width="22" height="95" fill="#f43f5e" stroke="#fb7185" stroke-width="1"/>

      <!-- Marker -->
      <rect x="310" y="110" width="150" height="45" rx="6" fill="#0f172a" stroke="#f43f5e" stroke-width="1.5"/>
      <text x="385" y="130" fill="#f43f5e" font-family="sans-serif" font-size="11" font-weight="bold" text-anchor="middle">BEARISH ENGULFING</text>
      <text x="385" y="146" fill="#f8fafc" font-family="sans-serif" font-size="10" text-anchor="middle">Rejection at .000 RN</text>

      <!-- Predictive Arrow For Next Candle -->
      <path d="M 330,230 L 350,260 L 370,230 Z" fill="#f43f5e" fill-opacity="0.8"/>
      <rect x="345" y="210" width="10" height="20" fill="#f43f5e" fill-opacity="0.8"/>
      <text x="350" y="280" fill="#f43f5e" font-family="sans-serif" font-size="12" font-weight="bold" text-anchor="middle">NEXT: PUT ⬇</text>
    </svg>
    `;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }

  // fvg_call default
  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 360" width="600" height="360" style="background:#0b0f19;">
    <rect width="600" height="360" fill="#090d16"/>
    <text x="50" y="35" fill="#f8fafc" font-family="sans-serif" font-size="16" font-weight="bold">BTC/USDT - 1m Smart Money FVG</text>
    <rect x="40" y="210" width="520" height="35" fill="#3b82f6" fill-opacity="0.2"/>
    <line x1="40" y1="227" x2="560" y2="227" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="4,4"/>
    <text x="450" y="205" fill="#3b82f6" font-family="sans-serif" font-size="10" font-weight="bold">BULLISH FVG MITIGATION</text>

    <!-- Candle 1: Big impulse up -->
    <line x1="120" y1="120" x2="120" y2="280" stroke="#10b981" stroke-width="3"/>
    <rect x="110" y="130" width="20" height="130" fill="#10b981"/>

    <!-- Candle 2: High candle -->
    <line x1="170" y1="80" x2="170" y2="160" stroke="#10b981" stroke-width="2"/>
    <rect x="160" y="90" width="20" height="50" fill="#10b981"/>

    <!-- Candle 3: Retracement filling FVG -->
    <line x1="220" y1="130" x2="220" y2="230" stroke="#f43f5e" stroke-width="2"/>
    <rect x="210" y="140" width="20" height="85" fill="#f43f5e"/>

    <!-- Candle 4: Wick tap into FVG 50% & instant bounce -->
    <line x1="270" y1="170" x2="270" y2="235" stroke="#10b981" stroke-width="3"/>
    <rect x="260" y="180" width="20" height="30" fill="#10b981"/>

    <text x="320" y="200" fill="#10b981" font-family="sans-serif" font-size="12" font-weight="bold">NEXT CANDLE: STRONG CALL ⬆</text>
  </svg>
  `;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}

export const SAMPLE_CHARTS: SampleChart[] = [
  {
    id: 'sample-eurusd-hammer',
    titleBn: 'EUR/USD ওটিসি - সাপোর্টে হ্যামার বাউন্স (CALL সিগন্যাল)',
    titleEn: 'EUR/USD OTC - Hammer Rejection at Major Support',
    asset: 'EUR/USD (OTC)',
    timeframe: '1m',
    expectedSignal: 'CALL',
    descriptionBn: '১-মিনিট ওটিসি চার্ট। ডাউনট্রেন্ডের শেষে স্ট্রং হরিজন্টাল সাপোর্টে একটি নিখুঁত বুলিশ হ্যামার রিজেকশন তৈরি হয়েছে। পরবর্তী ক্যান্ডেল নিশ্চিত গ্রিন হওয়ার ৯০% সুযোগ।',
    svgDataUri: createSampleChartSvg('hammer_call'),
  },
  {
    id: 'sample-gbpusd-engulfing',
    titleBn: 'GBP/USD - রাউন্ড নম্বরে বেয়ারিশ এনগালফিং (PUT সিগন্যাল)',
    titleEn: 'GBP/USD - Bearish Engulfing at 1.28000 Round Number',
    asset: 'GBP/USD',
    timeframe: '5m',
    expectedSignal: 'PUT',
    descriptionBn: '৫-মিনিট চার্ট। ১.২৮০০০ সাইকোলজিক্যাল রাউন্ড নাম্বারে রিজেকশন দিয়ে পূর্ববর্তী গ্রিন ক্যান্ডেলকে সম্পূর্ণ গিলে ফেলেছে বিশাল রেড ক্যান্ডেল। পরবর্তী ক্যান্ডেলে নিশ্চিত ডাউন মুভ।',
    svgDataUri: createSampleChartSvg('engulfing_put'),
  },
  {
    id: 'sample-btcusdt-fvg',
    titleBn: 'BTC/USDT - স্মার্ট মানি ফেয়ার ভ্যালু গ্যাপ রিটেস্ট (CALL সিগন্যাল)',
    titleEn: 'BTC/USDT - SMC Fair Value Gap (FVG) Mitigation',
    asset: 'BTC/USDT',
    timeframe: '1m',
    expectedSignal: 'CALL',
    descriptionBn: 'বুলিশ ইমপালস মুভের পর আনফিল্ড FVG জোনের ৫০% লেভেলে ক্যান্ডেলের উইক টাচ করে বাউন্স করেছে। পরবর্তী ক্যান্ডেল বুলিশ কন্টিনিউয়েশন দেবে।',
    svgDataUri: createSampleChartSvg('fvg_call'),
  },
];
