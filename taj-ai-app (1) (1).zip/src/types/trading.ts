export type AppLanguage = 'bn' | 'en';

export interface TradingRule {
  id: number;
  titleBn: string;
  titleEn: string;
  category: 'structure' | 'smc' | 'indicators' | 'binary' | 'psychology';
  categoryBn: string;
  summaryBn: string;
  summaryEn: string;
  detailsBn: string;
  detailsEn: string;
  keyChecklistBn: string[];
  candleType?: 'bullish' | 'bearish' | 'neutral' | 'reversal';
  winTipBn: string;
  winTipEn: string;
}

export interface CandleData {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema20?: number;
  ema50?: number;
  isBullish: boolean;
}

export interface NextCandlePrediction {
  signal: 'CALL' | 'PUT' | 'WAIT';
  confidence: number;
  trend: string;
  pattern: string;
  recommendedExpiry: string;
  entryAdvice: string;
  keyLevels: string;
  confluences: string[];
  bengaliExplanation: string;
  englishSummary: string;
  riskNote: string;
}

export interface PhoneAppAction {
  id: string;
  nameBn: string;
  nameEn: string;
  iconName: string;
  category: 'social' | 'trading' | 'tools' | 'device';
  urlScheme: string;
  webFallback: string;
  commandVoiceBn: string;
  color: string;
}

export interface AssistantChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  actionTriggered?: {
    app: string;
    label: string;
    url: string;
  };
  predictionData?: NextCandlePrediction;
}
